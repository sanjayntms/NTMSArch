// ═══════════════════════════════════════════════════════
// TOPIC MODULE: Virtual Machines & Infrastructure
// Well-Architected Framework lens on every service.
//
// Azure: VMs, VMSS, Dedicated Host, Spot VMs, Bastion,
//        Site Recovery, Azure Backup, Azure Migrate
// AWS:   EC2, Auto Scaling Groups, Dedicated Hosts,
//        Spot Instances, Systems Manager, AWS Backup,
//        Elastic Disaster Recovery, App Migration Svc
// GCP:   Compute Engine, MIGs, Sole-Tenant Nodes,
//        Spot VMs, IAP SSH, Cloud Backup & DR,
//        Migrate to Virtual Machines
// ═══════════════════════════════════════════════════════

window.TOPIC_VM = (function () {

const META = {
  id: 'vm',
  label: 'Virtual Machines',
  icon: '🖥️',
  desc: 'IaaS compute, auto-scaling, HA, DR, migration — through the Well-Architected lens',
  clouds: ['azure', 'aws', 'gcp'],
  views: ['tree', 'gallery', 'compare'],
  heroTitle: 'Which VM / IaaS service fits your workload?',
  heroSub: 'Reliability · Security · Cost · Performance · Operations — Well-Architected Framework',
  chips: {
    azure: ['🖥️ Virtual Machines', '📈 VM Scale Sets', '🔒 Azure Bastion', '💾 Azure Backup', '🔄 Site Recovery', '✈️ Azure Migrate'],
    aws:   ['🖥️ EC2', '📈 Auto Scaling', '🔒 Systems Manager', '💾 AWS Backup', '🔄 Elastic DR', '✈️ App Migration Svc'],
    gcp:   ['🖥️ Compute Engine', '📈 Managed Instance Groups', '🔒 IAP SSH', '💾 Cloud Backup & DR', '🔄 Snapshot Policy', '✈️ Migrate to VMs'],
  },
};

// ── SVG HELPERS ────────────────────────────────────────
function B(x,y,w,h,lb,sb,col,rx=9){
  const F={blue:'#ebf4fc',teal:'#e0f7fa',green:'#e8f5e8',amber:'#fff8ed',red:'#fce8e9',gray:'#f3f7fb',purple:'#f3e8fd',indigo:'#eef0fb',orange:'#fff3e0'};
  const S={blue:'#0078d4',teal:'#00b4d8',green:'#107c10',amber:'#e07000',red:'#a4262c',gray:'#a0b8cc',purple:'#7b2fbe',indigo:'#4b5ae4',orange:'#e65100'};
  const TX={blue:'#004578',teal:'#006478',green:'#0a5007',amber:'#5a3000',red:'#6b0c0e',gray:'#3a5068',purple:'#4a1580',indigo:'#1e2580',orange:'#4e1f00'};
  const f=F[col]||F.blue,s=S[col]||S.blue,t=TX[col]||TX.blue;
  const cy=sb?y+h/2-7:y+h/2;
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${f}" stroke="${s}" stroke-width="1.5"/>
<text x="${x+w/2}" y="${cy}" text-anchor="middle" dominant-baseline="central" font-family="'DM Sans',sans-serif" font-size="14" font-weight="600" fill="${t}">${lb}</text>
${sb?`<text x="${x+w/2}" y="${y+h/2+11}" text-anchor="middle" dominant-baseline="central" font-family="'DM Sans',sans-serif" font-size="12" fill="${t}" opacity=".8">${sb}</text>`:''}`;}

function A(x1,y1,x2,y2,col='#0078d4'){
  const id='vm'+Math.abs(x1*3+y1*7+x2*11+y2*17);
  return `<defs><marker id="${id}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M2 1L8 5L2 9" fill="none" stroke="${col}" stroke-width="2" stroke-linecap="round"/></marker></defs>
<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" stroke-width="2" class="fa" marker-end="url(#${id})"/>`;}

function N(x,y,t){return `<text x="${x}" y="${y}" font-family="'DM Sans',sans-serif" font-size="13" fill="#6a8ba4">${t}</text>`;}
function SVG(c,h=268){return `<svg viewBox="0 0 780 ${h}" xmlns="http://www.w3.org/2000/svg">${c}</svg>`;}

// WAF pillar label (small badge on diagrams)
function WAF(x,y,pillar,col){
  const cols={RE:'#107c10',SE:'#a4262c',CO:'#e07000',PE:'#0078d4',OE:'#7b2fbe'};
  const c=cols[pillar]||'#6a8ba4';
  return `<rect x="${x}" y="${y}" width="28" height="14" rx="4" fill="${c}" opacity=".15"/>
<text x="${x+14}" y="${y+10}" text-anchor="middle" font-family="'DM Sans',sans-serif" font-size="9" font-weight="700" fill="${c}">${pillar}</text>`;
}

// ── GLOSSY ICON BUILDER ────────────────────────────────
function gi(iid,bg1,bg2,shape){
  return `<svg width="80" height="80" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg" style="filter:drop-shadow(0 6px 18px ${bg1}70)">
<defs>
<radialGradient id="gb_${iid}" cx="35%" cy="28%" r="72%"><stop offset="0%" stop-color="${bg2}"/><stop offset="100%" stop-color="${bg1}"/></radialGradient>
<radialGradient id="gs_${iid}" cx="42%" cy="18%" r="62%"><stop offset="0%" stop-color="rgba(255,255,255,0.62)"/><stop offset="100%" stop-color="rgba(255,255,255,0)"/></radialGradient>
</defs>
<rect x="4" y="5" width="64" height="63" rx="16" fill="url(#gb_${iid})"/>
<rect x="4" y="5" width="64" height="35" rx="16" fill="url(#gs_${iid})" opacity="0.75"/>
<rect x="4" y="28" width="64" height="12" fill="url(#gs_${iid})" opacity="0.22"/>
${shape}
<rect x="4" y="5" width="64" height="63" rx="16" fill="none" stroke="rgba(255,255,255,0.28)" stroke-width="1.5"/>
</svg>`;}

// Icon shapes
const VM_SHAPE = `<rect x="14" y="16" width="44" height="32" rx="5" fill="white" opacity=".92"/>
<rect x="14" y="16" width="44" height="10" rx="5" fill="rgba(255,255,255,.5)"/>
<rect x="14" y="21" width="44" height="5" fill="rgba(255,255,255,.5)"/>
<circle cx="20" cy="23" r="2.2" fill="rgba(0,0,0,.2)"/>
<circle cx="26" cy="23" r="2.2" fill="rgba(0,0,0,.15)"/>
<rect x="20" y="31" width="16" height="2.5" rx="1" fill="rgba(0,0,0,.18)"/>
<rect x="20" y="36" width="24" height="2.5" rx="1" fill="rgba(0,0,0,.13)"/>
<rect x="20" y="41" width="12" height="2.5" rx="1" fill="rgba(0,0,0,.10)"/>
<rect x="26" y="50" width="20" height="4" rx="2" fill="white" opacity=".6"/>
<rect x="22" y="54" width="28" height="3" rx="1.5" fill="white" opacity=".45"/>`;

const SCALE_SHAPE = `<rect x="10" y="26" width="22" height="18" rx="4" fill="white" opacity=".75"/>
<rect x="25" y="18" width="22" height="18" rx="4" fill="white" opacity=".88"/>
<rect x="40" y="26" width="22" height="18" rx="4" fill="white" opacity=".75"/>
<path d="M20 22 L20 26 M36 14 L36 18 M52 22 L52 26" stroke="white" stroke-width="2" opacity=".6" stroke-linecap="round"/>
<path d="M20 22 Q36 16 52 22" fill="none" stroke="white" stroke-width="1.8" opacity=".5"/>`;

const BASTION_SHAPE = `<path d="M36 14 L50 20 L50 36 Q50 48 36 54 Q22 48 22 36 L22 20Z" fill="white" opacity=".9"/>
<path d="M30 36 L34 40 L42 30" stroke="rgba(0,0,0,.25)" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;

const BACKUP_SHAPE = `<path d="M36 16 C24 16 16 24 16 36 C16 48 24 56 36 56 C48 56 56 48 56 36" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" opacity=".9"/>
<path d="M36 14 L40 22 L32 22Z" fill="white" opacity=".85"/>
<rect x="30" y="30" width="12" height="12" rx="3" fill="white" opacity=".8"/>
<path d="M33 36 L35 38 L39 33" stroke="rgba(0,0,0,.3)" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;

const DR_SHAPE = `<rect x="12" y="20" width="22" height="16" rx="4" fill="white" opacity=".88"/>
<rect x="38" y="20" width="22" height="16" rx="4" fill="white" opacity=".7"/>
<path d="M34 28 L38 28" stroke="white" stroke-width="2.5" opacity=".7" stroke-linecap="round"/>
<path d="M34 26 L38 28 L34 30" fill="white" opacity=".8"/>
<path d="M22 36 L22 44 L50 44 L50 36" stroke="white" stroke-width="1.8" fill="none" opacity=".5" stroke-dasharray="4 2"/>
<rect x="28" y="44" width="16" height="10" rx="3" fill="white" opacity=".65"/>`;

const MIGRATE_SHAPE = `<rect x="10" y="22" width="20" height="16" rx="4" fill="white" opacity=".7"/>
<rect x="42" y="22" width="20" height="16" rx="4" fill="white" opacity=".92"/>
<path d="M30 30 L42 30" stroke="white" stroke-width="2.5" stroke-linecap="round" opacity=".8"/>
<path d="M38 26 L42 30 L38 34" fill="white" opacity=".9"/>
<text x="50" y="49" text-anchor="middle" font-family="'DM Sans',sans-serif" font-size="9" font-weight="700" fill="white" opacity=".8">CLOUD</text>
<text x="20" y="49" text-anchor="middle" font-family="'DM Sans',sans-serif" font-size="9" font-weight="700" fill="white" opacity=".6">ON-PREM</text>`;

const SPOT_SHAPE = `<path d="M40 14 L30 34 L38 34 L32 58 L52 30 L42 30 L48 14Z" fill="white" opacity=".92"/>`;

const DEDICATED_SHAPE = `<rect x="12" y="20" width="48" height="34" rx="5" fill="white" opacity=".25"/>
<rect x="16" y="24" width="18" height="12" rx="3" fill="white" opacity=".9"/>
<rect x="38" y="24" width="18" height="12" rx="3" fill="white" opacity=".9"/>
<rect x="16" y="38" width="18" height="12" rx="3" fill="white" opacity=".75"/>
<rect x="38" y="38" width="18" height="12" rx="3" fill="white" opacity=".75"/>`;

const PLACEMENT_SHAPE = `<circle cx="36" cy="36" r="6" fill="white" opacity=".95"/>
<circle cx="18" cy="22" r="5" fill="white" opacity=".8"/>
<circle cx="54" cy="22" r="5" fill="white" opacity=".8"/>
<circle cx="18" cy="50" r="5" fill="white" opacity=".7"/>
<circle cx="54" cy="50" r="5" fill="white" opacity=".7"/>
<line x1="22" y1="24" x2="31" y2="31" stroke="white" stroke-width="1.8" opacity=".6"/>
<line x1="50" y1="24" x2="41" y2="31" stroke="white" stroke-width="1.8" opacity=".6"/>
<line x1="22" y1="48" x2="31" y2="41" stroke="white" stroke-width="1.8" opacity=".55"/>
<line x1="50" y1="48" x2="41" y2="41" stroke="white" stroke-width="1.8" opacity=".55"/>`;

const ICONS = {
  // Azure
  'azure_vm':         gi('azVM',    '#004578','#0078d4', VM_SHAPE),
  'azure_vmss':       gi('azVMSS',  '#003060','#0060c0', SCALE_SHAPE),
  'azure_bastion':    gi('azBast',  '#003a70','#0080c0', BASTION_SHAPE),
  'azure_backup':     gi('azBkup',  '#5c0080','#9333ea', BACKUP_SHAPE),
  'azure_asr':        gi('azASR',   '#0a5060','#0891b2', DR_SHAPE),
  'azure_migrate':    gi('azMig',   '#004578','#0069b0', MIGRATE_SHAPE),
  'azure_spot':       gi('azSpot',  '#7a4200','#e07000', SPOT_SHAPE),
  'azure_dedicated':  gi('azDed',   '#002855','#004a90', DEDICATED_SHAPE),
  // AWS
  'aws_ec2':          gi('awsEC2',  '#7a4200','#e07000', VM_SHAPE),
  'aws_asg':          gi('awsASG',  '#6a3800','#c86800', SCALE_SHAPE),
  'aws_ssm':          gi('awsSSM',  '#003a70','#0070c0', BASTION_SHAPE),
  'aws_backup':       gi('awsBkup', '#5a3000','#a06000', BACKUP_SHAPE),
  'aws_drs':          gi('awsDRS',  '#0a4060','#0880b0', DR_SHAPE),
  'aws_ams':          gi('awsAMS',  '#7a4200','#c07000', MIGRATE_SHAPE),
  'aws_spot':         gi('awsSpot', '#6a3800','#d47000', SPOT_SHAPE),
  'aws_dedicated':    gi('awsDed',  '#3a2000','#806000', DEDICATED_SHAPE),
  // GCP
  'gcp_ce':           gi('gcpCE',   '#0d3b8c','#2878e8', VM_SHAPE),
  'gcp_mig':          gi('gcpMIG',  '#0d2f6e','#1a60d4', SCALE_SHAPE),
  'gcp_iap':          gi('gcpIAP',  '#0d4060','#0891b2', BASTION_SHAPE),
  'gcp_backup':       gi('gcpBkup', '#0d3b8c','#1565c0', BACKUP_SHAPE),
  'gcp_clouddr':      gi('gcpDR',   '#083060','#1060b0', DR_SHAPE),
  'gcp_migrate':      gi('gcpMig',  '#0d3b8c','#1a73e8', MIGRATE_SHAPE),
  'gcp_spot':         gi('gcpSpot', '#0d4060','#0369a1', SPOT_SHAPE),
  'gcp_soletenant':   gi('gcpST',   '#0d2040','#0d47a1', DEDICATED_SHAPE),
};

// ── DIAGRAMS ──────────────────────────────────────────────
const DIAG = {
  // ── AZURE ──
  azure_vm: ()=>SVG(`
${B(20,24,120,36,'Internet / VNet','','gray',7)}
${B(20,68,120,36,'Azure Load Balancer','or App Gateway','blue',7)}
${A(80,60,80,68,'#0078d4')}
${A(80,104,80,115,'#0078d4')}
${B(20,115,120,36,'NSG','Network Security Group','red',7)}
${A(80,151,80,162,'#0078d4')}
${B(20,162,340,78,'Availability Zone 1','','blue')}
${B(30,178,145,50,'VM (Primary)','D4s_v5 · Premium SSD','blue',7)}
${B(195,178,155,50,'Azure Backup','Daily · 30 days','purple',7)}
${B(370,162,340,78,'Availability Zone 2','','teal')}
${B(380,178,145,50,'VM (Secondary)','ASR replica','teal',7)}
${B(535,178,155,50,'Managed Identity','No stored secrets','green',7)}
${A(175,203,195,203,'#9333ea')}
${A(360,203,380,203,'#00b4d8')}
${N(20,258,'RE: Zone-redundant · SE: NSG + Managed Identity · CO: Right-size SKU · PE: Premium SSD · OE: Backup policy')}
`,270),

  azure_vmss: ()=>SVG(`
${B(20,40,140,40,'Load Balancer / AGIC','Distributes traffic','blue',7)}
${A(90,80,90,105,'#0078d4')}
${B(20,105,590,130,'VM Scale Set — Auto-scales 2 → 100 instances','','blue')}
${B(30,125,130,42,'VM Instance 1','','blue',7)}
${B(170,125,130,42,'VM Instance 2','','blue',7)}
${B(310,125,130,42,'VM Instance 3','','blue',7)}
${B(450,125,145,42,'+ scale out...','triggered by CPU/mem/custom','teal',7)}
${A(90,235,90,255,'#107c10')}
${B(20,255,180,38,'Autoscale Policy','CPU>70% scale-out · CPU<30% scale-in','green',7)}
${B(210,255,200,38,'Custom Script Extension','Bootstraps each instance','purple',7)}
${B(420,255,185,38,'Azure Monitor','Metrics → alert → scale','amber',7)}
${N(20,308,'RE: Multi-zone VMSS · CO: Scale in saves cost · PE: Accelerated Networking · OE: Rolling upgrades')}
`,320),

  azure_bastion: ()=>SVG(`
${B(20,80,120,44,'Admin Browser','HTTPS only — no RDP/SSH port open','gray')}
${A(140,102,215,102,'#0080c0')}
${B(215,60,175,84,'Azure Bastion','PaaS · fully managed','blue')}
${A(390,80,465,65,'#107c10')}${A(390,102,465,102,'#a4262c')}
${B(465,48,200,40,'VM (Windows)','RDP via browser — port 3389 closed','green',7)}
${B(465,96,200,40,'VM (Linux)','SSH via browser — port 22 closed','red',7)}
${B(20,185,590,50,'VNet — No public IP on VMs · NSG blocks RDP/SSH from internet','','gray')}
${N(20,252,'SE: Eliminates public RDP/SSH · OE: No jump-box to manage · RE: Bastion is zone-redundant (Standard)')}
`,265),

  azure_backup: ()=>SVG(`
${B(20,70,145,44,'Azure VM','Any OS · any disk type','gray')}
${A(165,92,240,92,'#9333ea')}
${B(240,52,200,80,'Azure Backup','Recovery Services Vault','purple')}
${A(440,70,515,55,'#9333ea')}${A(440,92,515,92,'#9333ea')}${A(440,114,515,128,'#9333ea')}
${B(515,38,200,40,'Daily snapshots','Application-consistent','purple',7)}
${B(515,82,200,40,'GRS / LRS vault','Cross-region restore','teal',7)}
${B(515,126,200,40,'Soft delete 14 days','Ransomware protection','green',7)}
${N(20,210,'RE: RPO/RTO · SE: Immutable vault · CO: Tiered storage (Vault-Standard vs Archive) · OE: Backup Centre')}
`,225),

  azure_asr: ()=>SVG(`
${B(20,65,160,44,'Primary Region','East US — production VMs','blue')}
${A(180,87,245,87,'#0891b2')}
${B(245,50,190,74,'Azure Site Recovery','Continuous replication','teal')}
${A(435,72,510,58,'#0891b2')}${A(435,87,510,87,'#0891b2')}
${B(510,40,200,40,'Secondary Region','West US — replica VMs','teal',7)}
${B(510,84,200,40,'Recovery Plan','1-click failover orchestration','green',7)}
${B(510,128,200,40,'Test Failover','No production impact','amber',7)}
${N(20,200,'RE: RPO <1 min · RTO <15 min · CO: Pay only while replicating · OE: Automated runbooks on failover')}
`,215),

  azure_migrate: ()=>SVG(`
${B(20,75,150,44,'On-premises','VMware · Hyper-V · Physical','gray')}
${A(170,97,240,97,'#0078d4')}
${B(240,55,200,84,'Azure Migrate Hub','Discover · Assess · Migrate','blue')}
${A(440,75,515,58,'#0078d4')}${A(440,97,515,97,'#0078d4')}${A(440,120,515,135,'#0078d4')}
${B(515,40,200,38,'Dependency mapping','Right-size assessment','teal',7)}
${B(515,82,200,38,'Replication agent','Continuous sync','green',7)}
${B(515,124,200,38,'Cutover','Minimal downtime','amber',7)}
${N(20,205,'OE: TCO calculator · CO: Reserved instance recommendations · SE: Migrate with zero open ports')}
`,218),

  azure_spot: ()=>SVG(`
${B(20,80,145,44,'Workload','Batch · ML · Rendering · CI','gray')}
${A(165,102,240,102,'#e07000')}
${B(240,62,195,80,'Azure Spot VMs','Up to 90% discount','amber')}
${B(460,42,230,40,'Eviction policy','Deallocate or Delete','amber',7)}
${B(460,86,230,40,'Spot price cap','Bid-based or market price','green',7)}
${B(460,130,230,40,'Fallback to on-demand','VMSS mixed-mode','teal',7)}
${A(435,82,460,62,'#e07000')}${A(435,102,460,106,'#e07000')}${A(435,122,460,150,'#e07000')}
${N(20,210,'CO: 60–90% savings · RE: Design for eviction — checkpoint state · OE: Use VMSS with Spot + on-demand mix')}
`,225),

  azure_dedicated: ()=>SVG(`
${B(20,80,145,44,'Organisation','Compliance · Licensing','gray')}
${A(165,102,240,102,'#004a90')}
${B(240,55,200,94,'Azure Dedicated Host','Physical server isolated to you','blue')}
${B(460,40,230,40,'Host group','Fault domain placement','blue',7)}
${B(460,84,230,40,'Bring Your Own License','Windows Server · SQL Server','green',7)}
${B(460,128,230,40,'Maintenance control','Schedule your own patching','teal',7)}
${A(440,75,460,60,'#004a90')}${A(440,102,460,104,'#004a90')}${A(440,128,460,148,'#004a90')}
${N(20,210,'SE: Hardware isolation for compliance (PCI-DSS, HIPAA) · CO: BYOL saves up to 40% · OE: Controlled patching')}
`,225),

  // ── AWS ──
  aws_ec2: ()=>SVG(`
${B(20,24,130,36,'Internet Gateway','','gray',7)}
${B(20,68,130,36,'Elastic Load Balancer','ALB or NLB','amber',7)}
${A(85,60,85,68,'#e07000')}${A(85,104,85,115,'#e07000')}
${B(20,115,130,36,'Security Group','Stateful firewall','red',7)}
${A(85,151,85,162,'#e07000')}
${B(20,162,340,78,'AZ us-east-1a','','amber')}
${B(30,178,145,50,'EC2 Instance','t3.large · gp3 EBS','amber',7)}
${B(185,178,160,50,'IAM Instance Profile','No access keys on instance','green',7)}
${B(370,162,340,78,'AZ us-east-1b','','teal')}
${B(380,178,145,50,'EC2 Instance','AMI — identical config','teal',7)}
${B(535,178,160,50,'Systems Manager','Patch + Session Manager','blue',7)}
${A(175,203,185,203,'#107c10')}${A(360,203,380,203,'#00b4d8')}
${N(20,258,'RE: Multi-AZ · SE: IAM profile + SG + SSM (no port 22) · CO: Savings Plans · PE: Enhanced Networking')}
`,270),

  aws_asg: ()=>SVG(`
${B(20,40,150,40,'Application Load Balancer','Health checks → route to healthy','amber',7)}
${A(95,80,95,105,'#e07000')}
${B(20,105,590,130,'Auto Scaling Group — Min 2 · Desired 4 · Max 20','','amber')}
${B(30,125,130,42,'EC2 Instance','AZ-1a','amber',7)}
${B(170,125,130,42,'EC2 Instance','AZ-1b','amber',7)}
${B(310,125,130,42,'EC2 Instance','AZ-1c','amber',7)}
${B(450,125,145,42,'→ scale out','on alarm','teal',7)}
${A(95,235,95,255,'#107c10')}
${B(20,255,180,38,'Scaling Policy','Target tracking · Step · Scheduled','green',7)}
${B(210,255,200,38,'Launch Template','AMI · type · SG · user-data','amber',7)}
${B(420,255,185,38,'CloudWatch Alarms','CPU · custom metric → scale','blue',7)}
${N(20,308,'RE: Multi-AZ min=2 always · CO: Spot+On-demand mix · PE: Warm pools (pre-warm instances) · OE: Instance Refresh')}
`,320),

  aws_ssm: ()=>SVG(`
${B(20,80,130,44,'Admin / CICD','No SSH key needed','gray')}
${A(150,102,225,102,'#0070c0')}
${B(225,60,175,84,'AWS Systems Manager','Session Manager · Patch · Run','blue')}
${A(400,80,475,65,'#107c10')}${A(400,102,475,102,'#a4262c')}
${B(475,48,200,40,'EC2 (private subnet)','Port 22/3389 closed · SSM agent','green',7)}
${B(475,96,200,40,'On-premises server','SSM hybrid activation','red',7)}
${B(225,165,390,44,'VPC Endpoint for SSM','Traffic stays in AWS network — no IGW','teal')}
${N(20,228,'SE: Zero open inbound ports · OE: Patch Manager automates OS patches · RE: SSM is regional HA')}
`,240),

  aws_backup: ()=>SVG(`
${B(20,70,145,44,'AWS Resources','EC2 · EBS · RDS · EFS · DynamoDB','gray')}
${A(165,92,240,92,'#a06000')}
${B(240,52,200,80,'AWS Backup','Centralised backup service','amber')}
${A(440,70,515,55,'#a06000')}${A(440,92,515,92,'#a06000')}${A(440,114,515,128,'#a06000')}
${B(515,38,200,40,'Backup plan','Policy · frequency · retention','amber',7)}
${B(515,82,200,40,'Cross-region copy','Disaster recovery vault','teal',7)}
${B(515,126,200,40,'Backup Vault Lock','WORM — immutable','green',7)}
${N(20,210,'RE: Cross-region · SE: Vault Lock (ransomware) · CO: Cold tier for old backups · OE: Organisation-wide policy')}
`,225),

  aws_drs: ()=>SVG(`
${B(20,65,160,44,'Source','On-prem · AWS · Other cloud','gray')}
${A(180,87,245,87,'#0880b0')}
${B(245,50,190,74,'AWS Elastic DR','Continuous block replication','blue')}
${A(435,72,510,58,'#0880b0')}${A(435,87,510,87,'#0880b0')}
${B(510,40,200,40,'Staging area','Low-cost replication servers','teal',7)}
${B(510,84,200,40,'Recovery instances','Launch in minutes','green',7)}
${B(510,128,200,40,'Drill mode','Test without impact','amber',7)}
${N(20,200,'RE: RPO seconds · RTO minutes · CO: Staging = t3.micro · OE: Automated failback after incident')}
`,215),

  aws_ams: ()=>SVG(`
${B(20,75,150,44,'Source','VMware vCenter · Hyper-V · AWS','gray')}
${A(170,97,240,97,'#c07000')}
${B(240,55,200,84,'AWS MGN','Application Migration Service','amber')}
${A(440,75,515,58,'#c07000')}${A(440,97,515,97,'#c07000')}${A(440,120,515,135,'#c07000')}
${B(515,40,200,38,'Continuous replication','Block-level sync','amber',7)}
${B(515,82,200,38,'Launch test instance','Verify before cutover','green',7)}
${B(515,124,200,38,'Cutover','Minimal downtime window','teal',7)}
${N(20,205,'OE: Automated cutover · CO: Right-size with Compute Optimizer · RE: Retest as many times as needed')}
`,218),

  aws_spot: ()=>SVG(`
${B(20,80,145,44,'Workload','Batch · ML · HPC · CI/CD','gray')}
${A(165,102,240,102,'#d47000')}
${B(240,62,195,80,'EC2 Spot Instances','Up to 90% discount','amber')}
${B(460,42,230,40,'Spot interruption','2-min notice · checkpoint','amber',7)}
${B(460,86,230,40,'Spot Instance Advisor','Interruption frequency guide','green',7)}
${B(460,130,230,40,'ASG mixed policy','Spot + On-Demand fallback','teal',7)}
${A(435,82,460,62,'#d47000')}${A(435,102,460,106,'#d47000')}${A(435,122,460,150,'#d47000')}
${N(20,210,'CO: 60–90% savings · RE: Handle interruption gracefully · OE: EC2 Fleet diversifies instance types')}
`,225),

  aws_dedicated: ()=>SVG(`
${B(20,80,145,44,'Organisation','Compliance · BYOL · Licensing','gray')}
${A(165,102,240,102,'#806000')}
${B(240,55,200,94,'EC2 Dedicated Hosts','Physical server to one account','amber')}
${B(460,40,230,40,'Host resource groups','Automatic placement','amber',7)}
${B(460,84,230,40,'BYOL','Windows · SQL Server licensing','green',7)}
${B(460,128,230,40,'Host Maintenance','Scheduled by AWS or you','teal',7)}
${A(440,75,460,60,'#806000')}${A(440,102,460,104,'#806000')}${A(440,128,460,148,'#806000')}
${N(20,210,'SE: Physical isolation (HIPAA, PCI-DSS) · CO: BYOL reduces cost · OE: Host resource groups auto-place')}
`,225),

  // ── GCP ──
  gcp_ce: ()=>SVG(`
${B(20,24,130,36,'Internet','','gray',7)}
${B(20,68,130,36,'Cloud Load Balancing','Global or Regional','blue',7)}
${A(85,60,85,68,'#1a73e8')}${A(85,104,85,115,'#1a73e8')}
${B(20,115,130,36,'Firewall Rules / Cloud Armor','VPC-level security','red',7)}
${A(85,151,85,162,'#1a73e8')}
${B(20,162,340,78,'Zone us-central1-a','','blue')}
${B(30,178,145,50,'GCE Instance','n2-standard-4 · SSD PD','blue',7)}
${B(185,178,160,50,'Service Account','Least-privilege + Workload ID','green',7)}
${B(370,162,340,78,'Zone us-central1-b','','teal')}
${B(380,178,145,50,'GCE Instance','Snapshot-based clone','teal',7)}
${B(535,178,160,50,'OS Login + IAP','No public IP / no SSH key','blue',7)}
${A(175,203,185,203,'#107c10')}${A(360,203,380,203,'#00b4d8')}
${N(20,258,'RE: Multi-zone · SE: Service account + IAP · CO: Committed use · PE: Tier_1 networking · OE: Ops Agent')}
`,270),

  gcp_mig: ()=>SVG(`
${B(20,40,155,40,'Cloud Load Balancing','Health checks distribute traffic','blue',7)}
${A(97,80,97,105,'#1a73e8')}
${B(20,105,590,130,'Managed Instance Group — Min 2 · Target 4 · Max 20','','blue')}
${B(30,125,130,42,'GCE Instance','zone a','blue',7)}
${B(170,125,130,42,'GCE Instance','zone b','blue',7)}
${B(310,125,130,42,'GCE Instance','zone c','blue',7)}
${B(450,125,145,42,'→ scale out','on metric','teal',7)}
${A(97,235,97,255,'#107c10')}
${B(20,255,175,38,'Autoscaling policy','CPU · HTTP LB · custom metric','green',7)}
${B(205,255,200,38,'Instance Template','Image · type · SA · metadata','blue',7)}
${B(415,255,195,38,'Cloud Monitoring','Alerts → autoscale → notify','amber',7)}
${N(20,308,'RE: Regional MIG spans 3 zones · CO: Spot VM instances in MIG · PE: Compact placement · OE: Rolling update')}
`,320),

  gcp_iap: ()=>SVG(`
${B(20,80,130,44,'Admin','Browser or gcloud CLI','gray')}
${A(150,102,225,102,'#0891b2')}
${B(225,60,175,84,'Identity-Aware Proxy','BeyondCorp · context-aware','teal')}
${A(400,80,475,65,'#107c10')}${A(400,102,475,102,'#1a73e8')}
${B(475,48,200,40,'GCE (no public IP)','SSH tunnelled via IAP','green',7)}
${B(475,96,200,40,'Internal web app','HTTP via IAP connector','blue',7)}
${B(225,165,390,44,'VPC — No public IP on VMs · Firewall denies direct SSH/RDP','','red')}
${N(20,228,'SE: Zero open ports · Google-verified identity checks · OE: Access Context Manager for policy · RE: GCP HA')}
`,240),

  gcp_backup: ()=>SVG(`
${B(20,70,145,44,'GCE / GKE / AlloyDB','Any disk or DB','gray')}
${A(165,92,240,92,'#1565c0')}
${B(240,52,200,80,'Cloud Backup and DR','Centralised — app-consistent','blue')}
${A(440,70,515,55,'#1565c0')}${A(440,92,515,92,'#1565c0')}${A(440,114,515,128,'#1565c0')}
${B(515,38,200,40,'Backup plan','Schedule · retention · window','blue',7)}
${B(515,82,200,40,'Multi-region vault','Cross-region recovery','teal',7)}
${B(515,126,200,40,'App-consistent','Agent-based VSS','green',7)}
${N(20,210,'RE: Cross-region · SE: CMEK-encrypted vault · CO: Coldline storage tier · OE: Centralised backup console')}
`,225),

  gcp_clouddr: ()=>SVG(`
${B(20,65,160,44,'Source','On-prem · GCE · AWS','gray')}
${A(180,87,245,87,'#1060b0')}
${B(245,50,190,74,'Cloud Backup and DR','Continuous replication','blue')}
${A(435,72,510,58,'#1060b0')}${A(435,87,510,87,'#1060b0')}
${B(510,40,200,40,'Journal-based replication','Near-zero RPO','blue',7)}
${B(510,84,200,40,'DR testing','Non-disruptive rehearsal','green',7)}
${B(510,128,200,40,'Instant recovery','Mount from journal','teal',7)}
${N(20,200,'RE: RPO minutes · RTO minutes · CO: Pay for journal storage only · OE: Automated DR runbooks')}
`,215),

  gcp_migrate: ()=>SVG(`
${B(20,75,150,44,'Source','VMware · AWS · Azure · Hyper-V','gray')}
${A(170,97,240,97,'#1a73e8')}
${B(240,55,200,84,'Migrate to VMs','Automated lift-and-shift','blue')}
${A(440,75,515,58,'#1a73e8')}${A(440,97,515,97,'#1a73e8')}${A(440,120,515,135,'#1a73e8')}
${B(515,40,200,38,'Fit assessment','Right-size + compatibility','blue',7)}
${B(515,82,200,38,'Streaming migration','No downtime copy','green',7)}
${B(515,124,200,38,'Cutover','DNS swap — minutes','teal',7)}
${N(20,205,'OE: Automation via runbook · CO: Rightsizing recommendations · RE: Test clone before cutover')}
`,218),

  gcp_spot: ()=>SVG(`
${B(20,80,145,44,'Workload','Batch · ML · Rendering · Dataflow','gray')}
${A(165,102,240,102,'#0369a1')}
${B(240,62,195,80,'GCP Spot VMs','Up to 91% discount','blue')}
${B(460,42,230,40,'24h max run time','Preemptible policy','blue',7)}
${B(460,86,230,40,'Preemption notice','30-second shutdown script','teal',7)}
${B(460,130,230,40,'MIG with Spot','Mix Spot + Standard in MIG','green',7)}
${A(435,82,460,62,'#0369a1')}${A(435,102,460,106,'#0369a1')}${A(435,122,460,150,'#0369a1')}
${N(20,210,'CO: Up to 91% savings · RE: Checkpoint jobs · design stateless · OE: MIG auto-replaces preempted VMs')}
`,225),

  gcp_soletenant: ()=>SVG(`
${B(20,80,145,44,'Organisation','Compliance · BYOL · Licensing','gray')}
${A(165,102,240,102,'#0d47a1')}
${B(240,55,200,94,'Sole-Tenant Nodes','Physical node for one project','blue')}
${B(460,40,230,40,'Node template','Machine family · affinity','blue',7)}
${B(460,84,230,40,'BYOL','Windows Server · SQL licensing','green',7)}
${B(460,128,230,40,'Node groups','Manage fleet of nodes','teal',7)}
${A(440,75,460,60,'#0d47a1')}${A(440,102,460,104,'#0d47a1')}${A(440,128,460,148,'#0d47a1')}
${N(20,210,'SE: Physical isolation (PCI, HIPAA) · CO: BYOL + committed use · OE: Node group auto-repair')}
`,225),
};

// ── WAF PILLAR BADGE HELPER (used in feature lists) ────────────
// RE=Reliability SE=Security CO=Cost PE=Performance OE=Operations
const P = (p,txt) => `<span style="display:inline-block;background:${
  {RE:'#e8f5e8',SE:'#fce8e9',CO:'#fff8ed',PE:'#ebf4fc',OE:'#f3e8fd'}[p]
};color:${
  {RE:'#0a5007',SE:'#6b0c0e',CO:'#5a3000',PE:'#004578',OE:'#4a1580'}[p]
};border-radius:4px;padding:1px 6px;font-size:10px;font-weight:700;margin-right:4px">${p}</span>${txt}`;

// ── SERVICE CATALOGUE ─────────────────────────────────────────
const SVC = {
  // ── AZURE ──
  azure_vm: {
    cl:'azure',ic:'🖥️',nm:'Azure Virtual Machines',
    tl:'IaaS · Windows & Linux · 600+ SKUs · Availability Zones',
    tg:['IaaS','Multi-OS','Availability Zones'],
    ds:'Azure IaaS compute foundation. Choose from 600+ VM sizes across General Purpose, Compute, Memory, Storage, GPU, and HPC families. Deploy into Availability Zones for 99.99% SLA.',
    dk:'azure_vm',
    ft:[
      P('RE','Availability Zones — 99.99% SLA when deployed across 2+ zones'),
      P('RE','Azure Load Balancer / App Gateway for traffic distribution'),
      P('SE','Azure Defender for Servers — threat detection & vulnerability'),
      P('SE','Managed Identity — no stored credentials in app code'),
      P('SE','Disk encryption at rest (SSE + ADE) · NSG for traffic control'),
      P('CO','Reserved Instances (1yr/3yr) — up to 72% savings'),
      P('CO','Right-size advisor in Azure Advisor · Hybrid Benefit (BYOL)'),
      P('PE','Accelerated Networking — up to 100 Gbps · Ultra Disk <1ms'),
      P('PE','Proximity Placement Groups for low-latency clusters'),
      P('OE','Azure Monitor + VM Insights · Auto-patching · Azure Policy'),
    ],
    uw:['Lift-and-shift workloads','SQL Server on Windows VMs','High-performance computing','Legacy apps needing full OS control','SAP on Azure'],
    nf:'Stateless web apps (use App Service / Container Apps), managed SQL (use Azure SQL).',
    nt:'💡 Always deploy across 2+ Availability Zones and use Azure Backup. Enable Defender for Servers from day 1.',
    doc:'https://learn.microsoft.com/en-us/azure/virtual-machines/'
  },
  azure_vmss: {
    cl:'azure',ic:'📈',nm:'VM Scale Sets',
    tl:'Auto-scale · Rolling upgrades · KEDA-like custom metrics · Zone-redundant',
    tg:['Auto-scale','IaaS','Zone-redundant'],
    ds:'Automatically scale identical VM instances based on demand. Supports rolling, blue-green, and canary upgrade policies. Integrates with Azure Load Balancer and Application Gateway.',
    dk:'azure_vmss',
    ft:[
      P('RE','Zone-redundant VMSS spans 3 AZs — survives full zone failure'),
      P('RE','Health probes auto-replace unhealthy instances'),
      P('CO','Scale in during off-peak — pay only for running VMs'),
      P('CO','Spot + On-Demand mixed mode — up to 90% savings on burst capacity'),
      P('PE','Accelerated Networking on all instances by default'),
      P('PE','Custom metric autoscale (queue depth, HTTP latency)'),
      P('SE','Managed Identity on all instances simultaneously'),
      P('OE','Rolling upgrade policy — zero-downtime OS updates'),
      P('OE','Automatic OS image upgrades · Azure Monitor integration'),
    ],
    uw:['Web tiers needing elastic scale','Stateless microservice backends','HPC burst workloads','CI/CD build agents that scale to zero'],
    nf:'Stateful single-instance apps (use VM + Azure Backup), containers (use Container Apps / AKS).',
    nt:null,
    doc:'https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/'
  },
  azure_bastion: {
    cl:'azure',ic:'🔒',nm:'Azure Bastion',
    tl:'Browser-based RDP/SSH · No public IP on VM · PaaS · Zone-redundant',
    tg:['Security','Zero public IP','PaaS'],
    ds:'Fully managed PaaS that provides secure RDP and SSH access to VMs over TLS from your browser — no public IP, no jump server, no open RDP/SSH ports.',
    dk:'azure_bastion',
    ft:[
      P('SE','No public IP required on target VMs — port 3389/22 never exposed'),
      P('SE','All traffic over port 443 HTTPS — TLS encrypted'),
      P('SE','Azure AD authentication + conditional access support'),
      P('SE','Session recording (Premium SKU) · Shareable links'),
      P('RE','Zone-redundant Standard SKU — survives zone failure'),
      P('OE','No jump-box AMI to patch or rotate — fully managed'),
      P('OE','Integrates with Azure Monitor for connection audit logs'),
      P('CO','Basic SKU for dev/test · Standard for prod features'),
    ],
    uw:['Production VMs with no public IP','Compliance environments (no RDP internet exposure)','Multi-VM administration without jump host','Emergency break-glass access'],
    nf:'Dev/test VMs you need to expose publicly (reconsider), VPN-connected networks (use existing VPN).',
    nt:'💡 Pair with NSG rules that explicitly deny RDP/SSH from internet — defense in depth.',
    doc:'https://learn.microsoft.com/en-us/azure/bastion/'
  },
  azure_backup: {
    cl:'azure',ic:'💾',nm:'Azure Backup',
    tl:'App-consistent snapshots · GRS vault · Soft-delete · Immutable vault',
    tg:['Backup','Reliability','Ransomware protection'],
    ds:'Cloud-native backup for Azure VMs, disks, SQL, SAP HANA, files, and blobs. Immutable vaults and soft-delete protect against ransomware. Cross-region restore for DR.',
    dk:'azure_backup',
    ft:[
      P('RE','App-consistent snapshots — guaranteed crash-consistent recovery'),
      P('RE','Cross-region restore — recover in secondary region in minutes'),
      P('SE','Immutable vault — even admins cannot delete backups'),
      P('SE','Soft delete 14 days — accidental deletion protection'),
      P('SE','Encryption at rest (platform or BYOK)'),
      P('CO','Vault-Standard tier vs Archive tier — 70% cheaper for old backups'),
      P('CO','Enhanced policy — hourly backup for low RPO without extra cost'),
      P('OE','Backup Centre — single pane across all subscriptions'),
      P('OE','Azure Policy — enforce backup on all VMs automatically'),
    ],
    uw:['VM disaster recovery & compliance','SQL Server on Azure VM backup','SAP HANA backup','Ransomware recovery strategy'],
    nf:'File-level sync (use Azure File Sync), database-level backup (use service-native backup + Backup vault).',
    nt:'⚠️ Enable immutable vault and soft-delete on day 1. Ransomware attacks target backups first.',
    doc:'https://learn.microsoft.com/en-us/azure/backup/'
  },
  azure_asr: {
    cl:'azure',ic:'🔄',nm:'Azure Site Recovery',
    tl:'Replication · Failover · Failback · RPO <1 min · RTO <15 min',
    tg:['Disaster Recovery','Replication','Business Continuity'],
    ds:'Business continuity and disaster recovery for Azure VMs, on-premises VMs, and physical servers. Continuous replication with RPO under 1 minute and orchestrated failover.',
    dk:'azure_asr',
    ft:[
      P('RE','RPO < 1 minute · RTO < 15 minutes with recovery plans'),
      P('RE','Automatic failover + failback — full orchestration'),
      P('RE','Recovery plans with pre/post scripts (Azure Automation)'),
      P('SE','Replicated data encrypted in transit and at rest'),
      P('CO','Pay only for replication storage — not full replica VMs'),
      P('CO','Test failover in isolated network — no production impact cost'),
      P('OE','Non-disruptive DR drills — test without disrupting production'),
      P('OE','Replication health monitoring in Azure Monitor'),
    ],
    uw:['Mission-critical VMs requiring DR','Regulatory compliance needing DR documentation','On-premises to Azure DR (Hyper-V · VMware)','Multi-region Azure VM DR'],
    nf:'Backup (different from DR — use Azure Backup for point-in-time recovery).',
    nt:'💡 Always test your recovery plan quarterly. An untested DR plan is not a DR plan.',
    doc:'https://learn.microsoft.com/en-us/azure/site-recovery/'
  },
  azure_migrate: {
    cl:'azure',ic:'✈️',nm:'Azure Migrate',
    tl:'Discover · Assess · Migrate · VMware · Hyper-V · Physical · AWS · GCP',
    tg:['Migration','Assessment','Lift-and-shift'],
    ds:'Unified hub for discovering, assessing, and migrating on-premises workloads to Azure. Dependency mapping, right-size recommendations, and TCO calculator included.',
    dk:'azure_migrate',
    ft:[
      P('CO','TCO calculator — quantify on-premises vs Azure cost'),
      P('CO','Right-size recommendations from performance data'),
      P('RE','Test migration before cutover — validation in parallel'),
      P('SE','Migrate without opening inbound ports — agent pushes to Azure'),
      P('OE','Dependency mapping — understand app dependencies before migration'),
      P('OE','Migration waves — group workloads for phased migration'),
      P('OE','Azure Monitor readiness assessment post-migration'),
    ],
    uw:['VMware vCenter migrations','Hyper-V migrations','Physical server migrations','AWS/GCP to Azure migrations','Datacenter consolidation'],
    nf:'Already in Azure (use ASR for region-to-region), app modernisation (use Azure App Service migration assistant).',
    nt:null,
    doc:'https://learn.microsoft.com/en-us/azure/migrate/'
  },
  azure_spot: {
    cl:'azure',ic:'⚡',nm:'Azure Spot VMs',
    tl:'Up to 90% discount · Evictable · Fault-tolerant workloads only',
    tg:['Cost Optimisation','Spot','Batch'],
    ds:'Azure Spot VMs use spare capacity at up to 90% discount. Azure can evict them with 30 seconds notice when capacity is needed. Design workloads to be stateless and checkpoint-aware.',
    dk:'azure_spot',
    ft:[
      P('CO','Up to 90% savings vs pay-as-you-go pricing'),
      P('CO','VMSS mixed mode — Spot for burst, on-demand for baseline'),
      P('RE','Checkpoint state frequently — eviction can happen any time'),
      P('RE','Eviction policy: Deallocate (preserves disk) or Delete'),
      P('OE','Azure Spot Instance Advisor — shows eviction frequency by region/SKU'),
      P('PE','Same hardware as regular VMs — identical performance'),
    ],
    uw:['Batch processing and ETL','ML model training','CI/CD build agents','Rendering and simulation','Dev/test environments'],
    nf:'Production databases, stateful apps, or anything that cannot tolerate interruption.',
    nt:'⚠️ Design for eviction: use checkpointing, stateless patterns, and always test eviction handling.',
    doc:'https://learn.microsoft.com/en-us/azure/virtual-machines/spot-vms'
  },
  azure_dedicated: {
    cl:'azure',ic:'🏢',nm:'Azure Dedicated Host',
    tl:'Physical server isolation · BYOL · Maintenance control · Compliance',
    tg:['Dedicated','Compliance','BYOL'],
    ds:'A physical server in an Azure datacenter dedicated to your organisation. Full hardware isolation for compliance. Bring your own Windows Server and SQL Server licenses.',
    dk:'azure_dedicated',
    ft:[
      P('SE','Physical isolation — no other customer VMs on same hardware'),
      P('SE','Meets PCI-DSS, HIPAA, HITRUST hardware isolation requirements'),
      P('CO','BYOL Windows Server / SQL Server — up to 40% savings'),
      P('CO','Azure Hybrid Benefit combined with Dedicated Host'),
      P('RE','Host group with fault domain spreading for HA'),
      P('OE','Maintenance control — choose your own maintenance window'),
      P('OE','Auto-replace host on hardware failure (with restart)'),
    ],
    uw:['PCI-DSS or HIPAA requiring physical isolation','Windows Server licensing on existing agreements','SQL Server per-core licensing optimisation','Compliance audits requiring hardware attestation'],
    nf:'Standard multi-tenant workloads (unnecessary overhead + cost), containers (use AKS).',
    nt:null,
    doc:'https://learn.microsoft.com/en-us/azure/virtual-machines/dedicated-hosts'
  },
  // ── AWS ──
  aws_ec2: {
    cl:'aws',ic:'🖥️',nm:'Amazon EC2',
    tl:'IaaS · 750+ instance types · Multi-AZ · Graviton · Intel · AMD',
    tg:['IaaS','Multi-AZ','Multi-architecture'],
    ds:'AWS IaaS compute foundation. 750+ instance types across General Purpose, Compute, Memory, Storage, GPU, HPC, and Graviton (ARM) families. Deploy across multiple AZs for high availability.',
    dk:'aws_ec2',
    ft:[
      P('RE','Multi-AZ — deploy across 3 AZs for resilience · ELB health checks'),
      P('RE','Auto Recovery — auto-restart on host hardware failure'),
      P('SE','IAM instance profiles — no access keys stored on instance'),
      P('SE','Security Groups — stateful firewall · SSM instead of port 22'),
      P('SE','IMDSv2 — mandatory metadata service hardening'),
      P('CO','Savings Plans — up to 72% · Reserved Instances · Compute Optimizer'),
      P('CO','Graviton3 instances — 40% better price-performance than x86'),
      P('PE','Enhanced Networking (ENA) · Elastic Fabric Adapter for HPC'),
      P('PE','Nitro System — bare-metal performance with hypervisor security'),
      P('OE','EC2 Image Builder · Systems Manager Patch Manager · CloudWatch'),
    ],
    uw:['Lift-and-shift from on-premises','SQL Server / Oracle on managed infra','High-performance computing','GPU workloads (ML training, rendering)','Legacy apps needing full OS control'],
    nf:'Stateless web apps (use Lambda/App Runner/ECS), managed DB (use RDS/Aurora).',
    nt:'💡 Use IMDSv2, SSM Session Manager (not SSH), and IAM instance profiles on every EC2 instance.',
    doc:'https://docs.aws.amazon.com/ec2/'
  },
  aws_asg: {
    cl:'aws',ic:'📈',nm:'Auto Scaling Groups',
    tl:'Auto-scale EC2 · Multi-AZ · Target tracking · Predictive scaling',
    tg:['Auto-scale','IaaS','Multi-AZ'],
    ds:'Automatically scale EC2 instances based on demand. Maintain minimum healthy instances across AZs. Supports target tracking, step, scheduled, and predictive scaling policies.',
    dk:'aws_asg',
    ft:[
      P('RE','Minimum capacity across AZs — always healthy even during AZ failure'),
      P('RE','Health check integration — auto-replace unhealthy instances'),
      P('CO','Spot + On-Demand mixed fleet — Spot for up to 90% savings'),
      P('CO','Predictive scaling — scale before demand peak, no idle cost'),
      P('PE','Warm pools — pre-warm instances to eliminate scale-out latency'),
      P('PE','Instance Refresh — rolling replacement with configurable health wait'),
      P('SE','Launch Templates enforce IMDSv2 and security settings'),
      P('OE','Lifecycle hooks — run scripts on launch and terminate'),
      P('OE','CloudWatch alarms trigger scaling — custom metrics supported'),
    ],
    uw:['Web application tiers with variable load','Stateless microservice backends','Scheduled batch workload scale-out','CI/CD build farm that scales to zero'],
    nf:'Stateful workloads (add persistence layer), containers (use ECS/EKS with Fargate).',
    nt:null,
    doc:'https://docs.aws.amazon.com/autoscaling/ec2/'
  },
  aws_ssm: {
    cl:'aws',ic:'🔒',nm:'AWS Systems Manager',
    tl:'Session Manager · Patch Manager · Run Command · No port 22 needed',
    tg:['Security','Operations','No SSH'],
    ds:'Unified operations hub for EC2 and on-premises servers. Session Manager provides browser-based shell access without opening port 22. Patch Manager automates OS patching.',
    dk:'aws_ssm',
    ft:[
      P('SE','Session Manager — zero open inbound ports, no SSH keys to rotate'),
      P('SE','All sessions logged to CloudWatch + S3 for audit'),
      P('SE','IAM-controlled access — not network-based'),
      P('OE','Patch Manager — automated OS patching with maintenance windows'),
      P('OE','Run Command — execute scripts across fleet without SSH'),
      P('OE','Parameter Store — secure config and secrets distribution'),
      P('RE','Works on private subnets via VPC endpoints — no internet needed'),
      P('CO','No bastion host EC2 to maintain — fully managed'),
    ],
    uw:['Eliminating SSH/RDP attack surface','Fleet-wide OS patching at scale','Break-glass access to private instances','Distributing config to EC2 fleet','Hybrid on-premises server management'],
    nf:'Full interactive desktop session (use DCV/AppStream), VPN-less network access (use Client VPN).',
    nt:'💡 Mandate IAM policy requiring SSM Session Manager — deny ec2:AuthorizeSecurityGroupIngress for port 22.',
    doc:'https://docs.aws.amazon.com/systems-manager/'
  },
  aws_backup: {
    cl:'aws',ic:'💾',nm:'AWS Backup',
    tl:'Centralised backup · Cross-region · Vault Lock (WORM) · Multi-service',
    tg:['Backup','Reliability','WORM'],
    ds:'Centralised, policy-driven backup service for EC2, EBS, RDS, DynamoDB, EFS, FSx, and more. Vault Lock provides WORM protection against ransomware and accidental deletion.',
    dk:'aws_backup',
    ft:[
      P('RE','Cross-region backup copies — recover in another region after disaster'),
      P('RE','Cross-account backup — isolated recovery account'),
      P('SE','Backup Vault Lock (WORM) — even account root cannot delete'),
      P('SE','KMS encryption — AWS-managed or CMK'),
      P('CO','Cold tier — 50% cheaper for backups older than 90 days'),
      P('CO','Organisation-wide policies — single policy covers all accounts'),
      P('OE','Backup audit manager — compliance reports for auditors'),
      P('OE','Tag-based backup plans — auto-backup any new resource with tag'),
    ],
    uw:['EC2 + EBS consistent backup','Cross-account DR isolation','Ransomware recovery posture','Compliance reporting (PCI, HIPAA)','Multi-service backup consolidation'],
    nf:'Database-native features you need (use RDS automated backups + snapshots in addition).',
    nt:'⚠️ Enable Backup Vault Lock immediately — it has a 72-hour cooling-off period before becoming immutable.',
    doc:'https://docs.aws.amazon.com/aws-backup/'
  },
  aws_drs: {
    cl:'aws',ic:'🔄',nm:'AWS Elastic Disaster Recovery',
    tl:'Continuous replication · RPO seconds · RTO minutes · Source-agnostic',
    tg:['Disaster Recovery','Replication','Cross-cloud'],
    ds:'Continuous block-level replication for on-premises, AWS, and multi-cloud servers. Minimal RPO (seconds) and rapid RTO (minutes). Low-cost staging area with full instances only at failover.',
    dk:'aws_drs',
    ft:[
      P('RE','RPO in seconds — continuous block-level replication'),
      P('RE','RTO in minutes — launch recovery instances on demand'),
      P('RE','Automated failback — reverse-replicate back to source'),
      P('CO','Staging area = low-cost t3.micro — full VMs only on failover'),
      P('CO','No upfront commitment — pay only for replication storage'),
      P('SE','Replication encrypted in transit (TLS) and at rest (KMS)'),
      P('OE','Non-disruptive DR drills — test without stopping production'),
      P('OE','Recovery instance blueprints — define target subnet, SG, IAM'),
    ],
    uw:['On-premises to AWS disaster recovery','Cross-region AWS DR','Multi-cloud DR (Azure/GCP → AWS)','Replacing physical DR site with cloud'],
    nf:'Backup (different from DR — use AWS Backup for point-in-time recovery).',
    nt:'💡 Run DR drills quarterly. DRS drill mode launches instances in isolated VPC — zero production impact.',
    doc:'https://docs.aws.amazon.com/drs/'
  },
  aws_ams: {
    cl:'aws',ic:'✈️',nm:'AWS Application Migration Service',
    tl:'Lift-and-shift · Continuous replication · Test before cutover · Free',
    tg:['Migration','Lift-and-shift','Replication'],
    ds:'AWS-recommended service for lift-and-shift migration. Installs a lightweight agent that continuously replicates servers to AWS. Free to use — pay only for EC2 at cutover.',
    dk:'aws_ams',
    ft:[
      P('CO','MGN itself is free — only pay for EC2/EBS during testing and production'),
      P('CO','Compute Optimizer recommendations after migration for right-sizing'),
      P('RE','Continuous replication — cutover window measured in minutes'),
      P('RE','Launch test instances as many times as needed before cutover'),
      P('OE','Migration dashboard — track all servers across migration waves'),
      P('OE','Post-launch actions — run scripts after instance starts'),
      P('SE','Replication over TLS — no sensitive data in transit unencrypted'),
    ],
    uw:['VMware / Hyper-V / physical server migrations','Cross-cloud migrations (Azure → AWS, GCP → AWS)','Replacing legacy DR site with AWS','Regional migrations within AWS'],
    nf:'Database migrations (use AWS DMS), app modernisation (use refactoring tools).',
    nt:null,
    doc:'https://docs.aws.amazon.com/mgn/'
  },
  aws_spot: {
    cl:'aws',ic:'⚡',nm:'EC2 Spot Instances',
    tl:'Up to 90% discount · Interruption notice 2 min · Fault-tolerant only',
    tg:['Cost Optimisation','Spot','Batch'],
    ds:'Spare EC2 capacity at up to 90% discount. AWS gives 2-minute interruption notice. Use Spot Instance Advisor to choose instance types with lowest interruption frequency.',
    dk:'aws_spot',
    ft:[
      P('CO','Up to 90% savings vs On-Demand — largest cost lever in AWS'),
      P('CO','EC2 Fleet / ASG mixed policy — Spot for cost, On-Demand for reliability'),
      P('RE','2-minute interruption notice — sufficient for checkpointing'),
      P('RE','Spot Instance Advisor — pick pools with <5% interruption frequency'),
      P('PE','Same underlying hardware as On-Demand instances'),
      P('OE','EC2 Fleet — diversify across instance types and AZs automatically'),
      P('OE','Spot placement score — find best region for availability'),
    ],
    uw:['Big data and analytics (EMR)','ML training jobs (SageMaker + Spot)','CI/CD build farms','Batch processing and rendering','Containerised fault-tolerant workloads (EKS Spot)'],
    nf:'Databases, stateful apps, anything requiring guaranteed availability.',
    nt:'⚠️ Diversify across instance types and AZs — never depend on a single Spot pool.',
    doc:'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-spot-instances.html'
  },
  aws_dedicated: {
    cl:'aws',ic:'🏢',nm:'EC2 Dedicated Hosts',
    tl:'Physical server isolation · BYOL · Compliance · License optimisation',
    tg:['Dedicated','Compliance','BYOL'],
    ds:'EC2 Dedicated Hosts provide a physical server fully dedicated to your use. Socket and core visibility for BYOL licensing. Required for some compliance frameworks needing hardware isolation.',
    dk:'aws_dedicated',
    ft:[
      P('SE','Physical isolation — no other AWS accounts share the host hardware'),
      P('SE','Meets PCI-DSS, HIPAA, FedRAMP hardware isolation controls'),
      P('CO','BYOL Windows Server / SQL Server per-socket or per-core'),
      P('CO','Dedicated Host Reservations — up to 70% vs On-Demand Dedicated'),
      P('RE','Host resource groups — auto-place instances across pool of hosts'),
      P('OE','Host maintenance notification — AWS notifies before maintenance'),
      P('OE','Auto-placement — AWS selects host with sufficient capacity'),
    ],
    uw:['SQL Server / Windows Server BYOL licensing','PCI-DSS or HIPAA hardware isolation requirement','Government compliance needing single-tenancy','Existing enterprise license agreement optimisation'],
    nf:'Standard multi-tenant workloads, containers (no BYOL benefit).',
    nt:null,
    doc:'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/dedicated-hosts-overview.html'
  },
  // ── GCP ──
  gcp_ce: {
    cl:'gcp',ic:'🖥️',nm:'Compute Engine',
    tl:'IaaS · 50+ machine families · Custom VMs · Spot · Committed use',
    tg:['IaaS','Custom VM','Committed use'],
    ds:'GCPs IaaS compute. 50+ predefined machine families plus custom machine types (any vCPU/memory combination). Deploy into zones for HA. Unique: live migration preserves VMs during host maintenance.',
    dk:'gcp_ce',
    ft:[
      P('RE','Multi-zone deployment — managed instance groups span 3 zones'),
      P('RE','Live migration — VMs survive host maintenance without restart'),
      P('SE','OS Login — IAM-based SSH, no SSH keys to distribute'),
      P('SE','Shielded VMs — Secure Boot + vTPM + Integrity Monitoring'),
      P('SE','Confidential VMs — memory encryption (AMD SEV)'),
      P('CO','Committed use discounts — 1yr (37%) or 3yr (55%) savings'),
      P('CO','Custom machine types — right-size precisely, no wasted resources'),
      P('PE','Tier_1 networking — up to 200 Gbps · Hyperdisk for storage'),
      P('OE','Ops Agent — unified metrics + logs · Cloud Monitoring integration'),
    ],
    uw:['Lift-and-shift from on-premises','Windows Server / SQL Server','SAP HANA certified instances','ML training with A100/H100 GPUs','Custom workloads needing precise resource sizing'],
    nf:'Stateless web apps (use Cloud Run / App Engine), managed DB (use Cloud SQL / AlloyDB).',
    nt:'💡 Enable OS Login, Shielded VM, and Confidential Computing for defence-in-depth on sensitive workloads.',
    doc:'https://cloud.google.com/compute/docs'
  },
  gcp_mig: {
    cl:'gcp',ic:'📈',nm:'Managed Instance Groups',
    tl:'Auto-scale · Regional (3 zones) · Rolling updates · Autohealing',
    tg:['Auto-scale','IaaS','Regional'],
    ds:'GCPs equivalent of ASG/VMSS. Regional MIGs span 3 zones automatically for HA. Autoscaling based on CPU, HTTP load balancing capacity, or custom Pub/Sub metrics. Stateful MIGs for databases.',
    dk:'gcp_mig',
    ft:[
      P('RE','Regional MIG — distributes across 3 zones automatically'),
      P('RE','Autohealing — health checks detect and replace failed instances'),
      P('CO','Spot VM support in MIG — mix Spot and Standard instances'),
      P('CO','Autoscaling scale-in — remove idle instances automatically'),
      P('PE','Autoscaling on custom Pub/Sub metric (e.g. queue depth)'),
      P('PE','Compact placement policy — low-latency tightly-coupled clusters'),
      P('SE','Instance template enforces SA and shielded VM for all instances'),
      P('OE','Rolling update — canary percentage-based rollout'),
      P('OE','Stateful MIG — preserve data disks + IPs on instance recreate'),
    ],
    uw:['Web tier auto-scaling','Stateless microservice backends','Batch processing with Spot VMs','Stateful MIG for clustered databases','GKE node pools under the hood'],
    nf:'Full Kubernetes control (use GKE), serverless (use Cloud Run).',
    nt:null,
    doc:'https://cloud.google.com/compute/docs/instance-groups'
  },
  gcp_iap: {
    cl:'gcp',ic:'🔒',nm:'Identity-Aware Proxy (IAP)',
    tl:'BeyondCorp · TCP tunnelling · No public IP · Context-aware access',
    tg:['Security','Zero Trust','No public IP'],
    ds:'GCPs BeyondCorp implementation. IAP TCP tunnelling provides SSH and RDP access to VMs with no public IP and no open firewall ports — identity and context verified at Google infrastructure level.',
    dk:'gcp_iap',
    ft:[
      P('SE','No public IP required — firewall blocks all external SSH/RDP'),
      P('SE','Google identity verification + MFA before any tunnel opens'),
      P('SE','Access Context Manager — enforce device trust, location, time'),
      P('SE','All tunnel traffic logged to Cloud Audit Logs'),
      P('RE','Managed by Google — no bastion to maintain or patch'),
      P('OE','Works with gcloud CLI and Cloud Shell — no VPN needed'),
      P('OE','IAP Desktop (Windows app) for RDP via IAP tunnel'),
      P('CO','No bastion VM cost — eliminates jump-host entirely'),
    ],
    uw:['GCE VMs with zero public IP','Internal web app access control without VPN','Compliance requiring verified-identity access','Dev/test environments with temporary access'],
    nf:'VPN-connected on-premises users (use Cloud VPN), pure internal traffic (no IAP needed).',
    nt:'💡 Combine IAP with OS Login + Shielded VMs for the strongest GCE security posture.',
    doc:'https://cloud.google.com/iap/docs'
  },
  gcp_backup: {
    cl:'gcp',ic:'💾',nm:'Cloud Backup and DR',
    tl:'App-consistent · Centralised · Multi-region · GCE · GKE · Databases',
    tg:['Backup','App-consistent','Multi-region'],
    ds:'GCPs managed backup service for Compute Engine, GKE, and databases. App-consistent backups via VSS agent. Centralised backup console across projects and regions.',
    dk:'gcp_backup',
    ft:[
      P('RE','App-consistent backups — crash-safe VSS-based snapshots'),
      P('RE','Cross-region backup copies — recover after regional outage'),
      P('SE','CMEK encryption — customer-managed keys for backup data'),
      P('SE','Backup vault — isolated storage with restricted delete'),
      P('CO','Coldline storage for older backups — 70% cheaper than Standard'),
      P('CO','Incremental-forever backups — only changed blocks after first full'),
      P('OE','Centralised backup jobs across all projects in one console'),
      P('OE','Backup plans with SLA monitoring — alerts on missed backups'),
    ],
    uw:['GCE VM consistent backup','GKE stateful workload backup','AlloyDB / Cloud SQL backup','Cross-region DR vault','Compliance backup retention (7yr)'],
    nf:'Simple disk snapshots only (use Persistent Disk snapshot schedules — cheaper).',
    nt:null,
    doc:'https://cloud.google.com/backup-disaster-recovery/docs'
  },
  gcp_clouddr: {
    cl:'gcp',ic:'🔄',nm:'Cloud Backup and DR — DR Mode',
    tl:'Journal-based replication · Near-zero RPO · Instant recovery · DR drills',
    tg:['Disaster Recovery','Replication','Near-zero RPO'],
    ds:'Cloud Backup and DR in disaster recovery mode provides journal-based continuous replication for near-zero RPO. Mount directly from journal for instant recovery without full restore.',
    dk:'gcp_clouddr',
    ft:[
      P('RE','Journal-based replication — RPO in minutes for any VM'),
      P('RE','Instant mount recovery — no full restore needed for RTO in minutes'),
      P('RE','Automated DR rehearsal — non-disruptive drill mode'),
      P('CO','Pay for journal storage — full VMs only launched at failover'),
      P('SE','Replicated data encrypted · isolated DR project'),
      P('OE','DR runbooks — automated recovery steps with notifications'),
      P('OE','RPO/RTO dashboards — prove compliance to auditors'),
    ],
    uw:['Mission-critical GCE VM protection','Cross-region DR for regulatory compliance','On-premises to GCP DR','Replacing physical DR appliances'],
    nf:'Point-in-time backup (use Cloud Backup snapshot schedule — simpler and cheaper).',
    nt:'💡 DR drills are non-disruptive — schedule them monthly, not just annually.',
    doc:'https://cloud.google.com/backup-disaster-recovery/docs'
  },
  gcp_migrate: {
    cl:'gcp',ic:'✈️',nm:'Migrate to Virtual Machines',
    tl:'VMware · AWS · Azure · Physical servers · Streaming migration',
    tg:['Migration','Lift-and-shift','Streaming'],
    ds:'GCPs lift-and-shift migration tool. Discovers, assesses, and migrates VMware, AWS, Azure, and physical servers to Compute Engine using streaming replication — no downtime during migration.',
    dk:'gcp_migrate',
    ft:[
      P('OE','Streaming migration — no long maintenance window required'),
      P('OE','Fit assessment — compatibility check and right-size before migration'),
      P('CO','Right-sizing recommendations from actual workload data'),
      P('CO','Migrate4Containers — modernise to containers during migration'),
      P('RE','Test clone — launch GCE clone without stopping source'),
      P('SE','No source VM credentials needed — agentless for VMware'),
      P('OE','Wave-based migration planning — group and sequence workloads'),
    ],
    uw:['VMware vSphere migrations','AWS EC2 to GCP migrations','Azure VM to GCP migrations','Physical server modernisation','Datacenter exit projects'],
    nf:'Database migrations (use Database Migration Service), app modernisation (use Migrate4Containers).',
    nt:null,
    doc:'https://cloud.google.com/migrate/virtual-machines/docs'
  },
  gcp_spot: {
    cl:'gcp',ic:'⚡',nm:'GCP Spot VMs',
    tl:'Up to 91% discount · Preemptible · 30-sec notice · Stateless only',
    tg:['Cost Optimisation','Spot','Batch'],
    ds:'GCP Spot VMs use excess capacity at up to 91% discount. GCP can reclaim them with 30-second notice. Previous name: Preemptible VMs. Available in MIGs for auto-replacement on preemption.',
    dk:'gcp_spot',
    ft:[
      P('CO','Up to 91% savings vs standard pricing — highest discount in GCP'),
      P('CO','Mix Spot and Standard in MIG — base capacity on-demand, burst on Spot'),
      P('RE','MIG auto-replaces preempted instances — transparent to workload'),
      P('RE','30-second preemption notice — checkpoint script on SIGTERM'),
      P('OE','MIG maintains target count — replaces Spot with Standard if no Spot available'),
      P('PE','Same hardware and network as standard VMs'),
    ],
    uw:['Batch data processing (Dataflow, Dataproc)','ML model training','Video transcoding','CI/CD build agents','Fault-tolerant containerised workloads (GKE Spot)'],
    nf:'Databases, stateful apps, guaranteed availability workloads.',
    nt:'⚠️ Use SIGTERM handler to checkpoint state — 30 seconds is sufficient for most batch jobs.',
    doc:'https://cloud.google.com/compute/docs/instances/spot'
  },
  gcp_soletenant: {
    cl:'gcp',ic:'🏢',nm:'Sole-Tenant Nodes',
    tl:'Physical server isolation · BYOL · Node groups · Compliance',
    tg:['Dedicated','Compliance','BYOL'],
    ds:'GCP Sole-Tenant Nodes provide a physical Compute Engine server dedicated to your project. Required for BYOL per-core Windows Server and SQL Server licensing. Node groups manage a fleet of sole-tenant nodes.',
    dk:'gcp_soletenant',
    ft:[
      P('SE','Physical isolation — no VMs from other GCP customers on node'),
      P('SE','Meets PCI-DSS, HIPAA, FedRAMP hardware isolation requirements'),
      P('CO','BYOL Windows Server / SQL Server per-socket or per-core licensing'),
      P('CO','Combine with committed use discounts for maximum savings'),
      P('RE','Node group affinity — place instances on same or different nodes'),
      P('OE','Node group auto-repair — GCP replaces failed nodes automatically'),
      P('OE','Maintenance policy — migrate VMs to other sole-tenant nodes'),
    ],
    uw:['Windows Server / SQL Server BYOL licensing','PCI-DSS or HIPAA hardware isolation','Government compliance single-tenancy','Existing enterprise license optimisation'],
    nf:'Standard multi-tenant workloads, GKE (node pools use shared nodes by default).',
    nt:null,
    doc:'https://cloud.google.com/compute/docs/nodes/sole-tenant-nodes'
  },
};

// ── DECISION TREES ────────────────────────────────────────────
const TREE = {
  azure: {
    root: {id:'q1',ey:'Step 1 of 4',q:'What is your primary VM infrastructure goal?',
      h:'WAF lens: each path leads to a recommendation grounded in Reliability, Security, Cost, Performance, or Operations.',
      two:false,
      opts:[
        {ic:'🖥️',lb:'Run a workload on a VM',ds:'Deploy Windows or Linux VMs for your application',cr:'Run VM workload',nx:'q2_run'},
        {ic:'📈',lb:'Scale VMs automatically',ds:'Handle variable demand — scale out and in based on metrics',cr:'Auto-scale',nx:'R_vmss'},
        {ic:'🔒',lb:'Secure access to VMs',ds:'RDP/SSH without opening ports to the internet',cr:'Secure access',nx:'R_bastion'},
        {ic:'💾',lb:'Protect VMs with backup or DR',ds:'Backup for recovery · Site Recovery for disaster recovery',cr:'Protect VMs',nx:'q2_protect'},
        {ic:'✈️',lb:'Migrate workloads to Azure',ds:'Lift-and-shift from on-premises, AWS, or GCP',cr:'Migration',nx:'R_migrate'},
        {ic:'⚡',lb:'Reduce VM cost significantly',ds:'Spot VMs, reserved instances, or right-sizing',cr:'Cost reduction',nx:'q2_cost'},
      ]},
    nodes: {
      q2_run: {id:'q2_run',ey:'Step 2 of 4',q:'Do you need full hardware isolation for compliance?',
        h:'Dedicated Hosts give physical server isolation for PCI-DSS, HIPAA, and BYOL licensing. Standard VMs share hardware with other tenants but are fully isolated at hypervisor level.',
        two:true,
        opts:[
          {ic:'🏢',lb:'Yes — compliance requires physical isolation',ds:'PCI-DSS · HIPAA · BYOL Windows/SQL Server',cr:'Physical isolation',nx:'R_dedicated'},
          {ic:'🖥️',lb:'No — standard multi-tenant is fine',ds:'Standard VMs with Availability Zones for HA',cr:'Standard VM',nx:'R_vm'},
        ]},
      q2_protect: {id:'q2_protect',ey:'Step 2 of 4',q:'Backup for recovery — or DR for failover?',
        h:'Azure Backup = point-in-time recovery (RPO hours). Azure Site Recovery = continuous replication for disaster recovery (RPO < 1 minute).',
        two:true,
        opts:[
          {ic:'💾',lb:'Backup — restore from a point in time',ds:'Daily snapshots · app-consistent · soft-delete',cr:'Backup',nx:'R_backup'},
          {ic:'🔄',lb:'DR — failover to another region if disaster strikes',ds:'Continuous replication · RPO < 1min · RTO < 15min',cr:'Disaster Recovery',nx:'R_asr'},
        ]},
      q2_cost: {id:'q2_cost',ey:'Step 2 of 4',q:'Can your workload tolerate interruption?',
        h:'Spot VMs save up to 90% but can be evicted. Reserved Instances commit to 1–3 years for 72% savings. Right-sizing (Advisor) reduces waste without any risk.',
        two:false,
        opts:[
          {ic:'⚡',lb:'Yes — batch, CI, ML, rendering',ds:'Spot VMs: up to 90% discount · design for eviction',cr:'Spot VMs',nx:'R_spot'},
          {ic:'🖥️',lb:'No — need guaranteed availability',ds:'Reserved Instances + right-sizing with Azure Advisor',cr:'Reserved/Right-size',nx:'R_vm'},
        ]},
    },
    results: {
      R_vm:       {k:'azure_vm',       w:'Azure Virtual Machines give you full IaaS control. Deploy across Availability Zones for 99.99% SLA. Enable Defender for Servers, use Managed Identity (not stored credentials), attach Azure Backup, and right-size using Azure Advisor. Enable Accelerated Networking for performance.'},
      R_vmss:     {k:'azure_vmss',     w:'VM Scale Sets automatically scale identical VMs based on CPU, memory, queue depth, or custom metrics. Use zone-redundant VMSS with a minimum of 2 instances across zones. Mix Spot and On-Demand instances for cost efficiency. Rolling upgrade policy gives zero-downtime updates.'},
      R_bastion:  {k:'azure_bastion',  w:'Azure Bastion provides browser-based RDP/SSH access over HTTPS — no public IP on your VMs, no port 3389/22 open. Pair with NSG rules that explicitly block RDP/SSH from the internet. Standard SKU is zone-redundant for HA.'},
      R_backup:   {k:'azure_backup',   w:'Azure Backup provides app-consistent daily snapshots stored in a Recovery Services Vault. Enable immutable vault and soft-delete on day 1 for ransomware protection. Use GRS vault for cross-region recovery. Backup Centre gives a single view across all subscriptions.'},
      R_asr:      {k:'azure_asr',      w:'Azure Site Recovery continuously replicates VMs to a secondary region with RPO under 1 minute. Recovery Plans orchestrate multi-VM failover with scripts. Run non-disruptive DR drills regularly — an untested DR plan is not a DR plan.'},
      R_migrate:  {k:'azure_migrate',  w:'Azure Migrate discovers and assesses on-premises VMware, Hyper-V, and physical servers. It maps dependencies, recommends right-sizes, and calculates TCO. Migrate in waves — test each wave before production cutover.'},
      R_spot:     {k:'azure_spot',     w:'Azure Spot VMs offer up to 90% savings for fault-tolerant workloads. Use VMSS mixed mode (Spot + On-Demand) so baseline stays on regular VMs. Design for eviction: checkpoint state, use stateless patterns, and set eviction policy to Deallocate (preserves disks).'},
      R_dedicated:{k:'azure_dedicated',w:'Azure Dedicated Host provides physical server isolation for compliance (PCI-DSS, HIPAA) and BYOL licensing for Windows Server / SQL Server. Use Host Groups with fault domain spreading. Maintenance control lets you choose your own patching window.'},
    },
  },
  aws: {
    root: {id:'q1',ey:'Step 1 of 4',q:'What is your primary EC2 infrastructure goal?',
      h:'WAF lens: each path leads to a recommendation grounded in Reliability, Security, Cost, Performance, or Operations.',
      two:false,
      opts:[
        {ic:'🖥️',lb:'Run a workload on EC2',ds:'Deploy Linux or Windows instances for your application',cr:'Run EC2 workload',nx:'q2_run'},
        {ic:'📈',lb:'Scale EC2 automatically',ds:'Handle variable demand with Auto Scaling Groups',cr:'Auto-scale',nx:'R_asg'},
        {ic:'🔒',lb:'Secure access — no open port 22',ds:'Session Manager, no SSH keys, private subnet only',cr:'Secure access',nx:'R_ssm'},
        {ic:'💾',lb:'Protect EC2 with backup or DR',ds:'AWS Backup for snapshots · Elastic DR for failover',cr:'Protect EC2',nx:'q2_protect'},
        {ic:'✈️',lb:'Migrate servers to AWS',ds:'Lift-and-shift from on-premises or other clouds',cr:'Migration',nx:'R_ams'},
        {ic:'⚡',lb:'Reduce EC2 cost significantly',ds:'Spot Instances, Savings Plans, or Graviton',cr:'Cost reduction',nx:'q2_cost'},
      ]},
    nodes: {
      q2_run: {id:'q2_run',ey:'Step 2 of 4',q:'Do you need physical server isolation for compliance?',
        h:'Dedicated Hosts give physical isolation for HIPAA, PCI-DSS, and BYOL licensing. Default multi-tenant EC2 is isolated at hypervisor level but shares physical hardware.',
        two:true,
        opts:[
          {ic:'🏢',lb:'Yes — physical isolation required',ds:'BYOL · PCI-DSS · HIPAA',cr:'Physical isolation',nx:'R_dedicated'},
          {ic:'🖥️',lb:'No — standard multi-tenant EC2',ds:'Multi-AZ + IAM profile + Security Groups',cr:'Standard EC2',nx:'R_ec2'},
        ]},
      q2_protect: {id:'q2_protect',ey:'Step 2 of 4',q:'Point-in-time backup — or continuous DR replication?',
        h:'AWS Backup = scheduled snapshots for recovery (RPO hours). Elastic Disaster Recovery = continuous block replication (RPO seconds).',
        two:true,
        opts:[
          {ic:'💾',lb:'Backup — restore from snapshot',ds:'Scheduled · cross-region · Vault Lock WORM',cr:'Backup',nx:'R_backup'},
          {ic:'🔄',lb:'DR — failover within minutes',ds:'Continuous replication · RPO seconds · RTO minutes',cr:'Disaster Recovery',nx:'R_drs'},
        ]},
      q2_cost: {id:'q2_cost',ey:'Step 2 of 4',q:'Can your workload tolerate interruption?',
        h:'Spot saves up to 90% for fault-tolerant jobs. Savings Plans commit for 1–3 years for 72% off. Graviton3 ARM gives 40% better price-performance.',
        two:false,
        opts:[
          {ic:'⚡',lb:'Yes — batch, ML, CI/CD, rendering',ds:'Spot Instances: up to 90% off · 2-min notice',cr:'Spot',nx:'R_spot'},
          {ic:'🖥️',lb:'No — need guaranteed availability',ds:'Savings Plans + Graviton + Compute Optimizer right-size',cr:'Savings Plans',nx:'R_ec2'},
        ]},
    },
    results: {
      R_ec2:      {k:'aws_ec2',      w:'Amazon EC2 is the AWS IaaS foundation. Deploy across multiple AZs. Use IAM instance profiles (not access keys), Security Groups (not open port 22 — use SSM), and Savings Plans for committed workloads. Graviton3 instances give 40% better price-performance for compatible workloads.'},
      R_asg:      {k:'aws_asg',      w:'Auto Scaling Groups maintain your target capacity across AZs. Set minimum=2 for HA. Use target tracking scaling (CPU 70%) for simplicity, warm pools to eliminate scale-out latency, and mixed Spot+On-Demand fleet for cost efficiency.'},
      R_ssm:      {k:'aws_ssm',      w:'AWS Systems Manager Session Manager eliminates the need for open port 22, SSH keys, and bastion hosts. Access is IAM-controlled and all sessions are logged to CloudWatch. Use VPC endpoints so traffic never leaves the AWS network. Patch Manager automates OS updates.'},
      R_backup:   {k:'aws_backup',   w:'AWS Backup provides centralised, policy-driven backup across EC2, EBS, RDS, and more. Enable Backup Vault Lock (WORM) immediately — it has a 72-hour cooling-off before it becomes immutable. Cross-account copies isolate your recovery backups from the production account.'},
      R_drs:      {k:'aws_drs',      w:'AWS Elastic Disaster Recovery provides continuous block-level replication with RPO in seconds. The staging area uses low-cost t3.micro instances — you only pay for full EC2 at failover. Run non-disruptive drills monthly using DRS drill mode.'},
      R_ams:      {k:'aws_ams',      w:'AWS Application Migration Service (MGN) is the recommended migration path. Install the lightweight agent, replicate continuously, launch test instances to validate, then cut over with a short maintenance window. MGN is free — you pay only for EC2/EBS during testing.'},
      R_spot:     {k:'aws_spot',     w:'EC2 Spot Instances offer up to 90% savings. Use EC2 Fleet or ASG mixed policy across multiple instance types and AZs — never depend on one Spot pool. Handle 2-minute interruption notice with a SIGTERM handler. Use Spot Instance Advisor to pick low-interruption pools.'},
      R_dedicated:{k:'aws_dedicated',w:'EC2 Dedicated Hosts provide physical server isolation for compliance and BYOL licensing for Windows Server / SQL Server per-socket or per-core. Use Host Resource Groups for automatic placement. Dedicated Host Reservations save up to 70% vs On-Demand Dedicated.'},
    },
  },
  gcp: {
    root: {id:'q1',ey:'Step 1 of 4',q:'What is your primary Compute Engine goal?',
      h:'WAF lens: each path leads to a recommendation grounded in Reliability, Security, Cost, Performance, or Operations.',
      two:false,
      opts:[
        {ic:'🖥️',lb:'Run a workload on a GCE VM',ds:'Deploy Linux or Windows VMs for your application',cr:'Run VM workload',nx:'q2_run'},
        {ic:'📈',lb:'Scale VMs automatically',ds:'Managed Instance Groups with autoscaling',cr:'Auto-scale',nx:'R_mig'},
        {ic:'🔒',lb:'Secure access — no public IP needed',ds:'IAP TCP tunnelling — BeyondCorp zero-trust access',cr:'Secure access',nx:'R_iap'},
        {ic:'💾',lb:'Protect VMs — backup or DR',ds:'Cloud Backup for snapshots · DR for failover',cr:'Protect VMs',nx:'q2_protect'},
        {ic:'✈️',lb:'Migrate servers to GCP',ds:'VMware · AWS · Azure · physical servers',cr:'Migration',nx:'R_migrate'},
        {ic:'⚡',lb:'Reduce VM cost significantly',ds:'Spot VMs, committed use, or custom machine types',cr:'Cost reduction',nx:'q2_cost'},
      ]},
    nodes: {
      q2_run: {id:'q2_run',ey:'Step 2 of 4',q:'Do you need physical server isolation for compliance?',
        h:'Sole-Tenant Nodes give physical isolation for HIPAA, PCI-DSS, and BYOL licensing. Standard GCE shares hardware but is isolated at hypervisor level with live migration keeping VMs running during maintenance.',
        two:true,
        opts:[
          {ic:'🏢',lb:'Yes — compliance or BYOL licensing',ds:'Physical isolation · Windows/SQL BYOL',cr:'Physical isolation',nx:'R_soletenant'},
          {ic:'🖥️',lb:'No — standard multi-tenant is fine',ds:'Multi-zone + OS Login + Shielded VMs',cr:'Standard GCE',nx:'R_ce'},
        ]},
      q2_protect: {id:'q2_protect',ey:'Step 2 of 4',q:'Point-in-time backup — or continuous DR replication?',
        h:'Cloud Backup snapshot mode = scheduled consistent backups (RPO hours). DR mode = journal-based continuous replication (RPO minutes, instant mount recovery).',
        two:true,
        opts:[
          {ic:'💾',lb:'Backup — restore from a point in time',ds:'App-consistent · cross-region · CMEK vault',cr:'Backup',nx:'R_backup'},
          {ic:'🔄',lb:'DR — instant failover if disaster strikes',ds:'Journal replication · near-zero RPO · instant mount',cr:'Disaster Recovery',nx:'R_clouddr'},
        ]},
      q2_cost: {id:'q2_cost',ey:'Step 2 of 4',q:'Can your workload tolerate interruption?',
        h:'Spot VMs save up to 91% for fault-tolerant jobs. Committed use gives 37–55% for guaranteed capacity. Custom machine types eliminate wasted vCPU/memory.',
        two:false,
        opts:[
          {ic:'⚡',lb:'Yes — batch, ML, Dataflow, rendering',ds:'Spot VMs: up to 91% off · 30-sec preemption notice',cr:'Spot VMs',nx:'R_spot'},
          {ic:'🖥️',lb:'No — need guaranteed availability',ds:'Committed use + custom machine type right-sizing',cr:'Committed use',nx:'R_ce'},
        ]},
    },
    results: {
      R_ce:        {k:'gcp_ce',       w:'Compute Engine is GCPs IaaS foundation. Enable OS Login and Shielded VMs on every instance. Use Service Accounts (not user credentials), deploy across zones, and enable live migration. Custom machine types let you right-size precisely. Committed use discounts save 37–55%.'},
      R_mig:       {k:'gcp_mig',      w:'Managed Instance Groups maintain capacity across 3 zones automatically. Regional MIGs are the right default — they survive a full zone failure. Use autoscaling with custom Pub/Sub metrics for event-driven scaling. Rolling updates give zero-downtime upgrades with configurable canary percentage.'},
      R_iap:       {k:'gcp_iap',      w:'Identity-Aware Proxy TCP tunnelling gives SSH and RDP access without public IPs or open firewall ports. GCP verifies Google identity + MFA before opening any tunnel. Combine with OS Login, Shielded VMs, and Access Context Manager for the strongest GCE security posture.'},
      R_backup:    {k:'gcp_backup',   w:'Cloud Backup and DR provides app-consistent, incremental-forever backups across GCE, GKE, and databases. Use cross-region copies for DR. CMEK encrypts the backup vault. Coldline storage tier reduces long-term backup cost by 70%.'},
      R_clouddr:   {k:'gcp_clouddr',  w:'Cloud Backup and DR in DR mode uses journal-based replication for near-zero RPO. Instant mount recovery means you can recover without a full restore. Run non-disruptive DR drills monthly — drill mode launches VMs in an isolated project.'},
      R_migrate:   {k:'gcp_migrate',  w:'Migrate to Virtual Machines uses streaming replication — no long maintenance window. Run a fit assessment first, launch test clones to validate, then cut over with a DNS swap. Migrate4Containers can modernise apps to Cloud Run during migration.'},
      R_spot:      {k:'gcp_spot',     w:'GCP Spot VMs offer up to 91% savings. Use Managed Instance Groups to automatically replace preempted VMs. Add a SIGTERM handler to checkpoint state within 30 seconds. Mix Spot and Standard in a MIG — base on Standard, burst on Spot.'},
      R_soletenant:{k:'gcp_soletenant',w:'Sole-Tenant Nodes provide physical server isolation for compliance and BYOL licensing. Node groups manage a fleet of nodes with auto-repair. Combine with committed use discounts for maximum savings on dedicated hardware.'},
    },
  },
};

// ── COMPARE HTML ──────────────────────────────────────────────
const COMPARE_HTML = `
<div style="margin-bottom:1.25rem">
  <h2 class="section-title">VM Infrastructure — Cross-Cloud Comparison</h2>
  <p class="section-sub">Equivalent IaaS services through the <strong>Well-Architected Framework</strong> lens: Reliability · Security · Cost · Performance · Operations.</p>
</div>

<div class="cmp-wrap"><div class="cmp-head"><h3>🖥️ Core IaaS Compute</h3><p>Fundamental VM services and auto-scaling</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Capability</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Core IaaS VM service</td><td>Azure Virtual Machines</td><td>Amazon EC2</td><td>Compute Engine</td></tr>
<tr><td>Auto-scaling fleet</td><td>VM Scale Sets (VMSS)</td><td>Auto Scaling Groups (ASG)</td><td>Managed Instance Groups (MIG)</td></tr>
<tr><td>Machine families</td><td>600+ SKUs (D, E, F, M, N, H series)</td><td>750+ types (t3, m6i, c7g Graviton, p4)</td><td>50+ families + custom vCPU/mem</td></tr>
<tr><td>Unique HA feature</td><td>Availability Zones — 3 per region</td><td>Multi-AZ — up to 6 AZs per region</td><td>Live migration — no VM restart on host maint.</td></tr>
<tr><td>ARM / custom architecture</td><td>Ampere Altra (Dpsv5)</td><td>Graviton3 — 40% better price-perf</td><td>Tau T2A (Ampere Altra)</td></tr>
<tr><td><strong>RE</strong> HA SLA</td><td>99.99% — 2+ zones · 99.95% — Av. Set</td><td>99.99% — Multi-AZ + ELB</td><td>99.99% — Regional MIG (3 zones)</td></tr>
<tr><td><strong>CO</strong> Committed savings</td><td>Reserved Instances — up to 72% · Hybrid Benefit</td><td>Savings Plans — up to 72% · Reserved — 75%</td><td>Committed Use — 37% (1yr) · 55% (3yr)</td></tr>
<tr><td><strong>CO</strong> Spot / Preemptible</td><td>Spot VMs — up to 90%</td><td>Spot Instances — up to 90%</td><td>Spot VMs — up to 91%</td></tr>
<tr><td><strong>PE</strong> Max networking</td><td>200 Gbps (M-series) · Accelerated Networking</td><td>200 Gbps (p4dn) · Elastic Fabric Adapter</td><td>200 Gbps (Tier_1) · compact placement</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>🔒 Security — Secure Access & Isolation</h3><p>Zero-trust access, physical isolation, identity-based auth</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Control</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Secure shell access (no open ports)</td><td>Azure Bastion — browser RDP/SSH</td><td>SSM Session Manager — IAM-based shell</td><td>IAP TCP tunnelling — BeyondCorp</td></tr>
<tr><td>VM identity (no stored credentials)</td><td>Managed Identity</td><td>IAM Instance Profile</td><td>Service Account (bound to VM)</td></tr>
<tr><td>OS-level security</td><td>Trusted Launch — Secure Boot + vTPM</td><td>Nitro System + IMDSv2</td><td>Shielded VMs — Secure Boot + vTPM</td></tr>
<tr><td>Memory encryption</td><td>Confidential VMs (AMD SEV)</td><td>AWS Nitro Enclaves</td><td>Confidential VMs (AMD SEV)</td></tr>
<tr><td>Network firewall</td><td>Network Security Groups (NSG)</td><td>Security Groups + Network ACL</td><td>VPC Firewall Rules + Cloud Armor</td></tr>
<tr><td>Physical isolation</td><td>Azure Dedicated Host</td><td>EC2 Dedicated Hosts</td><td>Sole-Tenant Nodes</td></tr>
<tr><td>BYOL (Windows/SQL)</td><td>✓ Azure Hybrid Benefit</td><td>✓ Dedicated Hosts BYOL</td><td>✓ Sole-Tenant Nodes BYOL</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>💾 Reliability — Backup &amp; Disaster Recovery</h3><p>RPO/RTO targets, replication, ransomware protection</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Capability</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Managed backup service</td><td>Azure Backup</td><td>AWS Backup</td><td>Cloud Backup and DR</td></tr>
<tr><td>Backup RPO</td><td>1 hour (enhanced policy)</td><td>1 hour (continuous EBS snapshots)</td><td>1 hour (scheduled snapshot)</td></tr>
<tr><td>Ransomware protection</td><td>Immutable vault + soft-delete (14 days)</td><td>Backup Vault Lock (WORM) — 72hr cool-off</td><td>Backup vault with restricted delete</td></tr>
<tr><td>Cross-region backup</td><td>✓ GRS vault</td><td>✓ Cross-region copy rule</td><td>✓ Multi-region vault</td></tr>
<tr><td>Disaster recovery service</td><td>Azure Site Recovery (ASR)</td><td>AWS Elastic Disaster Recovery (DRS)</td><td>Cloud Backup and DR (DR mode)</td></tr>
<tr><td>DR RPO</td><td>&lt; 1 minute</td><td>Seconds</td><td>Minutes (journal-based)</td></tr>
<tr><td>DR RTO</td><td>&lt; 15 minutes</td><td>Minutes</td><td>Minutes (instant mount)</td></tr>
<tr><td>Non-disruptive DR drill</td><td>✓ ASR test failover (isolated VNet)</td><td>✓ DRS drill mode (isolated VPC)</td><td>✓ DR drill mode (isolated project)</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>✈️ Operational Excellence — Migration &amp; Management</h3></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Capability</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Migration service</td><td>Azure Migrate</td><td>AWS Application Migration Service (MGN)</td><td>Migrate to Virtual Machines</td></tr>
<tr><td>Migration model</td><td>Agentless (VMware) · Agent (others)</td><td>Agent-based · continuous replication</td><td>Streaming migration · agentless VMware</td></tr>
<tr><td>Migration cost</td><td>Free (pay for replicated VMs)</td><td>Free (pay for EC2 at cutover)</td><td>Free (pay for GCE at cutover)</td></tr>
<tr><td>Right-size recommendations</td><td>Azure Advisor · Migrate assessment</td><td>Compute Optimizer (post-migration)</td><td>Fit Assessment (pre-migration)</td></tr>
<tr><td>Fleet patching</td><td>Azure Update Manager</td><td>SSM Patch Manager</td><td>OS Config · VM Manager</td></tr>
<tr><td>Monitoring</td><td>Azure Monitor + VM Insights + App Insights</td><td>CloudWatch + Systems Manager + X-Ray</td><td>Cloud Monitoring + Ops Agent + Cloud Trace</td></tr>
<tr><td>IaC support</td><td>Bicep · Terraform · ARM templates</td><td>CloudFormation · CDK · Terraform</td><td>Deployment Manager · Terraform · Config Connector</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>📋 Well-Architected Framework — VM Checklist</h3><p>Key decisions for every VM deployment across any cloud</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd" style="width:120px">Pillar</th><th class="hd">Must-do for every VM deployment</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td style="color:#0a5007;font-weight:700;background:#e8f5e8">🟢 Reliability</td><td>Deploy across 2+ zones with health-checked load balancer</td><td>VMSS + Zone-redundant LB</td><td>ASG multi-AZ + ALB</td><td>Regional MIG + GLB</td></tr>
<tr><td style="color:#6b0c0e;font-weight:700;background:#fce8e9">🔴 Security</td><td>No public IP · no open 22/3389 · IAM identity on VM</td><td>Bastion + Managed Identity</td><td>SSM + IAM Profile</td><td>IAP + Service Account</td></tr>
<tr><td style="color:#5a3000;font-weight:700;background:#fff8ed">🟡 Cost</td><td>Reserved/committed + right-size + Spot for burst</td><td>Reserved + Advisor + Spot</td><td>Savings Plans + Optimizer + Spot</td><td>CUD + custom type + Spot</td></tr>
<tr><td style="color:#004578;font-weight:700;background:#ebf4fc">🔵 Performance</td><td>Accelerated networking + right storage tier</td><td>Acc. Networking + Ultra Disk</td><td>ENA + io2 Block Express</td><td>Tier_1 + Hyperdisk</td></tr>
<tr><td style="color:#4a1580;font-weight:700;background:#f3e8fd">🟣 Operations</td><td>Backup + DR + monitoring + IaC + patch policy</td><td>Backup + ASR + Monitor</td><td>AWS Backup + DRS + CW</td><td>Backup DR + Monitoring</td></tr>
</tbody></table></div></div>`;

return { META, ICONS, DIAG, SVC, TREE, COMPARE_HTML };
})();
