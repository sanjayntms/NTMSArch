// ═══════════════════════════════════════════════════════
// TOPIC MODULE: Cloud Governance & Account Structure
// Azure: Tenant · Management Groups · Subscriptions ·
//        Resource Groups · Resources · Billing · RBAC · Policy
// AWS:   Organizations · OUs · Accounts · Resource Groups ·
//        Cost Explorer · SCPs · IAM
// GCP:   Organization · Folders · Projects · Billing Account ·
//        Resource Manager · IAM · Org Policies
// ═══════════════════════════════════════════════════════

window.TOPIC_GOVERNANCE = (function() {

const META = {
  id: 'governance',
  label: 'Governance & Accounts',
  icon: '🏛️',
  desc: 'Account structure · subscriptions · billing · RBAC · policy enforcement',
  clouds: ['azure','aws','gcp'],
  views: ['tree','gallery','compare'],
  heroTitle: 'How should you structure your cloud accounts?',
  heroSub: 'Tenants · Management groups · Subscriptions · Billing · Policy · RBAC',
  chips: {
    azure: ['🏛️ Entra Tenant','📁 Management Groups','💳 Subscriptions','📦 Resource Groups','💰 Cost Management','🔐 Azure Policy'],
    aws:   ['🏛️ AWS Organizations','📁 OUs','💳 Accounts','📦 Resource Groups','💰 Cost Explorer','🔐 SCPs'],
    gcp:   ['🏛️ Organization','📁 Folders','💳 Projects','💰 Billing Account','🔐 Org Policy','🗂️ Resource Manager'],
  },
};

// ── HELPERS ──────────────────────────────────────────────────────
function B(x,y,w,h,lb,sb,col,rx=9){
  const F={blue:'#ebf4fc',teal:'#e0f7fa',green:'#e8f5e8',amber:'#fff8ed',red:'#fce8e9',gray:'#f3f7fb',purple:'#f3e8fd',indigo:'#eef0fb',orange:'#fff3e0',dark:'#1e293b'};
  const S={blue:'#0078d4',teal:'#00b4d8',green:'#107c10',amber:'#e07000',red:'#a4262c',gray:'#a0b8cc',purple:'#7b2fbe',indigo:'#4b5ae4',orange:'#e65100',dark:'#334155'};
  const TX={blue:'#004578',teal:'#006478',green:'#0a5007',amber:'#5a3000',red:'#6b0c0e',gray:'#3a5068',purple:'#4a1580',indigo:'#1e2580',orange:'#4e1f00',dark:'#f1f5f9'};
  const f=F[col]||F.blue,s=S[col]||S.blue,t=TX[col]||TX.blue;
  const cy=sb?y+h/2-7:y+h/2;
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${f}" stroke="${s}" stroke-width="1.5"/><text x="${x+w/2}" y="${cy}" text-anchor="middle" dominant-baseline="central" font-family="'DM Sans',sans-serif" font-size="13" font-weight="600" fill="${t}">${lb}</text>${sb?`<text x="${x+w/2}" y="${y+h/2+10}" text-anchor="middle" dominant-baseline="central" font-family="'DM Sans',sans-serif" font-size="11" fill="${t}" opacity=".8">${sb}</text>`:''}`;}
function A(x1,y1,x2,y2,col='#0078d4'){const id='gv'+Math.abs(x1*3+y1*7+x2*11+y2*17);return `<defs><marker id="${id}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M2 1L8 5L2 9" fill="none" stroke="${col}" stroke-width="2" stroke-linecap="round"/></marker></defs><line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" stroke-width="2" class="fa" marker-end="url(#${id})"/>`;}
function N(x,y,t){return `<text x="${x}" y="${y}" font-family="'DM Sans',sans-serif" font-size="12.5" fill="#6a8ba4">${t}</text>`;}
function SVG(c,h=268){return `<svg viewBox="0 0 780 ${h}" xmlns="http://www.w3.org/2000/svg">${c}</svg>`;}
// Hierarchy line (vertical)
function VL(x,y1,y2,col='#a0b8cc'){return `<line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}" stroke="${col}" stroke-width="1.5" stroke-dasharray="4,3"/>`;}
// Horizontal connector
function HL(x1,x2,y,col='#a0b8cc'){return `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" stroke="${col}" stroke-width="1.5" stroke-dasharray="4,3"/>`;}

function gi(iid,bg1,bg2,shape){return `<svg width="80" height="80" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg" style="filter:drop-shadow(0 6px 18px ${bg1}70)"><defs><radialGradient id="gb_${iid}" cx="35%" cy="28%" r="72%"><stop offset="0%" stop-color="${bg2}"/><stop offset="100%" stop-color="${bg1}"/></radialGradient><radialGradient id="gs_${iid}" cx="42%" cy="18%" r="62%"><stop offset="0%" stop-color="rgba(255,255,255,0.62)"/><stop offset="100%" stop-color="rgba(255,255,255,0)"/></radialGradient></defs><rect x="4" y="5" width="64" height="63" rx="16" fill="url(#gb_${iid})"/><rect x="4" y="5" width="64" height="35" rx="16" fill="url(#gs_${iid})" opacity="0.75"/><rect x="4" y="28" width="64" height="12" fill="url(#gs_${iid})" opacity="0.22"/>${shape}<rect x="4" y="5" width="64" height="63" rx="16" fill="none" stroke="rgba(255,255,255,0.28)" stroke-width="1.5"/></svg>`;}

// Icon shapes
const TENANT_SH   = `<rect x="18" y="16" width="36" height="40" rx="5" fill="white" opacity=".9"/><rect x="22" y="20" width="28" height="8" rx="2" fill="rgba(0,0,0,.18)"/><rect x="22" y="32" width="10" height="10" rx="2" fill="rgba(0,0,0,.15)"/><rect x="35" y="32" width="10" height="10" rx="2" fill="rgba(0,0,0,.12)"/><rect x="22" y="45" width="23" height="8" rx="2" fill="rgba(0,0,0,.1)"/>`;
const MGMT_SH     = `<path d="M36 14 L54 24 L54 48 L36 58 L18 48 L18 24Z" fill="none" stroke="white" stroke-width="2.5" stroke-linejoin="round"/><path d="M36 14 L54 24 L36 34 L18 24Z" fill="white" opacity=".35"/><line x1="36" y1="34" x2="36" y2="58" stroke="white" stroke-width="2" opacity=".6"/><line x1="18" y1="24" x2="54" y2="24" stroke="white" stroke-width="2" opacity=".5"/>`;
const SUB_SH      = `<rect x="14" y="20" width="44" height="34" rx="5" fill="white" opacity=".9"/><rect x="14" y="20" width="44" height="10" rx="5" fill="rgba(0,0,0,.15)"/><rect x="14" y="26" width="44" height="4" fill="rgba(0,0,0,.15)"/><circle cx="20" cy="28" r="2" fill="rgba(255,255,255,.6)"/><rect x="18" y="35" width="36" height="4" rx="2" fill="rgba(0,0,0,.12)"/><rect x="18" y="42" width="24" height="4" rx="2" fill="rgba(0,0,0,.1)"/><rect x="18" y="49" width="30" height="4" rx="2" fill="rgba(0,0,0,.08)"/>`;
const RG_SH       = `<rect x="14" y="18" width="44" height="36" rx="5" fill="white" opacity=".9"/><rect x="20" y="24" width="14" height="14" rx="3" fill="rgba(0,0,0,.18)"/><rect x="38" y="24" width="14" height="14" rx="3" fill="rgba(0,0,0,.15)"/><rect x="20" y="42" width="14" height="8" rx="2" fill="rgba(0,0,0,.12)"/><rect x="38" y="42" width="14" height="8" rx="2" fill="rgba(0,0,0,.1)"/>`;
const BILLING_SH  = `<rect x="14" y="16" width="44" height="40" rx="5" fill="white" opacity=".9"/><path d="M28 26 Q36 20 44 26" fill="none" stroke="rgba(0,0,0,.2)" stroke-width="2.5" stroke-linecap="round"/><text x="36" y="40" text-anchor="middle" font-family="sans-serif" font-size="16" font-weight="700" fill="rgba(0,0,0,.28)">$</text><rect x="20" y="48" width="32" height="4" rx="2" fill="rgba(0,0,0,.1)"/>`;
const POLICY_SH   = `<path d="M36 14 L52 20 L52 40 Q52 52 36 58 Q20 52 20 40 L20 20Z" fill="none" stroke="white" stroke-width="2.5" stroke-linejoin="round"/><path d="M28 36 L33 41 L45 29" stroke="white" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
const ORG_SH      = `<circle cx="36" cy="22" r="8" fill="white" opacity=".9"/><circle cx="18" cy="50" r="7" fill="white" opacity=".85"/><circle cx="36" cy="50" r="7" fill="white" opacity=".8"/><circle cx="54" cy="50" r="7" fill="white" opacity=".75"/><line x1="36" y1="30" x2="18" y2="43" stroke="white" stroke-width="2" opacity=".6"/><line x1="36" y1="30" x2="36" y2="43" stroke="white" stroke-width="2" opacity=".6"/><line x1="36" y1="30" x2="54" y2="43" stroke="white" stroke-width="2" opacity=".6"/>`;
const IAM_SH      = `<circle cx="36" cy="26" r="10" fill="white" opacity=".9"/><path d="M16 58 Q16 44 36 44 Q56 44 56 58" fill="white" opacity=".75"/><rect x="30" y="36" width="12" height="10" rx="2" fill="rgba(0,0,0,.2)"/>`;
const COST_SH     = `<rect x="14" y="20" width="44" height="34" rx="5" fill="white" opacity=".9"/><polyline points="20,46 28,38 35,42 44,30 52,34" fill="none" stroke="rgba(0,100,0,.4)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><rect x="20" y="46" width="4" height="6" rx="1" fill="rgba(0,0,0,.15)"/><rect x="28" y="40" width="4" height="12" rx="1" fill="rgba(0,0,0,.15)"/><rect x="36" y="36" width="4" height="16" rx="1" fill="rgba(0,0,0,.15)"/>`;
const FOLDER_SH   = `<path d="M14 28 L14 56 L58 56 L58 28 L34 28 L30 22 L14 22Z" fill="white" opacity=".9"/><rect x="20" y="36" width="32" height="3" rx="1.5" fill="rgba(0,0,0,.15)"/><rect x="20" y="43" width="24" height="3" rx="1.5" fill="rgba(0,0,0,.12)"/><rect x="20" y="50" width="28" height="3" rx="1.5" fill="rgba(0,0,0,.1)"/>`;
const PROJECT_SH  = `<rect x="16" y="18" width="40" height="36" rx="5" fill="white" opacity=".9"/><rect x="16" y="18" width="40" height="11" rx="5" fill="rgba(0,0,0,.15)"/><rect x="16" y="25" width="40" height="4" fill="rgba(0,0,0,.15)"/><circle cx="22" cy="27" r="2" fill="rgba(255,255,255,.5)"/><circle cx="29" cy="27" r="2" fill="rgba(255,255,255,.4)"/><rect x="22" y="34" width="28" height="3" rx="1.5" fill="rgba(0,0,0,.12)"/><rect x="22" y="41" width="20" height="3" rx="1.5" fill="rgba(0,0,0,.1)"/><rect x="22" y="48" width="24" height="3" rx="1.5" fill="rgba(0,0,0,.08)"/>`;

const ICONS = {
  // AZURE
  'azure_tenant':      gi('azTen',  '#003060','#0050b3', TENANT_SH),
  'azure_mgmtgroup':   gi('azMG',   '#1a0060','#4b2aad', MGMT_SH),
  'azure_subscription':gi('azSub',  '#004578','#0078d4', SUB_SH),
  'azure_rg':          gi('azRG',   '#0a5060','#0891b2', RG_SH),
  'azure_billing':     gi('azBill', '#0a5007','#107c10', BILLING_SH),
  'azure_policy':      gi('azPol',  '#5c0080','#9333ea', POLICY_SH),
  'azure_rbac':        gi('azRBAC', '#7a3000','#b45309', IAM_SH),
  // AWS
  'aws_org':           gi('awOrg',  '#7a4200','#e07000', ORG_SH),
  'aws_ou':            gi('awOU',   '#6a3800','#c86800', FOLDER_SH),
  'aws_account':       gi('awAcc',  '#5a3000','#a05000', SUB_SH),
  'aws_rg':            gi('awRG',   '#4a3800','#886000', RG_SH),
  'aws_billing':       gi('awBill', '#1a4080','#2563eb', BILLING_SH),
  'aws_scp':           gi('awSCP',  '#3a2070','#6040c0', POLICY_SH),
  'aws_iam':           gi('awIAM',  '#7a2000','#b44000', IAM_SH),
  // GCP
  'gcp_org':           gi('gcOrg',  '#0d3b8c','#2878e8', ORG_SH),
  'gcp_folder':        gi('gcFold', '#0d4060','#0891b2', FOLDER_SH),
  'gcp_project':       gi('gcProj', '#0a4060','#0369a1', PROJECT_SH),
  'gcp_billing':       gi('gcBill', '#0a5040','#059669', BILLING_SH),
  'gcp_orgpolicy':     gi('gcOP',   '#4c1d95','#7c3aed', POLICY_SH),
  'gcp_iam':           gi('gcIAM',  '#083060','#1050a0', IAM_SH),
};

// ── DIAGRAMS ─────────────────────────────────────────────────────
const DIAG = {

  // Azure hierarchy
  azure_tenant: ()=>SVG(`
${B(280,14,220,36,'Entra ID Tenant','yourdomain.onmicrosoft.com','blue')}
${VL(390,50,80,'#4b2aad')}
${B(260,80,260,36,'Management Group','Root / Corp / Division','purple')}
${VL(390,116,148,'#0078d4')}
${B(185,148,145,34,'Subscription A','Production','blue')}
${B(455,148,145,34,'Subscription B','Non-Production','teal')}
${VL(258,182,214,'#0891b2')}${VL(528,182,214,'#0891b2')}
${B(185,214,145,34,'Resource Group','East US','teal')}
${B(455,214,145,34,'Resource Group','West EU','teal')}
${N(20,264,'Tenant → Mgmt Groups → Subscriptions → Resource Groups → Resources')}
${N(20,278,'Azure Policy and RBAC inherited down through each level')}`,295),

  azure_mgmtgroup: ()=>SVG(`
${B(290,12,200,34,'Root Mgmt Group','Tenant root','purple')}
${VL(390,46,78,'#4b2aad')}
${B(180,78,155,34,'Corp MG','All production','purple')}
${B(455,78,155,34,'Sandbox MG','Dev/test/POC','indigo')}
${VL(258,112,144,'#0078d4')}${VL(532,112,144,'#0078d4')}
${B(155,144,145,34,'Sub: Prod','Live workloads','blue')}
${B(315,144,135,34,'Sub: Staging','Pre-prod','teal')}
${B(455,144,145,34,'Sub: Dev','Developer subs','indigo')}
${N(20,208,'Policies assigned at MG level apply to all child subscriptions')}
${N(20,222,'Up to 6 levels of nesting · Max 10,000 MGs per tenant')}`,238),

  azure_subscription: ()=>SVG(`
${B(270,14,240,36,'Subscription','Billing + access boundary','blue')}
${A(330,50,220,82,'#0078d4')}${A(390,50,390,82,'#0078d4')}${A(450,50,560,82,'#0078d4')}
${B(130,82,175,34,'Resource Group','East US','teal')}
${B(303,82,175,34,'Resource Group','West EU','teal')}
${B(475,82,175,34,'Resource Group','Shared Svcs','green')}
${A(218,116,218,148,'#0891b2')}${A(390,116,390,148,'#0891b2')}${A(562,116,562,148,'#0891b2')}
${B(138,148,155,34,'VM · App Svc','Resources','gray')}
${B(312,148,155,34,'VM · DB · LB','Resources','gray')}
${B(487,148,155,34,'KV · DNS · FW','Resources','gray')}
${N(20,212,'Subscription = billing unit + RBAC scope + resource limit boundary')}
${N(20,226,'Limits: 980 RGs · unlimited resources (per type quota)')}`,242),

  azure_rg: ()=>SVG(`
${B(270,14,240,34,'Resource Group','Logical container · single region','teal')}
${A(270,48,185,80,'#0891b2')}${A(340,48,310,80,'#0891b2')}${A(410,48,440,80,'#0891b2')}${A(480,48,570,80,'#0891b2')}
${B(115,80,140,36,'Virtual Machine','East US','blue',7)}
${B(270,80,140,36,'App Service','East US','green',7)}
${B(365,80,145,36,'SQL Database','East US','amber',7)}
${B(520,80,140,36,'Key Vault','Global','purple',7)}
${N(20,148,'Resources in an RG share lifecycle — deploy, update, delete together')}
${N(20,162,'RG has a region (for metadata) but resources can be in any region')}
${N(20,176,'RBAC and Azure Policy can be scoped to individual RGs')}`,192),

  azure_billing: ()=>SVG(`
${B(270,14,240,34,'Azure Subscription','Billing boundary','blue')}
${A(390,48,390,80,'#107c10')}
${B(230,80,320,36,'Cost Management + Billing','Budgets · Alerts · Invoices','green')}
${A(280,116,200,148,'#107c10')}${A(390,116,390,148,'#107c10')}${A(500,116,580,148,'#107c10')}
${B(120,148,155,36,'Budgets','Alert at 80%/100%','green',7)}
${B(312,148,155,36,'Cost Analysis','By service/tag/RG','teal',7)}
${B(504,148,155,36,'Invoices','Monthly PDF/CSV','amber',7)}
${B(120,204,155,34,'EA / MCA','Enterprise contracts','blue',7)}
${B(312,204,155,34,'Dev/Test','Discounted rates','green',7)}
${B(504,204,155,34,'PAYG / CSP','Flexible billing','amber',7)}
${N(20,260,'Tags flow to Cost Management — tag all RGs with CostCenter, Env, Owner')}`,272),

  azure_policy: ()=>SVG(`
${B(270,14,240,34,'Azure Policy','Guardrails for compliance','purple')}
${A(350,48,240,80,'#9333ea')}${A(390,48,390,80,'#9333ea')}${A(430,48,545,80,'#9333ea')}
${B(130,80,200,34,'Deny','Block non-compliant','red',7)}
${B(290,80,200,34,'Audit','Log non-compliant','amber',7)}
${B(495,80,200,34,'DeployIfNotExists','Auto-remediate','green',7)}
${A(390,114,390,146,'#9333ea')}
${B(240,146,300,34,'Policy Initiative','Group of policies (benchmark)','purple')}
${N(20,210,'Assign at: MG · Subscription · Resource Group')}
${N(20,224,'Built-in: CIS · NIST · ISO 27001 · PCI DSS · HIPAA benchmarks')}`,238),

  azure_rbac: ()=>SVG(`
${B(270,14,240,34,'Azure RBAC','Role-based access control','amber')}
${A(320,48,215,80,'#b45309')}${A(390,48,390,80,'#b45309')}${A(460,48,565,80,'#b45309')}
${B(115,80,185,34,'Security Principal','User · Group · SP · MI','amber',7)}
${B(298,80,185,34,'Role Definition','Owner·Contrib·Reader+custom','blue',7)}
${B(501,80,185,34,'Scope','MG·Sub·RG·Resource','teal',7)}
${A(390,114,390,146,'#b45309')}
${B(240,146,300,34,'Role Assignment','Principal + Role + Scope','amber')}
${N(20,210,'Built-in roles: Owner · Contributor · Reader · 100+ service-specific')}
${N(20,224,'Custom roles: up to 5000 per tenant · JSON definition')}`,238),

  // AWS
  aws_org: ()=>SVG(`
${B(270,14,240,34,'AWS Organizations','Multi-account management','amber')}
${VL(390,48,80,'#c86800')}
${B(240,80,300,34,'Root','Top of OU hierarchy','amber')}
${VL(290,114,146,'#a05000')}${VL(490,114,146,'#a05000')}
${B(155,146,255,34,'OU: Production','Prod accounts','amber')}
${B(370,146,255,34,'OU: Sandbox','Dev/test accounts','indigo')}
${VL(283,180,212,'#a05000')}${VL(497,180,212,'#a05000')}
${B(155,212,140,34,'Account: App','Prod workload','blue')}
${B(310,212,140,34,'Account: Sec','Security tooling','red')}
${B(455,212,140,34,'Account: Dev','Developer sandbox','green')}
${N(20,264,'SCPs applied at OU level cascade to all child accounts')}
${N(20,278,'Account = isolation + blast-radius boundary in AWS')}`,295),

  aws_ou: ()=>SVG(`
${B(270,14,240,34,'Organizational Unit (OU)','Logical grouping of accounts','amber')}
${A(350,48,225,80,'#c86800')}${A(390,48,390,80,'#c86800')}${A(430,48,560,80,'#c86800')}
${B(110,80,210,34,'SCP: DenyRegions','us-east-1 only','red',7)}
${B(305,80,180,34,'SCP: RequireTags','Enforce tagging','amber',7)}
${B(505,80,185,34,'SCP: DenyRoot','Block root usage','purple',7)}
${A(390,114,390,146,'#c86800')}
${B(230,146,320,34,'Child Accounts','Inherit all parent SCPs','blue')}
${N(20,210,'OUs can be nested up to 5 levels · SCPs are deny-list by default')}
${N(20,224,'SCP cannot grant more permissions than the account-level boundary')}`,238),

  aws_account: ()=>SVG(`
${B(270,14,240,34,'AWS Account','Billing + blast-radius boundary','amber')}
${A(320,48,205,80,'#a05000')}${A(390,48,390,80,'#a05000')}${A(460,48,575,80,'#a05000')}
${B(105,80,190,36,'IAM','Users · Roles · Policies','blue',7)}
${B(298,80,185,36,'VPC','Networking isolation','teal',7)}
${B(486,80,190,36,'Resources','EC2 · S3 · RDS etc.','green',7)}
${A(200,116,200,148,'#a05000')}${A(390,116,390,148,'#a05000')}${A(581,116,581,148,'#a05000')}
${B(108,148,180,34,'Service Quotas','Per-account limits','gray',7)}
${B(303,148,175,34,'CloudTrail','All API calls logged','purple',7)}
${B(491,148,178,34,'Cost Allocation','Per-account billing','green',7)}
${N(20,210,'Separate account per env (Prod/Staging/Dev) is AWS best practice')}
${N(20,224,'AWS Control Tower automates multi-account landing zone setup')}`,238),

  aws_rg: ()=>SVG(`
${B(270,14,240,34,'AWS Resource Groups','Tag-based logical grouping','amber')}
${A(390,48,390,80,'#a05000')}
${B(230,80,320,34,'Tag-based Query','env=prod AND app=checkout','amber')}
${A(270,114,185,146,'#a05000')}${A(390,114,390,146,'#a05000')}${A(510,114,595,146,'#a05000')}
${B(95,146,175,34,'EC2 Instances','Tagged resources','blue',7)}
${B(303,146,175,34,'RDS Databases','Tagged resources','teal',7)}
${B(520,146,165,34,'S3 Buckets','Tagged resources','green',7)}
${N(20,220,'AWS Resource Groups are lightweight — primarily for Systems Manager views')}
${N(20,234,'Unlike Azure RGs, they are NOT a lifecycle or access boundary')}`,248),

  aws_billing: ()=>SVG(`
${B(270,14,240,34,'AWS Cost Management','Billing · Budgets · Forecasts','blue')}
${A(310,48,215,80,'#2563eb')}${A(390,48,390,80,'#2563eb')}${A(470,48,568,80,'#2563eb')}
${B(110,80,195,34,'Cost Explorer','Usage graphs · RI recs','blue',7)}
${B(298,80,185,34,'Budgets','Alert at $ threshold','amber',7)}
${B(483,80,195,34,'Cost Allocation Tags','Group by team/env','teal',7)}
${A(390,114,390,146,'#2563eb')}
${B(180,146,420,34,'Consolidated Billing','All org accounts in one invoice','blue')}
${N(20,208,'Savings Plans > Reserved Instances for flexibility · use Compute Optimizer')}
${N(20,222,'Cost Anomaly Detection uses ML to flag unexpected spend spikes')}`,238),

  aws_scp: ()=>SVG(`
${B(270,14,240,34,'Service Control Policies','Permission guardrails at OU/Account','indigo')}
${A(350,48,230,80,'#6040c0')}${A(390,48,390,80,'#6040c0')}${A(430,48,555,80,'#6040c0')}
${B(115,80,205,34,'Deny root usage','No root access ever','red',7)}
${B(303,80,185,34,'Require MFA','Enforce MFA for IAM','amber',7)}
${B(498,80,185,34,'Restrict regions','us-east-1 only','indigo',7)}
${A(390,114,390,146,'#6040c0')}
${B(230,146,320,34,'Effective permissions','SCP ∩ IAM policies','indigo')}
${N(20,210,'SCPs are deny filters — they cannot grant permissions')}
${N(20,224,'Full Access SCP is default · use allow-list or deny-list strategy')}`,238),

  aws_iam: ()=>SVG(`
${B(270,14,240,34,'AWS IAM','Identity & access management','red')}
${A(310,48,210,80,'#b44000')}${A(390,48,390,80,'#b44000')}${A(470,48,575,80,'#b44000')}
${B(105,80,195,34,'IAM Users','Long-lived credentials','red',7)}
${B(298,80,185,34,'IAM Roles','Temporary credentials','amber',7)}
${B(487,80,195,34,'IAM Policies','JSON permission docs','blue',7)}
${A(390,114,390,146,'#b44000')}
${B(200,146,380,34,'Least Privilege','Grant only what is needed','green')}
${N(20,210,'Best practice: use IAM Roles, not long-lived IAM User keys')}
${N(20,224,'IAM Access Analyzer flags unintended public/cross-account access')}`,238),

  // GCP
  gcp_org: ()=>SVG(`
${B(270,14,240,34,'GCP Organization','yourdomain.com','blue')}
${VL(390,48,80,'#0891b2')}
${B(235,80,310,34,'Folders','Department / Team / Env','teal')}
${VL(290,114,146,'#0369a1')}${VL(490,114,146,'#0369a1')}
${B(155,146,255,34,'Folder: Production','Live workloads','blue')}
${B(370,146,255,34,'Folder: Non-Prod','Dev/staging/test','teal')}
${VL(283,180,212,'#059669')}${VL(497,180,212,'#059669')}
${B(145,212,150,34,'Project: App','GCE · GKE · Cloud SQL','green')}
${B(310,212,150,34,'Project: Shared','VPC · DNS · KMS','blue')}
${B(465,212,150,34,'Project: Dev','Developer workloads','teal')}
${N(20,264,'Org → Folders → Projects → Resources')}
${N(20,278,'IAM and Org Policies inherited from parent — override at child level')}`,295),

  gcp_folder: ()=>SVG(`
${B(270,14,240,34,'GCP Folder','Grouping for projects','teal')}
${A(340,48,225,80,'#0891b2')}${A(390,48,390,80,'#0891b2')}${A(440,48,558,80,'#0891b2')}
${B(110,80,205,34,'Org Policy','Enforce at folder level','purple',7)}
${B(298,80,185,34,'IAM binding','roles/editor on folder','blue',7)}
${B(495,80,175,34,'Child Folders','Sub-department nesting','teal',7)}
${A(390,114,390,146,'#0891b2')}
${B(230,146,320,34,'Projects','Inherit folder policies','green')}
${N(20,210,'Folders can nest up to 10 levels · apply Org Policy constraints here')}
${N(20,224,'Use folders to separate Prod/NonProd — never mix in same folder')}`,238),

  gcp_project: ()=>SVG(`
${B(270,14,240,34,'GCP Project','Billing + API + IAM boundary','blue')}
${A(310,48,205,80,'#0369a1')}${A(390,48,390,80,'#0369a1')}${A(470,48,578,80,'#0369a1')}
${B(100,80,195,36,'Enabled APIs','Cloud Run · BigQuery…','blue',7)}
${B(298,80,185,36,'IAM Members','Roles bound to project','teal',7)}
${B(487,80,190,36,'Resources','GCE · GCS · Pub/Sub','green',7)}
${A(200,116,200,148,'#0369a1')}${A(390,116,390,148,'#0369a1')}${A(582,116,582,148,'#0369a1')}
${B(107,148,185,34,'Service Accounts','Per-service identity','amber',7)}
${B(305,148,170,34,'Quotas','Per-project API limits','gray',7)}
${B(494,148,180,34,'Billing link','One billing account','green',7)}
${N(20,212,'Project = smallest isolation unit · one project per app/env recommended')}
${N(20,226,'Projects are globally unique — use org prefix: myorg-prod-checkout')}`,242),

  gcp_billing: ()=>SVG(`
${B(270,14,240,34,'GCP Billing Account','Payment method + invoicing','green')}
${A(390,48,390,80,'#059669')}
${B(215,80,350,34,'Linked Projects','Many projects → one billing account','green')}
${A(280,114,200,146,'#059669')}${A(390,114,390,146,'#059669')}${A(500,114,580,146,'#059669')}
${B(110,146,165,34,'Budgets','Alert at threshold','amber',7)}
${B(308,146,165,34,'Cost Breakdown','By project/SKU/label','teal',7)}
${B(505,146,165,34,'Invoices','Monthly billing export','blue',7)}
${B(180,202,420,34,'BigQuery Export','Full cost data → BQ analytics','indigo')}
${N(20,256,'Labels flow to billing — label all resources with team, env, cost-center')}
${N(20,270,'Committed Use Discounts (1/3yr) and Sustained Use auto-discounts')}`,285),

  gcp_orgpolicy: ()=>SVG(`
${B(270,14,240,34,'GCP Org Policy','Centrally enforce constraints','purple')}
${A(340,48,220,80,'#7c3aed')}${A(390,48,390,80,'#7c3aed')}${A(440,48,562,80,'#7c3aed')}
${B(105,80,205,34,'Restrict locations','Only allowed regions','purple',7)}
${B(298,80,185,34,'Disable public IPs','No external IPs on GCE','red',7)}
${B(500,80,175,34,'Require OS Login','SSH via IAM only','blue',7)}
${A(390,114,390,146,'#7c3aed')}
${B(230,146,320,34,'Inherited to children','Folder → Project → Resource','purple')}
${N(20,210,'200+ built-in constraints · custom constraints with CEL expressions')}
${N(20,224,'Unlike IAM — Org Policy enforces what CAN happen, not who can do it')}`,238),

  gcp_iam: ()=>SVG(`
${B(270,14,240,34,'GCP IAM','Identity & access management','blue')}
${A(310,48,210,80,'#1050a0')}${A(390,48,390,80,'#1050a0')}${A(470,48,575,80,'#1050a0')}
${B(105,80,195,34,'Members','User · Group · SA · Domain','blue',7)}
${B(298,80,185,34,'Roles','Basic · Predefined · Custom','teal',7)}
${B(487,80,195,34,'Conditions','Time · resource-based','amber',7)}
${A(390,114,390,146,'#1050a0')}
${B(200,146,380,34,'Policy binding','Member + Role + Condition + Resource','blue')}
${N(20,210,'Prefer predefined roles over basic roles (Owner/Editor/Viewer)')}
${N(20,224,'Service Accounts: one per workload · use Workload Identity for GKE')}`,238),
};

// ── SERVICE CATALOGUE ─────────────────────────────────────────────
const SVC = {
  // ── AZURE ──
  azure_tenant: {
    cl:'azure', ic:'🏛️', nm:'Azure / Entra ID Tenant',
    tl:'Top-level identity boundary · yourdomain.onmicrosoft.com · single directory',
    tg:['Identity','Top-level','Entra ID'],
    ds:'The root of your Azure identity hierarchy. Every Azure subscription must trust exactly one Entra ID tenant. Contains all users, groups, service principals, and app registrations.',
    dk:'azure_tenant',
    ft:['Single Entra ID directory per tenant','All subscriptions trust one tenant','Contains users, groups, apps, service principals','Guest users (B2B) invited from other tenants','Global Administrator role scoped to tenant','Tenant ID is a GUID — globally unique','One tenant can own multiple subscriptions','Free with any Azure subscription'],
    uw:['Root of your entire Azure identity and access setup','Understanding the relationship between identity and subscriptions','B2B guest access for partners and contractors','Multi-tenant app registrations for SaaS products'],
    nf:'Not a billing unit (subscriptions are) — not a network boundary (VNets are).',
    nt:'💡 Most organisations have one tenant. Multiple tenants add management complexity — only use multiple tenants for strict isolation requirements (e.g. sovereign cloud, M&A).',
    doc:'https://learn.microsoft.com/en-us/azure/active-directory/fundamentals/active-directory-whatis'
  },
  azure_mgmtgroup: {
    cl:'azure', ic:'📁', nm:'Management Groups',
    tl:'Group subscriptions · inherit Policy & RBAC · up to 6 levels deep',
    tg:['Hierarchy','Policy scope','RBAC scope'],
    ds:'Containers that group multiple subscriptions. Azure Policy and RBAC assignments at a Management Group level are inherited by all child subscriptions. Root Management Group spans the entire tenant.',
    dk:'azure_mgmtgroup',
    ft:['Group subscriptions into logical hierarchy','Azure Policy and RBAC inherited to children','Up to 6 levels of nesting','Root MG auto-created per tenant','Up to 10,000 MGs per tenant','Subscription can belong to one MG only','Azure Blueprints assigned at MG level','Landing Zone architecture uses MGs heavily'],
    uw:['Applying consistent policy across dozens of subscriptions','Separating production from non-production at scale','Enterprise landing zone with platform/workload separation','Delegating subscription management to business units'],
    nf:'Not needed for single-subscription setups. Not a billing boundary — subscriptions are.',
    nt:'💡 Common pattern: Root → Platform MG (Connectivity, Identity, Management) + Workloads MG (Prod, Non-Prod) + Sandbox MG.',
    doc:'https://learn.microsoft.com/en-us/azure/governance/management-groups/overview'
  },
  azure_subscription: {
    cl:'azure', ic:'💳', nm:'Azure Subscription',
    tl:'Billing unit · RBAC boundary · resource quota container · per-environment',
    tg:['Billing unit','Access boundary','Resource container'],
    ds:'The fundamental deployment and billing unit in Azure. Each subscription has its own resource quotas, billing, and RBAC scope. Best practice: one subscription per environment (Prod, Staging, Dev).',
    dk:'azure_subscription',
    ft:['Primary billing boundary for Azure costs','Resource quotas scoped per subscription','RBAC assignments at subscription scope','Contains Resource Groups and Resources','Types: Pay-As-You-Go · EA · MCA · Dev/Test','980 Resource Groups per subscription limit','Subscription-level Activity Log','Move resources between subscriptions (limited)'],
    uw:['Separating production from non-production costs','Isolating team or project billing','Applying different policies to different environments','Hitting resource quotas and needing a new limit boundary'],
    nf:'Not an identity boundary (tenant is) — not a network boundary (VNet is).',
    nt:'💡 WAF Cost: use separate subscriptions for Prod/NonProd so cost is clearly separated. Use Dev/Test subscription type for 40-60% savings on dev workloads.',
    doc:'https://learn.microsoft.com/en-us/azure/cost-management-billing/manage/create-subscription'
  },
  azure_rg: {
    cl:'azure', ic:'📦', nm:'Resource Group',
    tl:'Lifecycle container · deploy together · tag together · delete together',
    tg:['Lifecycle','Deployment unit','Tag scope'],
    ds:'A logical container for Azure resources that share a lifecycle. Deploying, tagging, monitoring, and deleting a Resource Group affects all resources inside it. RBAC and Policy can be scoped to RG level.',
    dk:'azure_rg',
    ft:['All resources must belong to exactly one RG','Delete RG deletes all resources inside it','Resources can be in different regions than the RG','RBAC scoped to RG level','Azure Policy assignable at RG scope','Tags on RG propagate to cost reports','ARM / Bicep / Terraform deploy to an RG','Resources can be moved between RGs (most types)'],
    uw:['Grouping all resources for one application together','Lifecycle-based grouping (deploy/delete as a unit)','Per-environment separation within a subscription','Scoping RBAC to a specific application team'],
    nf:'Not a billing boundary (subscription is) — not a network boundary (VNet/subnet is).',
    nt:'💡 Name RGs with env prefix: rg-prod-checkout-eastus · rg-dev-checkout-eastus. Tag every RG with CostCenter, Owner, Environment for cost attribution.',
    doc:'https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/manage-resource-groups-portal'
  },
  azure_billing: {
    cl:'azure', ic:'💰', nm:'Azure Cost Management + Billing',
    tl:'Budgets · Cost analysis · Invoices · Alerts · Advisor recommendations',
    tg:['Billing','Cost control','FinOps'],
    ds:'Azure Cost Management provides visibility into spending, budget alerts, cost analysis by resource/tag/RG, and invoice management. Integrates with Azure Advisor for right-sizing recommendations.',
    dk:'azure_billing',
    ft:['Cost analysis by subscription/RG/tag/service','Budgets with email and action group alerts','Invoice download (PDF and CSV)','Export cost data to Storage Account','Azure Advisor cost recommendations','Dev/Test pricing (40-60% discount)','Reservation and Savings Plan management','EA · MCA · CSP · PAYG agreement types'],
    uw:['Setting monthly spend budgets with alerts','Analysing cost by team using resource tags','Showback/chargeback reporting per department','Identifying idle resources via Advisor'],
    nf:'Not for real-time billing (slight delay) — not a replacement for tag governance strategy.',
    nt:'💡 FinOps: tag every resource with CostCenter and Environment. Set budget alerts at 80% and 100%. Export cost data to Storage for custom Power BI dashboards.',
    doc:'https://learn.microsoft.com/en-us/azure/cost-management-billing/'
  },
  azure_policy: {
    cl:'azure', ic:'🔐', nm:'Azure Policy',
    tl:'Guardrails · Deny · Audit · Auto-remediate · CIS/NIST/ISO benchmarks',
    tg:['Compliance','Guardrails','Auto-remediate'],
    ds:'Azure Policy evaluates resources against defined rules. Effects include Deny (block), Audit (log), and DeployIfNotExists (auto-remediate). Assign policies at MG, subscription, or RG scope.',
    dk:'azure_policy',
    ft:['Deny non-compliant resource creation','Audit and report compliance status','DeployIfNotExists auto-remediation','Policy Initiatives (grouped policies)','Built-in: CIS · NIST · ISO 27001 · PCI · HIPAA','Custom policies with JSON/Bicep','Compliance dashboard and reports','Exempt specific resources/scopes'],
    uw:['Enforcing allowed Azure regions','Requiring tags on all resources','Ensuring encryption at rest on storage','Blocking public IP creation in prod','Ensuring Defender is enabled on VMs'],
    nf:'Not a replacement for RBAC (who can do what) — Policy controls what can be done.',
    nt:'💡 Start with Audit mode — understand non-compliance before switching to Deny. Use DeployIfNotExists to auto-attach Defender or diagnostic settings.',
    doc:'https://learn.microsoft.com/en-us/azure/governance/policy/overview'
  },
  azure_rbac: {
    cl:'azure', ic:'🔑', nm:'Azure RBAC',
    tl:'Role assignments · Built-in roles · Custom roles · Least privilege',
    tg:['Access control','Identity','Least privilege'],
    ds:'Azure Role-Based Access Control assigns built-in or custom roles to security principals (users, groups, service principals, managed identities) at a specific scope (MG, subscription, RG, or resource).',
    dk:'azure_rbac',
    ft:['Owner · Contributor · Reader (built-in)','100+ service-specific built-in roles','Custom roles (up to 5000 per tenant)','Assignments: User · Group · SP · Managed Identity','Scope: MG → Sub → RG → Resource','Deny assignments (block even Owner)','Privileged Identity Management (PIM) for JIT','Access reviews for periodic cleanup'],
    uw:['Granting app teams access to their RG only','CI/CD pipeline identity (Contributor on RG)','Read-only access for auditors (Reader)','JIT admin access via PIM'],
    nf:'Not for controlling which Azure services can be created (use Azure Policy) — not for app-level auth (use Entra ID app roles).',
    nt:'💡 Never assign Owner at subscription scope broadly. Use Managed Identities instead of Service Principals where possible — no credential to rotate.',
    doc:'https://learn.microsoft.com/en-us/azure/role-based-access-control/overview'
  },

  // ── AWS ──
  aws_org: {
    cl:'aws', ic:'🏛️', nm:'AWS Organizations',
    tl:'Multi-account management · consolidated billing · SCP enforcement · OUs',
    tg:['Multi-account','Top-level','SCPs'],
    ds:'AWS Organizations groups multiple AWS accounts into a hierarchy of Organizational Units (OUs). Enables consolidated billing, cross-account policies via SCPs, and AWS Control Tower landing zone automation.',
    dk:'aws_org',
    ft:['Consolidated billing across all accounts','Organizational Units (OUs) for grouping','Service Control Policies (SCPs) for guardrails','AWS Control Tower for landing zone automation','Delegated administrator accounts','Cross-account resource sharing (RAM)','CloudTrail aggregation at org level','Up to 100,000 accounts per organization'],
    uw:['Managing 10+ AWS accounts centrally','Applying security guardrails across all accounts','Consolidated billing and cost visibility','Setting up a multi-account landing zone'],
    nf:'Not needed for single-account setups — adds complexity worth it at scale.',
    nt:'💡 AWS best practice: separate account per environment (Prod, Staging, Dev, Sandbox, Security, Log Archive). Use Control Tower to automate this.',
    doc:'https://docs.aws.amazon.com/organizations/'
  },
  aws_ou: {
    cl:'aws', ic:'📁', nm:'Organizational Units (OUs)',
    tl:'Group AWS accounts · SCP inheritance · up to 5 levels · policy boundary',
    tg:['Hierarchy','SCP scope','Grouping'],
    ds:'OUs group AWS accounts within an Organization. SCPs assigned to an OU apply to all child OUs and accounts. Common OU structure: Infrastructure, Security, Workloads (Prod/NonProd), Sandbox.',
    dk:'aws_ou',
    ft:['Group accounts by environment or team','SCPs apply to OU and all children','Up to 5 levels of nesting','Accounts can belong to one OU only','AWS Control Tower creates recommended OU structure','IAM policies still apply within accounts','Move accounts between OUs','Nested OUs for complex org structures'],
    uw:['Separating production and non-production accounts','Applying strict SCPs to production accounts only','Grouping sandbox accounts for developers','Team or BU-based account grouping'],
    nf:'OUs alone do not create network isolation — accounts have separate VPCs for that.',
    nt:'💡 Keep OU structure flat (2-3 levels) to start. Deep nesting makes SCP debugging complex. Common: Root → Security OU + Infrastructure OU + Workloads OU (Prod/NonProd).',
    doc:'https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_ous.html'
  },
  aws_account: {
    cl:'aws', ic:'💳', nm:'AWS Account',
    tl:'Billing unit · blast-radius boundary · IAM scope · VPC container',
    tg:['Billing unit','Isolation','IAM scope'],
    ds:'An AWS account is the fundamental isolation unit — separate IAM, VPCs, quotas, billing, and CloudTrail. AWS recommends one account per environment. Accounts are the primary blast-radius boundary.',
    dk:'aws_account',
    ft:['Independent IAM namespace per account','Separate VPCs and networking per account','Individual service quotas and limits','Separate CloudTrail and billing','Root user exists per account (protect with MFA)','Accounts can be created programmatically via Organizations','Cross-account roles for shared access','Cost allocation per account in consolidated billing'],
    uw:['Isolating production from non-production','Separate billing per team or product','Limiting blast radius of security incidents','Meeting compliance isolation requirements'],
    nf:'Not a substitute for least-privilege IAM — accounts isolate, IAM controls within accounts.',
    nt:'💡 Use AWS Control Tower Account Factory to vend new accounts with guardrails pre-applied. Never use the root user — create an IAM admin user or use SSO.',
    doc:'https://docs.aws.amazon.com/accounts/latest/reference/accounts-welcome.html'
  },
  aws_rg: {
    cl:'aws', ic:'📦', nm:'AWS Resource Groups',
    tl:'Tag-based grouping · Systems Manager integration · not a lifecycle boundary',
    tg:['Grouping','Tag-based','Lightweight'],
    ds:'AWS Resource Groups logically group resources based on tags or CloudFormation stack membership. Primarily used for Systems Manager operations (patching, run command). NOT a lifecycle or access boundary like Azure RGs.',
    dk:'aws_rg',
    ft:['Tag-based resource queries','CloudFormation stack-based grouping','Systems Manager Fleet Manager integration','Run Command across a group','Patch Manager target groups','AWS Config aggregation view','Saved queries for common groups','Available in all regions'],
    uw:['Targeting Systems Manager operations at tagged resources','Organising resources for operational views','Patching all "env=prod" tagged EC2 instances at once'],
    nf:'Not a lifecycle boundary (deleting RG does not delete resources) — not an access scope (use IAM conditions for tag-based access).',
    nt:'⚠️ AWS Resource Groups are much simpler than Azure Resource Groups. In AWS, account separation (not RGs) provides the equivalent lifecycle and billing isolation.',
    doc:'https://docs.aws.amazon.com/ARG/latest/userguide/resource-groups.html'
  },
  aws_billing: {
    cl:'aws', ic:'💰', nm:'AWS Cost Management',
    tl:'Cost Explorer · Budgets · Anomaly Detection · Savings Plans · Consolidated billing',
    tg:['Billing','FinOps','Cost control'],
    ds:'AWS Cost Management provides Cost Explorer for analysis, Budgets for alerting, Savings Plans for commitment discounts, and Cost Anomaly Detection for ML-based spend alerting. All accounts roll up to consolidated billing.',
    dk:'aws_billing',
    ft:['Cost Explorer with 12 months history','Budgets with SNS/email/Chatbot alerts','Cost Anomaly Detection (ML-based)','Savings Plans (1yr/3yr commitment)','Reserved Instance management','Consolidated billing across org','Cost allocation tags (active + inactive)','CUR (Cost and Usage Report) to S3'],
    uw:['Setting account-level spend alerts','Analysing cost by tag/service/account','Committing to Savings Plans for EC2/Lambda/Fargate','Detecting unexpected spend spikes automatically'],
    nf:'Not real-time — up to 24h delay. Not a substitute for tagging strategy.',
    nt:'💡 FinOps: activate cost allocation tags immediately. Use CUR + Athena/QuickSight for custom dashboards. Compute Optimizer gives right-sizing recommendations.',
    doc:'https://docs.aws.amazon.com/cost-management/'
  },
  aws_scp: {
    cl:'aws', ic:'🔐', nm:'Service Control Policies (SCPs)',
    tl:'Org-level guardrails · deny filters · cascade through OUs · cannot grant permissions',
    tg:['Guardrails','Org-level','Deny-list'],
    ds:'SCPs are permission guardrails applied at OU or account level in AWS Organizations. They act as a maximum permissions boundary — they can restrict but never grant permissions. Effective permission = SCP ∩ IAM policy.',
    dk:'aws_scp',
    ft:['Applied at Root, OU, or Account level','Cascade to all child OUs and accounts','Cannot grant permissions — only restrict','Effective permission = SCP AND IAM policy','FullAWSAccess SCP applied by default','Allow-list or deny-list strategy','Does not affect management account','AWS Control Tower manages SCPs via guardrails'],
    uw:['Preventing any account from disabling CloudTrail','Restricting all workloads to specific regions','Blocking root user access across all accounts','Requiring MFA for all IAM actions','Preventing accidental S3 public access'],
    nf:'SCPs do not apply to management (root) account — apply separate controls there. SCPs cannot be used to grant permissions.',
    nt:'⚠️ SCPs affect ALL principals in the account including admins — test in sandbox first. Use deny-list strategy: attach FullAWSAccess + targeted Deny policies.',
    doc:'https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html'
  },
  aws_iam: {
    cl:'aws', ic:'🔑', nm:'AWS IAM',
    tl:'Users · Roles · Policies · Permission boundaries · Least privilege',
    tg:['Access control','Identity','Least privilege'],
    ds:'AWS Identity and Access Management controls authentication and authorisation within an account. Best practice: use IAM Roles (temporary credentials) over IAM Users (long-lived keys). Use IAM Identity Center for human access.',
    dk:'aws_iam',
    ft:['IAM Users (long-lived — avoid for humans)','IAM Roles (temporary credentials — preferred)','IAM Policies (JSON permission documents)','Permission boundaries (max permissions cap)','IAM Identity Center (SSO for human access)','Resource-based policies (S3, KMS, etc.)','IAM Access Analyzer (detect overpermissions)','Service-linked roles for AWS services'],
    uw:['EC2 instance role for S3/DynamoDB access','Cross-account role assumption','CI/CD pipeline role with Contributor equivalent','IAM Identity Center for developer access via SSO'],
    nf:'Not for org-level controls (use SCPs) — not for end-user authentication (use Cognito).',
    nt:'💡 Never use IAM Users for CI/CD — use OIDC federation (GitHub Actions → IAM Role). Enable IAM Access Analyzer in every account to detect unintended public/cross-account access.',
    doc:'https://docs.aws.amazon.com/iam/'
  },

  // ── GCP ──
  gcp_org: {
    cl:'gcp', ic:'🏛️', nm:'GCP Organization',
    tl:'Root of hierarchy · yourdomain.com · Cloud Identity · Org policies inherited',
    tg:['Top-level','Identity','Org policies'],
    ds:'The Organization resource is the root node of the GCP resource hierarchy, representing your company domain. Created automatically when you set up Cloud Identity or Google Workspace. All folders and projects belong to the Org.',
    dk:'gcp_org',
    ft:['Root of all GCP resources for your domain','Created via Google Workspace or Cloud Identity','Org Admin role for top-level control','Org Policy constraints apply to all children','Folders and Projects belong to the Org','Audit logs aggregated at org level','Shared VPC host projects defined here','Cloud Asset Inventory for org-wide visibility'],
    uw:['Top-level governance for all GCP usage','Applying org-wide security constraints','Understanding where all GCP spend comes from','Setting up a landing zone for the organisation'],
    nf:'Not a billing unit (projects linked to billing accounts are) — not a network boundary (VPCs are).',
    nt:'💡 Always use an Organization — personal Gmail accounts without org have no Org resource and miss critical governance controls. Use Cloud Identity (free) if no Workspace.',
    doc:'https://cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy'
  },
  gcp_folder: {
    cl:'gcp', ic:'📁', nm:'GCP Folders',
    tl:'Group projects · inherit IAM + Org Policy · department/env separation',
    tg:['Hierarchy','IAM scope','Org Policy scope'],
    ds:'Folders group projects and can be nested up to 10 levels. IAM bindings and Org Policy constraints set on a folder are inherited by all child folders and projects. Use folders to separate departments, teams, or environments.',
    dk:'gcp_folder',
    ft:['Group projects and sub-folders','IAM inherited to all children','Org Policy constraints inherited','Up to 10 levels of nesting','300 folders per parent node','Common: Prod/NonProd/Sandbox folders','Project Factory (IaC) creates projects in folders','Folder-level billing export via BigQuery'],
    uw:['Separating production from non-production projects','Department-based project grouping','Applying stricter Org Policies to production folder','Delegating folder IAM admin to team leads'],
    nf:'Not a billing boundary (linked billing accounts are) — not a network boundary (VPCs/Shared VPC are).',
    nt:'💡 Recommended structure: Org → Bootstrap folder → Production folder → Non-production folder → Sandbox folder. Match your Terraform folder structure to this hierarchy.',
    doc:'https://cloud.google.com/resource-manager/docs/creating-managing-folders'
  },
  gcp_project: {
    cl:'gcp', ic:'💳', nm:'GCP Project',
    tl:'API · billing · IAM boundary · resource container · globally unique ID',
    tg:['Billing unit','API scope','Resource container'],
    ds:'A Project is the base-level organising entity in GCP. All GCP resources belong to a project. Projects enable APIs, link to a billing account, and define the IAM and quota scope. Recommended: one project per application per environment.',
    dk:'gcp_project',
    ft:['Globally unique Project ID (cannot change)','Links to one billing account','Enables/disables GCP APIs','IAM policies scoped to project','Service quotas per project','Default compute network per project','Service accounts belong to a project','terraform.tfstate per project recommended'],
    uw:['One project per application environment (prod, staging, dev)','Shared services project for VPC, DNS, KMS','Sandbox project for individual developer experimentation','CI/CD project for build infrastructure'],
    nf:'Not a network boundary alone (use Shared VPC for cross-project networking) — not an org-level control boundary (use Folders + Org Policy).',
    nt:'💡 Project naming: {org}-{env}-{app} e.g. acme-prod-checkout · acme-dev-checkout. Use Project Factory (Terraform module) to enforce consistent project creation.',
    doc:'https://cloud.google.com/resource-manager/docs/creating-managing-projects'
  },
  gcp_billing: {
    cl:'gcp', ic:'💰', nm:'GCP Billing Account',
    tl:'Payment method · linked projects · Budgets · BigQuery export · CUD / SUDs',
    tg:['Billing','FinOps','Cost control'],
    ds:'A GCP Billing Account is linked to a payment method and can be associated with multiple projects. Costs from all linked projects appear on one invoice. GCP applies Sustained Use Discounts (SUDs) automatically and offers Committed Use Discounts (CUDs) for 1/3yr commitments.',
    dk:'gcp_billing',
    ft:['One billing account → many projects','Budgets with email/Pub/Sub alerts','BigQuery billing export (detailed + standard)','Sustained Use Discounts (auto-applied)','Committed Use Discounts (1yr/3yr)','Cost breakdown by project/SKU/label','Billing IAM roles separate from resource IAM','Sub-accounts for resellers/MSPs'],
    uw:['Centralised billing for all org projects','Setting project-level spend budgets','Exporting cost data to BigQuery for FinOps dashboards','Committing to CUDs for VM/database savings'],
    nf:'Not a resource isolation boundary — not the same as a GCP project.',
    nt:'💡 Always enable BigQuery billing export on day 1. Use Looker Studio or custom dashboards on BQ billing data for granular chargeback. Label all resources with team, env, cost-center.',
    doc:'https://cloud.google.com/billing/docs'
  },
  gcp_orgpolicy: {
    cl:'gcp', ic:'🔐', nm:'GCP Org Policy',
    tl:'200+ constraints · restrict locations · disable public IPs · enforce OS Login',
    tg:['Guardrails','Constraints','Compliance'],
    ds:'Org Policy Service lets you centrally control what can be configured on GCP resources. Unlike IAM (who can do what), Org Policy defines what configurations are allowed. Constraints are inherited from Org → Folder → Project.',
    dk:'gcp_orgpolicy',
    ft:['200+ built-in constraints','Custom constraints with CEL expressions','Inherited: Org → Folder → Project','Override at child level (if permitted)','Restrict resource locations (GDPR compliance)','Disable external IP on Compute Engine','Require OS Login (disable SSH keys)','Require Shielded VMs org-wide','Disable service account key creation'],
    uw:['Restricting all GCE to approved regions only','Preventing public IP on all VMs by default','Enforcing Shielded VM across the org','Disabling service account key downloads','Requiring VPC flow logs on all subnets'],
    nf:'Not for access control (use IAM) — Org Policy controls WHAT can be configured, not WHO can do it.',
    nt:'💡 Apply constraints_iam.disableServiceAccountKeyCreation org-wide — force Workload Identity instead. Apply constraints_compute.restrictCloudArmor to prevent bypassing security.',
    doc:'https://cloud.google.com/org-policy/docs/overview'
  },
  gcp_iam: {
    cl:'gcp', ic:'🔑', nm:'GCP IAM',
    tl:'Members · Roles · Conditions · Policy bindings · Least privilege · Workload Identity',
    tg:['Access control','Identity','Least privilege'],
    ds:'GCP IAM controls who (member) can do what (role) on which resource (scope). IAM policies bind members to roles on resources. Use predefined roles over basic roles. Use Service Accounts + Workload Identity for workloads.',
    dk:'gcp_iam',
    ft:['Members: Google account · Group · Service Account · Domain','Basic roles: Owner/Editor/Viewer (avoid)','Predefined roles: 1000+ fine-grained','Custom roles for least privilege','IAM Conditions (time/resource-based)','Service Accounts per workload','Workload Identity for GKE pods','Policy Analyzer and IAM Recommender'],
    uw:['Granting Cloud Run service account access to Cloud SQL','GKE workload accessing Secret Manager via Workload Identity','Developer read-only access to prod project','Auditor access with roles/viewer at org level'],
    nf:'Not for org-level constraints (use Org Policy) — not for end-user identity management (use Google Workspace/Cloud Identity).',
    nt:'💡 Use IAM Recommender to identify and remove excess permissions. Use Workload Identity Federation instead of service account keys for GitHub Actions → GCP deployments.',
    doc:'https://cloud.google.com/iam/docs/overview'
  },
};

// ── DECISION TREES ─────────────────────────────────────────────
const TREE = {
  azure: {
    root: {id:'q1', ey:'Step 1 of 3',
      q:'What governance challenge are you trying to solve?',
      h:'Azure governance spans identity (tenant), hierarchy (management groups), billing (subscriptions), deployment (resource groups), and compliance (policy + RBAC).',
      two:false,
      opts:[
        {ic:'🏛️', lb:'Understand the account hierarchy',    ds:'Tenant → Mgmt Groups → Subscriptions → RGs',    cr:'Hierarchy',   nx:'q2_hier'},
        {ic:'💰', lb:'Control and analyse cloud costs',      ds:'Budgets, invoices, cost analysis by tag',        cr:'Billing',     nx:'R_billing'},
        {ic:'🔐', lb:'Enforce compliance guardrails',        ds:'Block non-compliant resources automatically',    cr:'Policy',      nx:'R_policy'},
        {ic:'🔑', lb:'Control who can access what',          ds:'Assign roles to users, groups, managed identities', cr:'RBAC',     nx:'R_rbac'},
        {ic:'📦', lb:'Organise resources for an application',ds:'Resource Groups — lifecycle and scope containers', cr:'Resource Groups', nx:'R_rg'},
      ]},
    nodes:{
      q2_hier:{id:'q2_hier', ey:'Step 2 of 3',
        q:'Which level of the hierarchy do you need to understand?',
        h:'Each level serves a different purpose: identity, grouping, billing, or deployment.',
        two:false,
        opts:[
          {ic:'🏛️', lb:'Entra ID Tenant — identity root',            ds:'All users, apps, service principals live here', cr:'Tenant',         nx:'R_tenant'},
          {ic:'📁', lb:'Management Groups — group subscriptions',     ds:'Policy and RBAC scope across many subs',        cr:'Mgmt Groups',    nx:'R_mgmtgroup'},
          {ic:'💳', lb:'Subscriptions — billing and quota boundary',  ds:'One per environment — Prod/Staging/Dev',        cr:'Subscriptions',  nx:'R_subscription'},
          {ic:'📦', lb:'Resource Groups — resource lifecycle',        ds:'Deploy and delete resources as a group',        cr:'Resource Groups', nx:'R_rg'},
        ]},
    },
    results:{
      R_tenant:      {k:'azure_tenant',       w:'The Entra ID Tenant is the root of your Azure identity. Every Azure subscription trusts exactly one tenant. All users, groups, app registrations, and service principals live here. Most orgs have one tenant — multiple tenants add management complexity.'},
      R_mgmtgroup:   {k:'azure_mgmtgroup',    w:'Management Groups group subscriptions into a hierarchy. Azure Policy and RBAC assigned at a Management Group cascade to all child subscriptions automatically. Essential for organisations with 5+ subscriptions. Common structure: Platform MG + Workloads MG + Sandbox MG.'},
      R_subscription:{k:'azure_subscription', w:'Subscriptions are the primary billing and quota boundary. Best practice: one subscription per environment (Prod, Staging, Dev). Use Dev/Test subscription type for 40-60% savings on non-production workloads.'},
      R_rg:          {k:'azure_rg',           w:'Resource Groups are lifecycle containers — deploy, tag, monitor, and delete resources together. Every resource must belong to exactly one RG. RBAC and Policy can be scoped to RG level. Name with env prefix: rg-prod-checkout-eastus.'},
      R_billing:     {k:'azure_billing',      w:'Azure Cost Management + Billing provides budgets, alerts, cost analysis by tag/RG/service, and invoice management. Tag every Resource Group with CostCenter, Environment, Owner. Set budget alerts at 80% and 100%. Export to Storage for Power BI dashboards.'},
      R_policy:      {k:'azure_policy',       w:'Azure Policy enforces compliance guardrails. Use Deny to block non-compliant resources, Audit to log them, and DeployIfNotExists to auto-remediate. Start with Audit mode, then switch to Deny once impact is understood. Assign at Management Group scope to cover all subscriptions.'},
      R_rbac:        {k:'azure_rbac',         w:'Azure RBAC controls who can do what at which scope. Assign the narrowest scope needed. Use Managed Identities instead of Service Principals for app authentication. Use PIM for just-in-time privileged access. Custom roles for precise least-privilege control.'},
    },
  },
  aws: {
    root: {id:'q1', ey:'Step 1 of 3',
      q:'What governance challenge are you trying to solve?',
      h:'AWS governance spans Organizations (hierarchy), Accounts (isolation), SCPs (guardrails), IAM (access), and Cost Management (billing).',
      two:false,
      opts:[
        {ic:'🏛️', lb:'Understand the account hierarchy',    ds:'Organizations → OUs → Accounts',                cr:'Hierarchy',  nx:'q2_hier'},
        {ic:'💰', lb:'Control and analyse cloud costs',      ds:'Cost Explorer, Budgets, Savings Plans',          cr:'Billing',    nx:'R_billing'},
        {ic:'🔐', lb:'Enforce org-wide guardrails',          ds:'Service Control Policies at OU/account level',   cr:'SCPs',       nx:'R_scp'},
        {ic:'🔑', lb:'Control who can access what',          ds:'IAM Roles, Policies, Identity Center',           cr:'IAM',        nx:'R_iam'},
        {ic:'📦', lb:'Group resources for operations',       ds:'Resource Groups — tag-based for Systems Manager',cr:'Resource Groups', nx:'R_rg'},
      ]},
    nodes:{
      q2_hier:{id:'q2_hier', ey:'Step 2 of 3',
        q:'Which level of the AWS hierarchy?',
        h:'In AWS, the Account is the primary isolation unit — separate IAM, VPCs, quotas, and billing.',
        two:false,
        opts:[
          {ic:'🏛️', lb:'Organizations — root of all accounts', ds:'Consolidated billing + SCP enforcement',         cr:'Organizations',  nx:'R_org'},
          {ic:'📁', lb:'OUs — group accounts by environment',  ds:'SCPs cascade to all accounts in the OU',         cr:'OUs',            nx:'R_ou'},
          {ic:'💳', lb:'Accounts — isolation + billing unit',  ds:'One account per environment best practice',      cr:'Accounts',       nx:'R_account'},
          {ic:'📦', lb:'Resource Groups — tag-based grouping', ds:'Lightweight operational grouping (not lifecycle)',cr:'Resource Groups', nx:'R_rg'},
        ]},
    },
    results:{
      R_org:     {k:'aws_org',      w:'AWS Organizations is the root of your multi-account strategy. It enables consolidated billing, SCP-based guardrails, and AWS Control Tower for landing zone automation. Every serious AWS deployment should use Organizations — even with just a few accounts.'},
      R_ou:      {k:'aws_ou',       w:'Organizational Units group accounts and cascade SCPs to all children. Start simple: Root → Security OU + Infrastructure OU + Workloads OU (Prod/NonProd sub-OUs) + Sandbox OU. AWS Control Tower creates this structure automatically.'},
      R_account: {k:'aws_account',  w:'The AWS Account is the fundamental isolation unit — separate IAM namespace, VPCs, quotas, and billing. AWS recommends one account per environment (Prod, Staging, Dev, Sandbox). Use Control Tower Account Factory to vend new accounts with guardrails pre-applied.'},
      R_rg:      {k:'aws_rg',       w:'AWS Resource Groups are lightweight tag-based groupings for Systems Manager operations. Unlike Azure RGs, they are NOT lifecycle or billing boundaries — deleting a Resource Group does not delete resources. Account separation (not RGs) provides the equivalent isolation in AWS.'},
      R_billing: {k:'aws_billing',  w:'AWS Cost Management provides Cost Explorer, Budgets with anomaly detection, and Savings Plans. Activate cost allocation tags immediately. Use CUR (Cost and Usage Report) exported to S3 + Athena for custom analysis. Set budget alerts at account and service level.'},
      R_scp:     {k:'aws_scp',      w:'Service Control Policies are permission guardrails at OU or account level. They restrict but cannot grant permissions. Common SCPs: prevent root usage, enforce MFA, restrict to approved regions, block CloudTrail disable. Test in sandbox before applying to prod OUs.'},
      R_iam:     {k:'aws_iam',      w:'AWS IAM controls access within an account. Use IAM Roles (temporary credentials) not IAM Users for workloads. Use IAM Identity Center for human access via SSO. Use OIDC federation for GitHub Actions — no long-lived keys needed. Enable IAM Access Analyzer in every account.'},
    },
  },
  gcp: {
    root: {id:'q1', ey:'Step 1 of 3',
      q:'What governance challenge are you trying to solve?',
      h:'GCP governance spans the Organization (root), Folders (grouping), Projects (billing+API boundary), Billing Accounts, Org Policies (guardrails), and IAM (access).',
      two:false,
      opts:[
        {ic:'🏛️', lb:'Understand the resource hierarchy',   ds:'Organization → Folders → Projects → Resources',  cr:'Hierarchy',  nx:'q2_hier'},
        {ic:'💰', lb:'Control and analyse cloud costs',      ds:'Billing accounts, Budgets, BigQuery export',      cr:'Billing',    nx:'R_billing'},
        {ic:'🔐', lb:'Enforce org-wide constraints',         ds:'Org Policy — restrict locations, disable public IPs', cr:'Org Policy', nx:'R_orgpolicy'},
        {ic:'🔑', lb:'Control who can access what',          ds:'IAM members, roles, conditions, Workload Identity', cr:'IAM',       nx:'R_iam'},
        {ic:'📁', lb:'Organise projects into groups',        ds:'Folders for department or environment separation', cr:'Folders',    nx:'R_folder'},
      ]},
    nodes:{
      q2_hier:{id:'q2_hier', ey:'Step 2 of 3',
        q:'Which level of the GCP hierarchy?',
        h:'GCP hierarchy: Organization (identity root) → Folders (grouping) → Projects (billing+API) → Resources.',
        two:false,
        opts:[
          {ic:'🏛️', lb:'Organization — root for your domain',  ds:'All GCP resources under your domain',             cr:'Organization', nx:'R_org'},
          {ic:'📁', lb:'Folders — group projects by env/team', ds:'IAM and Org Policy inherited to child projects',  cr:'Folders',      nx:'R_folder'},
          {ic:'💳', lb:'Projects — billing and API boundary',  ds:'One per application per environment',             cr:'Projects',     nx:'R_project'},
        ]},
    },
    results:{
      R_org:       {k:'gcp_org',       w:'The GCP Organization is the root of your resource hierarchy, tied to your domain (e.g. mycompany.com). Created automatically with Google Workspace or Cloud Identity. IAM bindings and Org Policy constraints set at Org level apply to everything. Always use an Organization — personal accounts without one miss critical governance controls.'},
      R_folder:    {k:'gcp_folder',    w:'Folders group projects and inherit IAM + Org Policy to all children. Recommended structure: Org → Bootstrap → Production folder → Non-production folder → Sandbox folder. Use the GCP Enterprise Foundation Blueprint (Terraform) to create this structure consistently.'},
      R_project:   {k:'gcp_project',   w:'A GCP Project is the base isolation unit — it defines which APIs are enabled, links to one billing account, and scopes IAM and quotas. Best practice: one project per application per environment. Use a Project Factory (Terraform module) to ensure consistent naming and labelling.'},
      R_billing:   {k:'gcp_billing',   w:'GCP Billing Accounts link to projects and consolidate spend. Enable BigQuery billing export on day 1 — it is the foundation for all GCP FinOps. GCP auto-applies Sustained Use Discounts (up to 30%) with no commitment. Add Committed Use Discounts (1/3yr) for further savings on predictable workloads.'},
      R_orgpolicy: {k:'gcp_orgpolicy', w:'Org Policy constrains what configurations are allowed across all projects and folders. Key policies to enable: restrict resource locations (GDPR), disable external IP creation on GCE, require OS Login, disable service account key creation (use Workload Identity instead), require Shielded VMs. Apply at org level, override selectively at folder/project where needed.'},
      R_iam:       {k:'gcp_iam',       w:'GCP IAM binds members (users, groups, service accounts) to roles at a resource scope. Use predefined roles (not basic Owner/Editor/Viewer). Use Workload Identity for GKE pods accessing GCP services — eliminates service account key files entirely. Use IAM Recommender to identify and remove excess permissions quarterly.'},
    },
  },
};

// ── COMPARE HTML ─────────────────────────────────────────────────
const COMPARE_HTML = `
<div style="margin-bottom:1.25rem">
  <h2 class="section-title">Cloud Governance — Cross-Cloud Comparison</h2>
  <p class="section-sub">Account hierarchy, billing, access control, and policy enforcement across Azure, AWS, and GCP.</p>
</div>

<div class="cmp-wrap"><div class="cmp-head"><h3>Resource Hierarchy</h3><p>How each cloud organises accounts, projects, and resources</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Level</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Identity root</td><td>Entra ID Tenant (yourdomain.onmicrosoft.com)</td><td>AWS Account (root) + IAM Identity Center</td><td>Organization (yourdomain.com via Cloud Identity)</td></tr>
<tr><td>Top grouping</td><td>Management Groups (up to 6 levels)</td><td>AWS Organizations Root → OUs (up to 5 levels)</td><td>Organization → Folders (up to 10 levels)</td></tr>
<tr><td>Billing unit</td><td>Subscription (Pay-As-You-Go / EA / MCA)</td><td>AWS Account (consolidated via Organizations)</td><td>GCP Project (linked to Billing Account)</td></tr>
<tr><td>Resource container</td><td>Resource Group (lifecycle + RBAC scope)</td><td>AWS Account → VPC (no RG equivalent for lifecycle)</td><td>GCP Project (API + IAM + quota scope)</td></tr>
<tr><td>Logical grouping</td><td>Resource Group (strong — lifecycle boundary)</td><td>Resource Groups (weak — tag-based, operational only)</td><td>Project (strong — billing + API boundary)</td></tr>
<tr><td>Hierarchy depth</td><td>Tenant → MG (6 levels) → Sub → RG → Resource</td><td>Org → Root → OU (5 levels) → Account → Resource</td><td>Org → Folder (10 levels) → Project → Resource</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>Account / Subscription Isolation</h3><p>What each billing/isolation unit provides</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Feature</th><th class="az">Azure Subscription</th><th class="aw">AWS Account</th><th class="gc">GCP Project</th></tr></thead><tbody>
<tr><td>Billing boundary</td><td>✓ Primary billing unit</td><td>✓ Primary billing unit</td><td>✓ Linked to billing account</td></tr>
<tr><td>IAM namespace</td><td>✓ RBAC scope</td><td>✓ Separate IAM namespace</td><td>✓ IAM policy scope</td></tr>
<tr><td>Network isolation</td><td>VNet provides isolation</td><td>✓ Separate VPC per account</td><td>VPC provides isolation</td></tr>
<tr><td>Resource quotas</td><td>✓ Per subscription</td><td>✓ Per account</td><td>✓ Per project (API quotas)</td></tr>
<tr><td>Blast radius</td><td>Subscription-scoped</td><td>✓ Strong — account-level isolation</td><td>Project-scoped</td></tr>
<tr><td>Recommended use</td><td>One per environment (Prod/Staging/Dev)</td><td>One per environment per team</td><td>One per app per environment</td></tr>
<tr><td>Creation automation</td><td>Azure Blueprints / Subscription vending</td><td>Control Tower Account Factory</td><td>Project Factory (Terraform module)</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>Policy & Guardrails</h3><p>Enforcing compliance and preventing misconfigurations</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Feature</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Policy enforcement service</td><td>Azure Policy</td><td>Service Control Policies (SCPs)</td><td>Org Policy Service</td></tr>
<tr><td>Scope of application</td><td>MG → Subscription → RG → Resource</td><td>Root → OU → Account</td><td>Org → Folder → Project → Resource</td></tr>
<tr><td>Inheritance</td><td>✓ Child inherits parent policy</td><td>✓ Child inherits parent SCP</td><td>✓ Child inherits parent constraint</td></tr>
<tr><td>Effects / Actions</td><td>Deny · Audit · DeployIfNotExists · Modify</td><td>Allow (whitelist) or Deny (blacklist)</td><td>Deny · Allow · RestrictValues</td></tr>
<tr><td>Can grant permissions?</td><td>No (RBAC grants, Policy restricts)</td><td>No (SCPs can only restrict)</td><td>No (IAM grants, Org Policy restricts)</td></tr>
<tr><td>Auto-remediation</td><td>✓ DeployIfNotExists + remediation task</td><td>✗ Use Config Rules + Lambda</td><td>✗ Use Cloud Functions on audit findings</td></tr>
<tr><td>Built-in benchmarks</td><td>CIS · NIST · ISO 27001 · PCI · HIPAA</td><td>AWS Config conformance packs</td><td>CIS GCP Foundation benchmark</td></tr>
<tr><td>Custom policies</td><td>✓ JSON / Bicep / Terraform</td><td>✓ JSON SCP documents</td><td>✓ CEL-based custom constraints</td></tr>
<tr><td>Number of built-ins</td><td>1000+ built-in policies</td><td>~300 AWS Config managed rules</td><td>200+ org policy constraints</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>Access Control (IAM)</h3><p>Identity, roles, and access management comparison</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Feature</th><th class="az">Azure RBAC</th><th class="aw">AWS IAM</th><th class="gc">GCP IAM</th></tr></thead><tbody>
<tr><td>Identity types</td><td>User · Group · Service Principal · Managed Identity</td><td>IAM User · IAM Role · Federated identity</td><td>Google account · Group · Service Account · Domain</td></tr>
<tr><td>Preferred workload identity</td><td>Managed Identity (no credential)</td><td>IAM Role (temporary STS credentials)</td><td>Service Account + Workload Identity</td></tr>
<tr><td>Human access</td><td>Entra ID users / groups</td><td>IAM Identity Center (SSO)</td><td>Google Workspace / Cloud Identity</td></tr>
<tr><td>Role types</td><td>Built-in (100+) + Custom (JSON)</td><td>AWS Managed + Customer Managed + Inline</td><td>Basic · Predefined (1000+) · Custom</td></tr>
<tr><td>Max custom roles</td><td>5,000 per tenant</td><td>Unlimited per account</td><td>1,000 per org/project</td></tr>
<tr><td>Condition-based access</td><td>✓ Azure Attribute-based (ABAC)</td><td>✓ IAM Condition keys</td><td>✓ IAM Conditions (CEL)</td></tr>
<tr><td>CI/CD recommended pattern</td><td>Managed Identity / OIDC federation</td><td>OIDC federation (no long-lived keys)</td><td>Workload Identity Federation</td></tr>
<tr><td>Excess permission detection</td><td>Microsoft Entra Access Reviews + Advisor</td><td>IAM Access Analyzer + Credential Report</td><td>IAM Recommender + Policy Analyzer</td></tr>
</tbody></table></div></div>

<div class="cmp-wrap" style="margin-top:1rem"><div class="cmp-head"><h3>Billing & Cost Management</h3><p>FinOps capabilities across clouds</p></div>
<div style="overflow-x:auto"><table class="ct"><thead><tr><th class="hd">Feature</th><th class="az">Azure</th><th class="aw">AWS</th><th class="gc">GCP</th></tr></thead><tbody>
<tr><td>Cost analysis tool</td><td>Azure Cost Management + Billing</td><td>AWS Cost Explorer</td><td>GCP Cost Table (console) + BigQuery export</td></tr>
<tr><td>Budget alerts</td><td>✓ Budget → Action Group (email/webhook)</td><td>✓ Budget → SNS → email/Chatbot</td><td>✓ Budget → Pub/Sub → email/Slack</td></tr>
<tr><td>Anomaly detection</td><td>✓ Cost anomaly alerts</td><td>✓ Cost Anomaly Detection (ML)</td><td>✓ Budget alerts (threshold-based)</td></tr>
<tr><td>Discount types</td><td>Reservations (1/3yr) · Savings Plans · Dev/Test</td><td>Reserved Instances · Savings Plans · Spot</td><td>CUD (1/3yr) · SUD (auto) · Spot</td></tr>
<tr><td>Auto-applied discount</td><td>✗ (must purchase reservation)</td><td>✗ (must purchase RI or SP)</td><td>✓ Sustained Use Discounts (auto, up to 30%)</td></tr>
<tr><td>Cost export for analysis</td><td>Export to Storage Account (CSV)</td><td>CUR to S3 → Athena/QuickSight</td><td>BigQuery billing export (recommended)</td></tr>
<tr><td>Right-sizing recommendations</td><td>Azure Advisor</td><td>AWS Compute Optimizer</td><td>GCP Recommender</td></tr>
<tr><td>Tagging for cost</td><td>Tags → Cost Management (RG + resource level)</td><td>Cost allocation tags (must activate)</td><td>Labels → Billing export (project + resource)</td></tr>
</tbody></table></div></div>`;

return { META, ICONS, DIAG, SVC, TREE, COMPARE_HTML };
})();
