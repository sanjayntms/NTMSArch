const express = require('express');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const port = process.env.PORT || 3000;
app.use(express.json());

// ── Config ─────────────────────────────────────────────────────
const AUTH_ENABLED  = (process.env.AUTH_ENABLED  || 'false').toLowerCase() === 'true';
const ADMIN_EMAIL_RAW = process.env.ADMIN_EMAIL  || 'sanjay.dubey@outlook.com,sanjay@ntms.onmicrosoft.com';
const ADMIN_EMAILS  = ADMIN_EMAIL_RAW.split(',').map(e => e.trim().toLowerCase()).filter(Boolean);
const TOPICS_DIR    = path.join(__dirname, 'public', 'topics');
const INDEX_PATH    = path.join(__dirname, 'public', 'index.html');
const CONFIG_PATH   = path.join(__dirname, 'admin-config.json');

console.log('=== STARTUP ===');
console.log('AUTH_ENABLED :', AUTH_ENABLED);
console.log('ADMIN_EMAILS :', ADMIN_EMAILS);
console.log('===============');

// ── Admin config ───────────────────────────────────────────────
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH))
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (e) { console.warn('Config read error:', e.message); }
  const def = (process.env.PROTECTED_TOPICS || '').split(',').map(t=>t.trim()).filter(Boolean);
  return { protectedTopics: def };
}
function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

// ── Easy Auth principal ────────────────────────────────────────
// App Service injects this header in ALL variations of casing.
// We check every possible header name.
function getRawPrincipalHeader(req) {
  return req.headers['x-ms-client-principal']
      || req.headers['X-MS-CLIENT-PRINCIPAL']
      || req.headers['x-ms-client-principal-name']
      || null;
}

function getPrincipal(req) {
  // Try the base64 principal first
  const h = req.headers['x-ms-client-principal'];
  if (h) {
    try { return JSON.parse(Buffer.from(h, 'base64').toString('utf8')); }
    catch(e) { console.warn('Principal parse error:', e.message); }
  }
  return null;
}

function resolveGuestUpn(v) {
  if (!v || !v.includes('#ext#')) return v;
  const local  = v.split('#ext#')[0];
  const lastUs = local.lastIndexOf('_');
  if (lastUs > 0) return local.slice(0, lastUs) + '@' + local.slice(lastUs + 1);
  return v;
}

function extractEmails(p) {
  const claims = p.claims || [];
  const gc = type => (claims.find(c => c.typ === type) || {}).val || '';
  const raw = [
    gc('email'),
    gc('preferred_username'),
    gc('upn'),
    gc('unique_name'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn'),
    gc('http://schemas.microsoft.com/identity/claims/identityprovider'),
    p.userDetails || '',
  ].map(v => v.toLowerCase()).filter(v => v.includes('@'));

  const resolved = raw.map(resolveGuestUpn);
  return [...new Set([...raw, ...resolved])].filter(Boolean);
}

function getUser(req) {
  const p = getPrincipal(req);
  if (!p) return null;
  const claims = p.claims || [];
  const gc = type => (claims.find(c => c.typ === type) || {}).val || '';
  const emails = extractEmails(p);
  return {
    name:      gc('name') || gc('given_name') || p.userDetails || 'User',
    email:     emails[0] || p.userDetails || '',
    allEmails: emails,
  };
}

function checkIsAdmin(req) {
  if (!AUTH_ENABLED) return false;
  const user = getUser(req);
  if (!user) return false;
  const match = user.allEmails.some(e => ADMIN_EMAILS.includes(e));
  console.log(`[isAdmin] allEmails=${JSON.stringify(user.allEmails)} adminList=${JSON.stringify(ADMIN_EMAILS)} match=${match}`);
  return match;
}

// ── Topic discovery ────────────────────────────────────────────
function getTopicIds() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => f.replace('-module.js', ''));
  } catch { return []; }
}
function getTopicScripts() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => `<script src="/topics/${f}"></script>`)
      .join('\n    ');
  } catch { return ''; }
}

// ── Dynamic index.html ─────────────────────────────────────────
let indexTemplate = null;
function getIndexHtml() {
  if (!indexTemplate || process.env.NODE_ENV !== 'production') {
    const raw = fs.readFileSync(INDEX_PATH, 'utf8');
    indexTemplate = raw.replace(
      /<!-- TOPIC MODULES.*?<!-- END TOPIC MODULES -->/s,
      '<!-- TOPIC MODULES — auto-injected -->\n    __TOPIC_SCRIPTS__\n    <!-- END TOPIC MODULES -->'
    );
  }
  return indexTemplate.replace('__TOPIC_SCRIPTS__', getTopicScripts());
}

// ════════════════════════════════════════════════════════════════
// ROUTES
// ════════════════════════════════════════════════════════════════

// ── GET /api/auth/me ───────────────────────────────────────────
app.get('/api/auth/me', (req, res) => {
  const p    = getPrincipal(req);
  const user = getUser(req);

  // Log every /api/auth/me call for debugging
  console.log('[/api/auth/me]',
    'principal:', !!p,
    'user:', user ? user.email : 'none',
    'AUTH_ENABLED:', AUTH_ENABLED,
    'header present:', !!req.headers['x-ms-client-principal']
  );

  if (!AUTH_ENABLED) {
    return res.json({ authenticated: false, isAdmin: false, debug: 'AUTH_ENABLED=false' });
  }

  if (user) {
    const admin = user.allEmails.some(e => ADMIN_EMAILS.includes(e));
    return res.json({
      authenticated: true,
      isAdmin:  admin,
      name:     user.name,
      email:    user.email,
    });
  }

  res.json({ authenticated: false, isAdmin: false });
});

// ── GET /api/auth/topics ───────────────────────────────────────
app.get('/api/auth/topics', (req, res) => {
  const authed = AUTH_ENABLED && !!getPrincipal(req);
  const cfg    = loadConfig();
  res.json({
    authenticated:   authed,
    protectedTopics: authed ? [] : cfg.protectedTopics,
  });
});

// ── GET /api/admin/config ──────────────────────────────────────
app.get('/api/admin/config', (req, res) => {
  if (!checkIsAdmin(req)) return res.status(403).json({ error: 'Admin only.' });
  const cfg = loadConfig();
  res.json({ protectedTopics: cfg.protectedTopics, allTopics: getTopicIds(), adminEmails: ADMIN_EMAILS });
});

// ── POST /api/admin/config ─────────────────────────────────────
app.post('/api/admin/config', (req, res) => {
  if (!checkIsAdmin(req)) return res.status(403).json({ error: 'Admin only.' });
  const { protectedTopics } = req.body;
  if (!Array.isArray(protectedTopics)) return res.status(400).json({ error: 'Array expected.' });
  const known = new Set(getTopicIds());
  const valid = protectedTopics.filter(t => known.has(t));
  saveConfig({ protectedTopics: valid, updatedAt: new Date().toISOString() });
  res.json({ ok: true, protectedTopics: valid });
});

// ── GET /api/debug/claims ──────────────────────────────────────
// Open this in a NEW tab after signing in:
// https://ntms-cloud-guide.azurewebsites.net/api/debug/claims
app.get('/api/debug/claims', (req, res) => {
  res.setHeader('Content-Type', 'application/json');

  const allHeaders = {};
  // Capture every x-ms-* header to see what App Service is injecting
  Object.keys(req.headers).forEach(k => {
    if (k.startsWith('x-ms-') || k.startsWith('x-arr-')) {
      allHeaders[k] = req.headers[k];
    }
  });

  const principalHeader = req.headers['x-ms-client-principal'];
  const p = getPrincipal(req);

  if (!p) {
    return res.json({
      STATUS:           'NOT_SIGNED_IN',
      AUTH_ENABLED:     AUTH_ENABLED,
      principalHeader:  !!principalHeader,
      xMsHeaders:       allHeaders,
      tip:              'If principalHeader is false, Easy Auth is not injecting the header. Check App Service Authentication settings.',
    });
  }

  const user  = getUser(req);
  const admin = user.allEmails.some(e => ADMIN_EMAILS.includes(e));

  res.json({
    STATUS:                 admin ? 'ADMIN_OK' : 'NOT_ADMIN',
    isAdmin:                admin,
    name:                   user.name,
    email:                  user.email,
    allExtractedEmails:     user.allEmails,
    configuredAdminEmails:  ADMIN_EMAILS,
    ACTION_IF_NOT_ADMIN:    admin ? 'none needed' : `Set ADMIN_EMAIL app setting to include: ${user.email}`,
    identityProvider:       p.identityProvider,
    userDetails:            p.userDetails,
    xMsHeaders:             allHeaders,
    allClaims:              (p.claims || []).map(c => ({ typ: c.typ, val: c.val })),
  });
});

// ── GET /api/topics/list ───────────────────────────────────────
app.get('/api/topics/list', (req, res) => {
  res.json({ topics: getTopicIds(), count: getTopicIds().length });
});

// ── Auth redirect helpers ──────────────────────────────────────
app.get('/api/auth/login', (req, res) => {
  res.redirect(`/.auth/login/aad?post_login_redirect_uri=${encodeURIComponent(req.query.redirect || '/')}`);
});
app.get('/api/auth/logout', (req, res) => {
  res.redirect('/.auth/logout?post_logout_redirect_uri=/');
});

// ── Static files ───────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, index: false }));

// ── SPA fallback ───────────────────────────────────────────────
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: `No API route: ${req.path}` });
  }
  try {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(getIndexHtml());
  } catch (err) {
    res.status(500).send('Server error.');
  }
});

// ── Start ──────────────────────────────────────────────────────
app.listen(port, () => {
  console.log(`NTMS Cloud Guide   port=${port}`);
  console.log(`Auth enabled     : ${AUTH_ENABLED}`);
  console.log(`Admin emails     : ${ADMIN_EMAILS.join(' | ')}`);
  console.log(`Topics           : ${getTopicIds().join(', ')}`);
});
