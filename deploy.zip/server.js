const express = require('express');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const port = process.env.PORT || 3000;
app.use(express.json());

// ── Config ────────────────────────────────────────────────────
const AUTH_ENABLED = (process.env.AUTH_ENABLED || 'false').toLowerCase() === 'true';
const ADMIN_EMAIL  = (process.env.ADMIN_EMAIL  || 'sanjay.dubey@outlook.com').toLowerCase();
const TOPICS_DIR   = path.join(__dirname, 'public', 'topics');
const INDEX_PATH   = path.join(__dirname, 'public', 'index.html');
// Persisted admin config — survives restarts (App Service persists /home/site/wwwroot)
const CONFIG_PATH  = path.join(__dirname, 'admin-config.json');

// ── Admin config (lock/unlock topics) ────────────────────────
// Loads from admin-config.json; falls back to PROTECTED_TOPICS env var.
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
  } catch (e) {
    console.warn('admin-config.json unreadable, using defaults:', e.message);
  }
  // Default: read from PROTECTED_TOPICS env var
  const defaultLocked = (process.env.PROTECTED_TOPICS || '')
    .split(',').map(t => t.trim()).filter(Boolean);
  return { protectedTopics: defaultLocked };
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

// ── Easy Auth header parser ────────────────────────────────────
function getPrincipal(req) {
  const h = req.headers['x-ms-client-principal'];
  if (!h) return null;
  try { return JSON.parse(Buffer.from(h, 'base64').toString('utf8')); }
  catch { return null; }
}

function getUser(req) {
  const p = getPrincipal(req);
  if (!p) return null;
  const claims = p.claims || [];
  const gc = type => (claims.find(c => c.typ === type) || {}).val || '';
  return {
    name:    gc('name') || gc('preferred_username') || p.userDetails || 'User',
    email:  (gc('preferred_username') || gc('upn') || gc('email') || '').toLowerCase(),
    authenticated: true,
  };
}

function isAuthenticated(req) {
  return AUTH_ENABLED && getPrincipal(req) !== null;
}

function isAdmin(req) {
  if (!AUTH_ENABLED) return false;
  const user = getUser(req);
  return user && user.email === ADMIN_EMAIL;
}

// ── Topic file discovery ──────────────────────────────────────
function getTopicIds() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js'))
      .sort()
      .map(f => f.replace('-module.js', ''));
  } catch { return []; }
}

function getTopicScripts() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js'))
      .sort()
      .map(f => `<script src="/topics/${f}"></script>`)
      .join('\n    ');
  } catch { return ''; }
}

// ── Dynamic index.html ────────────────────────────────────────
let indexTemplate = null;
function getIndexHtml() {
  if (!indexTemplate || process.env.NODE_ENV !== 'production') {
    const raw = fs.readFileSync(INDEX_PATH, 'utf8');
    indexTemplate = raw.replace(
      /<!-- TOPIC MODULES.*?<!-- END TOPIC MODULES -->/s,
      '<!-- TOPIC MODULES — auto-injected -->\n    __TOPIC_SCRIPTS__\n    <!-- END TOPIC MODULES -->'
    );
  }
  return indexTemplate.replace('__TOPIC_SCRIPTS__', getTopicScripts());
}

// ════════════════════════════════════════════════════════
// API ROUTES
// ════════════════════════════════════════════════════════

// ── GET /api/auth/me ──────────────────────────────────────────
// Always 200. Anonymous → { authenticated: false, isAdmin: false }
app.get('/api/auth/me', (req, res) => {
  const user = getUser(req);
  if (user) {
    res.json({
      authenticated: true,
      isAdmin:       user.email === ADMIN_EMAIL,
      name:          user.name,
      email:         user.email,
    });
  } else {
    res.json({ authenticated: false, isAdmin: false });
  }
});

// ── GET /api/auth/topics ──────────────────────────────────────
// Returns which topics are currently locked for this user.
app.get('/api/auth/topics', (req, res) => {
  const authed = isAuthenticated(req);
  const cfg    = loadConfig();
  res.json({
    authenticated:   authed,
    protectedTopics: authed ? [] : cfg.protectedTopics,
  });
});

// ── GET /api/admin/config ─────────────────────────────────────
// Returns full config + all available topic IDs. Admin only.
app.get('/api/admin/config', (req, res) => {
  if (!isAdmin(req))
    return res.status(403).json({ error: 'Admin access required.' });
  const cfg      = loadConfig();
  const allTopics = getTopicIds();
  res.json({
    protectedTopics: cfg.protectedTopics,
    allTopics,
    adminEmail: ADMIN_EMAIL,
  });
});

// ── POST /api/admin/config ────────────────────────────────────
// Saves updated protectedTopics list. Admin only.
app.post('/api/admin/config', (req, res) => {
  if (!isAdmin(req))
    return res.status(403).json({ error: 'Admin access required.' });
  const { protectedTopics } = req.body;
  if (!Array.isArray(protectedTopics))
    return res.status(400).json({ error: 'protectedTopics must be an array.' });
  // Validate: only allow known topic IDs
  const known = new Set(getTopicIds());
  const valid = protectedTopics.filter(t => known.has(t));
  const cfg   = { protectedTopics: valid, updatedAt: new Date().toISOString(), updatedBy: ADMIN_EMAIL };
  saveConfig(cfg);
  console.log(`[Admin] Topic config updated by ${ADMIN_EMAIL}:`, valid);
  res.json({ ok: true, protectedTopics: valid });
});

// ── GET /api/topics/list (diagnostic) ────────────────────────
app.get('/api/topics/list', (req, res) => {
  res.json({ topics: getTopicIds(), count: getTopicIds().length });
});

// ── Easy Auth login / logout ──────────────────────────────────
app.get('/api/auth/login', (req, res) => {
  res.redirect(`/.auth/login/aad?post_login_redirect_uri=${encodeURIComponent(req.query.redirect || '/')}`);
});
app.get('/api/auth/logout', (req, res) => {
  res.redirect('/.auth/logout?post_logout_redirect_uri=/');
});

// ── Static files ──────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, index: false }));

// ── SPA fallback ──────────────────────────────────────────────
app.get('*', (req, res) => {
  try {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(getIndexHtml());
  } catch (err) {
    console.error('index.html error:', err.message);
    res.status(500).send('Server error.');
  }
});

// ── Start ─────────────────────────────────────────────────────
app.listen(port, () => {
  const cfg = loadConfig();
  console.log(`NTMS Cloud Guide   port=${port}`);
  console.log(`Auth enabled     : ${AUTH_ENABLED}`);
  console.log(`Admin email      : ${ADMIN_EMAIL}`);
  console.log(`Protected topics : ${cfg.protectedTopics.join(', ') || '(none)'}`);
  console.log(`Topics installed : ${getTopicIds().join(', ')}`);
  console.log(`Config file      : ${CONFIG_PATH}`);
});
