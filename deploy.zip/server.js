const express = require('express');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const port = process.env.PORT || 3000;
app.use(express.json());

// ── Config ─────────────────────────────────────────────────────
const AUTH_ENABLED = (process.env.AUTH_ENABLED || 'false').toLowerCase() === 'true';
// ADMIN_EMAIL: comma-separated list — supports multiple admin accounts
// Set in App Service → Configuration → Application settings
// e.g. "sanjay.dubey@outlook.com,sanjay@ntms.onmicrosoft.com"
const ADMIN_EMAILS = (process.env.ADMIN_EMAIL || 'sanjay.dubey@outlook.com,sanjay@ntms.onmicrosoft.com')
  .split(',').map(e => e.trim().toLowerCase()).filter(Boolean);

const TOPICS_DIR  = path.join(__dirname, 'public', 'topics');
const INDEX_PATH  = path.join(__dirname, 'public', 'index.html');
const CONFIG_PATH = path.join(__dirname, 'admin-config.json');

// ── Admin config ───────────────────────────────────────────────
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH))
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (e) { console.warn('admin-config read error:', e.message); }
  const def = (process.env.PROTECTED_TOPICS || '').split(',').map(t=>t.trim()).filter(Boolean);
  return { protectedTopics: def };
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

// ── Easy Auth principal parser ─────────────────────────────────
function getPrincipal(req) {
  const h = req.headers['x-ms-client-principal'];
  if (!h) return null;
  try { return JSON.parse(Buffer.from(h, 'base64').toString('utf8')); }
  catch { return null; }
}

// Resolve guest #EXT# UPN → original email
// e.g. sanjay.dubey_outlook.com#EXT#@tenant → sanjay.dubey@outlook.com
function resolveGuestUpn(v) {
  if (!v || !v.includes('#ext#')) return v;
  const local = v.split('#ext#')[0];            // sanjay.dubey_outlook.com
  const lastUs = local.lastIndexOf('_');
  if (lastUs > 0) return local.slice(0,lastUs) + '@' + local.slice(lastUs+1);
  return v;
}

// Extract ALL possible email representations from claims
function extractEmails(p) {
  const claims = p.claims || [];
  const gc = type => (claims.find(c => c.typ === type) || {}).val || '';

  const raw = [
    gc('email'),
    gc('preferred_username'),
    gc('upn'),
    gc('unique_name'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn'),
    gc('http://schemas.microsoft.com/identity/claims/objectidentifier') ? '' : '',
    p.userDetails || '',
  ].map(v => v.toLowerCase()).filter(Boolean);

  // Add #EXT# resolved versions
  const resolved = raw.map(resolveGuestUpn);
  return [...new Set([...raw, ...resolved])].filter(Boolean);
}

function getUser(req) {
  const p = getPrincipal(req);
  if (!p) return null;
  const claims = p.claims || [];
  const gc = type => (claims.find(c => c.typ === type) || {}).val || '';
  const emails = extractEmails(p);
  return {
    name:          gc('name') || gc('given_name') || p.userDetails || 'User',
    email:         emails[0] || '',
    allEmails:     emails,
    authenticated: true,
  };
}

function isAuthenticated(req) {
  return AUTH_ENABLED && !!getPrincipal(req);
}

function checkIsAdmin(req) {
  if (!AUTH_ENABLED) return false;
  const user = getUser(req);
  if (!user) return false;
  return user.allEmails.some(e => ADMIN_EMAILS.includes(e));
}

// ── Topic discovery ────────────────────────────────────────────
function getTopicIds() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => f.replace('-module.js',''));
  } catch { return []; }
}

function getTopicScripts() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => `<script src="/topics/${f}"></script>`)
      .join('\n    ');
  } catch { return ''; }
}

// ── Dynamic index.html ─────────────────────────────────────────
let indexTemplate = null;
function getIndexHtml() {
  if (!indexTemplate || process.env.NODE_ENV !== 'production') {
    const raw = fs.readFileSync(INDEX_PATH, 'utf8');
    indexTemplate = raw.replace(
      /<!-- TOPIC MODULES.*?<!-- END TOPIC MODULES -->/s,
      '<!-- TOPIC MODULES — auto-injected -->\n    __TOPIC_SCRIPTS__\n    <!-- END TOPIC MODULES -->'
    );
  }
  return indexTemplate.replace('__TOPIC_SCRIPTS__', getTopicScripts());
}

// ════════════════════════════════════════════════════════════════
// API ROUTES — all defined BEFORE the SPA wildcard
// ════════════════════════════════════════════════════════════════

// ── GET /api/auth/me ───────────────────────────────────────────
app.get('/api/auth/me', (req, res) => {
  const user = getUser(req);
  if (user) {
    res.json({
      authenticated: true,
      isAdmin:  checkIsAdmin(req),
      name:     user.name,
      email:    user.email,
    });
  } else {
    res.json({ authenticated: false, isAdmin: false });
  }
});

// ── GET /api/auth/topics ───────────────────────────────────────
app.get('/api/auth/topics', (req, res) => {
  const authed = isAuthenticated(req);
  const cfg    = loadConfig();
  res.json({
    authenticated:   authed,
    protectedTopics: authed ? [] : cfg.protectedTopics,
  });
});

// ── GET /api/admin/config ──────────────────────────────────────
app.get('/api/admin/config', (req, res) => {
  if (!checkIsAdmin(req)) return res.status(403).json({ error: 'Admin only.' });
  const cfg = loadConfig();
  res.json({ protectedTopics: cfg.protectedTopics, allTopics: getTopicIds(), adminEmails: ADMIN_EMAILS });
});

// ── POST /api/admin/config ─────────────────────────────────────
app.post('/api/admin/config', (req, res) => {
  if (!checkIsAdmin(req)) return res.status(403).json({ error: 'Admin only.' });
  const { protectedTopics } = req.body;
  if (!Array.isArray(protectedTopics)) return res.status(400).json({ error: 'Array expected.' });
  const known = new Set(getTopicIds());
  const valid = protectedTopics.filter(t => known.has(t));
  saveConfig({ protectedTopics: valid, updatedAt: new Date().toISOString() });
  console.log('[Admin] Config saved:', valid);
  res.json({ ok: true, protectedTopics: valid });
});

// ── GET /api/debug/claims ──────────────────────────────────────
// Visit this URL while signed in to see exactly what Entra ID sends.
// Useful for diagnosing admin email matching.
app.get('/api/debug/claims', (req, res) => {
  // Force JSON — prevent browser/SPA from intercepting
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  const p = getPrincipal(req);
  if (!p) {
    return res.json({
      signedIn: false,
      tip: 'Sign in first, then visit /api/debug/claims',
      easyAuthEnabled: AUTH_ENABLED,
      headerPresent: !!req.headers['x-ms-client-principal'],
    });
  }

  const user      = getUser(req);
  const adminMatch = checkIsAdmin(req);

  res.json({
    signedIn:             true,
    isAdmin:              adminMatch,
    resolvedName:         user?.name,
    resolvedEmail:        user?.email,
    allExtractedEmails:   user?.allEmails,
    configuredAdminEmails: ADMIN_EMAILS,
    matchExplanation:     adminMatch
      ? `MATCH — one of allExtractedEmails is in configuredAdminEmails`
      : `NO MATCH — add "${user?.email}" to ADMIN_EMAIL app setting`,
    identityProvider:     p.identityProvider,
    userDetails:          p.userDetails,
    rawClaims:            (p.claims || []).map(c => ({ typ: c.typ, val: c.val })),
  });
});

// ── GET /api/topics/list ───────────────────────────────────────
app.get('/api/topics/list', (req, res) => {
  res.json({ topics: getTopicIds(), count: getTopicIds().length });
});

// ── Easy Auth login / logout ───────────────────────────────────
app.get('/api/auth/login', (req, res) => {
  res.redirect(`/.auth/login/aad?post_login_redirect_uri=${encodeURIComponent(req.query.redirect || '/')}`);
});
app.get('/api/auth/logout', (req, res) => {
  res.redirect('/.auth/logout?post_logout_redirect_uri=/');
});

// ── Static files ───────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, index: false }));

// ── SPA wildcard — MUST be last ────────────────────────────────
app.get('*', (req, res) => {
  // Never catch /api/* here — those are handled above
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found.' });
  }
  try {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(getIndexHtml());
  } catch (err) {
    console.error('index.html error:', err.message);
    res.status(500).send('Server error.');
  }
});

// ── Start ──────────────────────────────────────────────────────
app.listen(port, () => {
  const cfg = loadConfig();
  console.log(`NTMS Cloud Guide   port=${port}`);
  console.log(`Auth enabled     : ${AUTH_ENABLED}`);
  console.log(`Admin emails     : ${ADMIN_EMAILS.join(', ')}`);
  console.log(`Protected topics : ${cfg.protectedTopics.join(', ') || '(none)'}`);
  console.log(`Topics installed : ${getTopicIds().join(', ')}`);
  console.log(`Debug URL        : https://ntms-cloud-guide.azurewebsites.net/api/debug/claims`);
});
