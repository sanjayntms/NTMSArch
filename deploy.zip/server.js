const express = require('express');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const port = process.env.PORT || 3000;
app.use(express.json());

// ── Config ─────────────────────────────────────────────────────
const AUTH_ENABLED = (process.env.AUTH_ENABLED || 'false').toLowerCase() === 'true';
const ADMIN_EMAIL  = (process.env.ADMIN_EMAIL  || 'sanjay.dubey@outlook.com').toLowerCase();
const TOPICS_DIR   = path.join(__dirname, 'public', 'topics');
const INDEX_PATH   = path.join(__dirname, 'public', 'index.html');
const CONFIG_PATH  = path.join(__dirname, 'admin-config.json');

// ── Admin config persistence ───────────────────────────────────
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH))
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (e) {
    console.warn('admin-config.json unreadable:', e.message);
  }
  const defaultLocked = (process.env.PROTECTED_TOPICS || '')
    .split(',').map(t => t.trim()).filter(Boolean);
  return { protectedTopics: defaultLocked };
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

// ── Easy Auth header parser ────────────────────────────────────
function getPrincipal(req) {
  const h = req.headers['x-ms-client-principal'];
  if (!h) return null;
  try { return JSON.parse(Buffer.from(h, 'base64').toString('utf8')); }
  catch { return null; }
}

// Extract user info — handles regular + guest Entra ID accounts.
// Guest accounts use UPN like: user_domain.com#EXT#@tenant.onmicrosoft.com
// We check every useful claim and also strip #EXT# UPNs back to the
// original email address so admin matching works.
function getUser(req) {
  const p = getPrincipal(req);
  if (!p) return null;

  const claims = p.claims || [];
  const gc  = type => (claims.find(c => c.typ === type) || {}).val || '';
  const all = type => claims.filter(c => c.typ === type).map(c => c.val);

  // Collect every candidate email from all claim types
  const candidates = [
    gc('email'),
    gc('preferred_username'),
    gc('upn'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'),
    gc('http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn'),
    gc('unique_name'),
    p.userDetails || '',
  ].map(v => v.toLowerCase()).filter(Boolean);

  // For guest accounts: convert "user_domain.com#EXT#@tenant.onmicrosoft.com"
  // back to "user@domain.com"
  const resolved = candidates.map(v => {
    if (v.includes('#ext#')) {
      // e.g. sanjay.dubey_outlook.com#EXT#@contoso.onmicrosoft.com
      // → extract the part before #EXT#, replace last _ with @
      const local = v.split('#ext#')[0];           // sanjay.dubey_outlook.com
      const lastUs = local.lastIndexOf('_');
      if (lastUs > 0) return local.slice(0,lastUs) + '@' + local.slice(lastUs+1);
    }
    return v;
  });

  // Dedupe and combine
  const allEmails = [...new Set([...candidates, ...resolved])].filter(Boolean);

  const name  = gc('name') || gc('given_name') || gc('unique_name') || p.userDetails || 'User';
  const email = allEmails[0] || '';

  return { name, email, allEmails, authenticated: true };
}

function isAuthenticated(req) {
  return AUTH_ENABLED && getPrincipal(req) !== null;
}

// Admin if ANY of the extracted email variants matches ADMIN_EMAIL
function isAdmin(req) {
  if (!AUTH_ENABLED) return false;
  const user = getUser(req);
  if (!user) return false;
  return user.allEmails.some(e => e === ADMIN_EMAIL);
}

// ── Topic discovery ────────────────────────────────────────────
function getTopicIds() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => f.replace('-module.js',''));
  } catch { return []; }
}

function getTopicScripts() {
  try {
    return fs.readdirSync(TOPICS_DIR)
      .filter(f => f.endsWith('-module.js')).sort()
      .map(f => `<script src="/topics/${f}"></script>`)
      .join('\n    ');
  } catch { return ''; }
}

// ── Dynamic index.html ─────────────────────────────────────────
let indexTemplate = null;
function getIndexHtml() {
  if (!indexTemplate || process.env.NODE_ENV !== 'production') {
    const raw = fs.readFileSync(INDEX_PATH, 'utf8');
    indexTemplate = raw.replace(
      /<!-- TOPIC MODULES.*?<!-- END TOPIC MODULES -->/s,
      '<!-- TOPIC MODULES — auto-injected -->\n    __TOPIC_SCRIPTS__\n    <!-- END TOPIC MODULES -->'
    );
  }
  return indexTemplate.replace('__TOPIC_SCRIPTS__', getTopicScripts());
}

// ════════════════════════════════════════════════════════════════
// API ROUTES
// ════════════════════════════════════════════════════════════════

// ── GET /api/auth/me ───────────────────────────────────────────
app.get('/api/auth/me', (req, res) => {
  const user = getUser(req);
  if (user) {
    const admin = user.allEmails.some(e => e === ADMIN_EMAIL);
    res.json({
      authenticated: true,
      isAdmin:       admin,
      name:          user.name,
      email:         user.email,
    });
  } else {
    res.json({ authenticated: false, isAdmin: false });
  }
});

// ── GET /api/auth/topics ───────────────────────────────────────
app.get('/api/auth/topics', (req, res) => {
  const authed = isAuthenticated(req);
  const cfg    = loadConfig();
  res.json({
    authenticated:   authed,
    protectedTopics: authed ? [] : cfg.protectedTopics,
  });
});

// ── GET /api/admin/config ──────────────────────────────────────
app.get('/api/admin/config', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Admin access required.' });
  const cfg = loadConfig();
  res.json({ protectedTopics: cfg.protectedTopics, allTopics: getTopicIds(), adminEmail: ADMIN_EMAIL });
});

// ── POST /api/admin/config ─────────────────────────────────────
app.post('/api/admin/config', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Admin access required.' });
  const { protectedTopics } = req.body;
  if (!Array.isArray(protectedTopics)) return res.status(400).json({ error: 'Array expected.' });
  const known = new Set(getTopicIds());
  const valid = protectedTopics.filter(t => known.has(t));
  saveConfig({ protectedTopics: valid, updatedAt: new Date().toISOString() });
  console.log('[Admin] Topics updated:', valid);
  res.json({ ok: true, protectedTopics: valid });
});

// ── GET /api/debug/claims  ─────────────────────────────────────
// Shows exactly what Entra ID sends — use to diagnose guest account
// admin matching. REMOVE or restrict in production once verified.
app.get('/api/debug/claims', (req, res) => {
  const p = getPrincipal(req);
  if (!p) return res.json({ message: 'No principal — not signed in or Easy Auth not enabled.' });
  const user = getUser(req);
  res.json({
    userDetails:  p.userDetails,
    identityProvider: p.identityProvider,
    allEmails:    user?.allEmails,
    resolvedName: user?.name,
    adminEmailConfigured: ADMIN_EMAIL,
    isAdminMatch: user?.allEmails?.some(e => e === ADMIN_EMAIL) || false,
    rawClaims:    p.claims || [],
  });
});

// ── GET /api/topics/list ───────────────────────────────────────
app.get('/api/topics/list', (req, res) => {
  res.json({ topics: getTopicIds(), count: getTopicIds().length });
});

// ── Easy Auth login / logout ───────────────────────────────────
app.get('/api/auth/login', (req, res) => {
  res.redirect(`/.auth/login/aad?post_login_redirect_uri=${encodeURIComponent(req.query.redirect || '/')}`);
});
app.get('/api/auth/logout', (req, res) => {
  res.redirect('/.auth/logout?post_logout_redirect_uri=/');
});

// ── Static files ───────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, index: false }));

// ── SPA fallback ───────────────────────────────────────────────
app.get('*', (req, res) => {
  try {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(getIndexHtml());
  } catch (err) {
    console.error('index.html error:', err.message);
    res.status(500).send('Server error.');
  }
});

// ── Start ──────────────────────────────────────────────────────
app.listen(port, () => {
  const cfg = loadConfig();
  console.log(`NTMS Cloud Guide   port=${port}`);
  console.log(`Auth enabled     : ${AUTH_ENABLED}`);
  console.log(`Admin email      : ${ADMIN_EMAIL}`);
  console.log(`Protected topics : ${cfg.protectedTopics.join(', ') || '(none)'}`);
  console.log(`Topics installed : ${getTopicIds().join(', ')}`);
  console.log(`Debug claims URL : /api/debug/claims (sign in first)`);
});
